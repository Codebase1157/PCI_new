# splits/

Leave-one-domain-out (LODO) split manifests (Section 3.3).

## What's here

```
splits/
├── lodo_isic2019/          # fold: ISIC 2019 held out
├── lodo_derm7pt/           # fold: Derm7pt held out
├── lodo_fitzpatrick17k_c/  # fold: Fitzpatrick17k-C held out
├── lodo_pad_ufes_20/       # fold: PAD-UFES-20 held out
│   ├── split.EXAMPLE.csv     # schema-correct example (see note)
│   └── summary.EXAMPLE.csv   # per-role image / patient / prevalence counts
└── external/
    ├── ddi.EXAMPLE.csv       # external-only test set schema
    └── scin.EXAMPLE.csv
```

> **`*.EXAMPLE.csv` are schema demonstrations, not the real splits.** The real splits
> index the actual dataset images, which are not redistributed (see
> `docs/data_access.md`). After you obtain the datasets and run
> `scripts/00_prepare_data.py` → `scripts/02_make_splits.py`, the real
> `split.csv`/`summary.csv` are written here with identical columns. The splits are
> **deterministic** given `seed` in `configs/default.yaml`, so anyone with the same raw
> data reproduces byte-identical manifests.

## Schema (`split.csv`)

| Column | Meaning |
|--------|---------|
| `image_id` | unique image identifier |
| `source` | one of the six datasets |
| `modality` | dermoscopy / clinical / smartphone |
| `path` | image path relative to `data_root` |
| `native_label` | normalized native diagnosis |
| `binary_label` | 0 = non-malignant, 1 = malignant (Table S4b) |
| `is_actinic_keratosis` | flagged for separate reporting (Section 3.1) |
| `patient_id` | patient-level grouping (lesion-level fallback where no IDs) |
| `fitzpatrick` | externally supplied Fitzpatrick label, where available |
| `ita_bin` | **estimated** Del Bino tone bin (label-free; Section 3.2) |
| `role` | `learner_train` / `level1_oof` / `conformal_calib` / `val` / `heldout_test` |
| `fold` | the held-out source for this fold |

## Partitioning (Section 3.3)

Within each fold the three training sources are split **at patient level** into disjoint
partitions so no image serves two roles:

| Role | Share | Purpose |
|------|-------|---------|
| `learner_train` | 70% | stage-1 learner training |
| `level1_oof` | 15% | out-of-fold level-1 features (eq 14) |
| `conformal_calib` | 15% | conformal calibration (eq 22) |
| `val` | carved from `learner_train` | training-domain model selection |

`fitzpatrick` is used **only** for fairness stratification in evaluation; `ita_bin` is
the label-free estimate used inside the model (dependence penalty, counterfactual
search, conformal grouping at inference). The two are never interchanged (Section 3.2).
