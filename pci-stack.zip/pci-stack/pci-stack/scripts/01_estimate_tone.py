#!/usr/bin/env python
"""Stage 01 — label-free skin-tone (ITA) estimation (Section 3.2).

Adds `ita` and `ita_bin` to the harmonized manifest and writes the Table S6 agreement
statistics for the two training sources carrying a Fitzpatrick label. ITA is used only
in the dependence penalty (eq 10) and the counterfactual target search (eq 6); fairness
reporting always uses the externally supplied Fitzpatrick annotation.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.data import ImageLoader, agreement, estimate_tone_for_manifest
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("01_tone")

    man_path = Path(cfg.paths.harmonized) / "manifest.csv"
    if not man_path.exists():
        log.error("no manifest at %s — run 00_prepare_data.py first.", man_path)
        return
    manifest = pd.read_csv(man_path)
    loader = ImageLoader(cfg.paths.data_root, size=cfg.image_size)

    log.info("estimating ITA for %d images (annulus %.1f-%.1f lesion radii)...",
             len(manifest), *cfg.tone.annulus_radii)
    try:
        toned = estimate_tone_for_manifest(manifest, loader)
    except FileNotFoundError as e:
        log.error("%s", e)
        log.error("Raw images are required for tone estimation; see docs/data_access.md.")
        return

    toned.to_csv(man_path, index=False)
    log.info("wrote ITA for %d rows", len(toned))

    for src in ("fitzpatrick17k_c", "pad_ufes_20"):
        sub = toned[toned["source"] == src]
        if len(sub):
            a = agreement(sub)
            log.info("Table S6 agreement %s: n=%d qwk=%.2f exact3=%.1f%%",
                     src, a["n"], a["qwk"], a["exact3"])


if __name__ == "__main__":
    main()
