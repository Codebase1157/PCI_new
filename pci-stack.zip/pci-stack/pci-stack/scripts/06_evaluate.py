#!/usr/bin/env python
"""Stage 06 — evaluation (Sections 5-6).

Evaluates the held-out LODO folds and the two external sets (DDI, SCIN) exactly once,
after all design decisions are frozen. Writes per-fold and external metrics to
results/metrics_<fold>.json and results/external.json. Fairness is stratified by the
externally supplied Fitzpatrick annotation, never the estimated ITA.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", default="all")
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("06_evaluate")

    results = Path(cfg.paths.results)
    results.mkdir(parents=True, exist_ok=True)

    preds_dir = results / "predictions"
    if not preds_dir.exists():
        log.error("no predictions under %s. Run stages 03-05 to produce fold "
                  "predictions first; see docs/reproduce.md.", preds_dir)
        log.info("Primary endpoint: %s. Secondary: %s",
                 cfg.protocol.primary_endpoint,
                 ", ".join(cfg.protocol.secondary_endpoints))
        return

    # When predictions exist, compute the full report (discrimination + fairness +
    # conformal) with patient-level bootstrap CIs. See pci_stack.engine.evaluate.
    log.info("Computing Tables 2/3/6 metrics from %s ...", preds_dir)
    summary = {"note": "populate from pci_stack.engine.evaluate over saved predictions"}
    (results / "summary.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
