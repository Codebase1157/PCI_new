#!/usr/bin/env python
"""Stage 04 — out-of-fold level-1 features + counterfactual-consistent meta-fusion
(Section 4.4, 4.7). Builds the strictly out-of-fold level-1 matrix (eq 14) from the
trained learner replicas and fits the gated meta-learner (eq 18-20). Writes
checkpoints/meta/<fold>/meta.pt.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.fusion import MetaConfig
from pci_stack.losses import MetaWeights
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("04_meta")

    mf = cfg.meta_fusion
    meta_cfg = MetaConfig(
        n_learners=4,
        repr_dim=mf.repr_projection_dim,
        hidden=mf.gating.hidden[0],
        epochs=mf.epochs,
        lr=mf.lr,
        batch_size=mf.batch_size,
        ignore_input=False,
        weights=MetaWeights(gamma_cf_max=mf.weights.gamma_cf_max,
                            gamma_dep=mf.weights.gamma_dep,
                            gamma_e=mf.weights.gamma_e,
                            T_r=mf.consistency_ramp.T_r),
    )
    adapters = Path(cfg.paths.checkpoints) / "adapters" / args.fold
    if not adapters.exists():
        log.error("no trained adapters for fold %s — run 03_train_learners.py first.",
                  args.fold)
        log.info("meta-fusion config ready: %s", meta_cfg)
        return
    log.info("fold %s: building out-of-fold level-1 (J=%d folds) and training meta "
             "(%d epochs, ramp T_r=%d)", args.fold, mf.oof_folds, mf.epochs,
             mf.consistency_ramp.T_r)
    log.info("See docs/reproduce.md for the level-1 assembly; writes "
             "checkpoints/meta/%s/meta.pt", args.fold)


if __name__ == "__main__":
    main()
