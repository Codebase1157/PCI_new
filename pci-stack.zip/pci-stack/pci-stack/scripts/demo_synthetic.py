#!/usr/bin/env python
"""Self-contained end-to-end smoke test of PCI-Stack on synthetic data.

Exercises all five tiers without any downloaded weights or datasets, in seconds:

  Tier 1  physics counterfactual engine   (reflectance round-trip, tone/Fourier/photometric)
  Tier 2  four-learner zoo (synthetic backbone) + per-learner objective
  Tier 3  out-of-fold level-1 + gated meta-fusion
  Tier 4  Mondrian + shift-aware conformal + abstention
  Tier 5  AAI / CAS / fused-CAM / surrogate / faithfulness

It validates wiring and numerics, NOT accuracy — the reported results require the real
datasets and backbones (docs/data_access.md).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pci_stack.audit import (
    attribution_agreement_index,
    counterfactual_attribution_stability,
    fused_cam,
)
from pci_stack.conformal import (
    MondrianCalibrator,
    abstain,
    calibrate_margin,
    nonconformity,
    prediction_set,
)
from pci_stack.generators import CounterfactualEngine, EngineConfig, decompose, render
from pci_stack.utils import seed_everything
from pci_stack.utils.metrics import coverage, mean_set_size, worst_group_auroc


def banner(t):
    print(f"\n{'='*64}\n{t}\n{'='*64}")


def main():
    seed_everything(2026)
    rng = np.random.default_rng(2026)

    # ---------------- Tier 1 ---------------------------------------------- #
    banner("Tier 1  physics-guided counterfactual engine")
    img = np.clip(0.55 + 0.1 * rng.standard_normal((64, 64, 3)), 0, 1)
    mask = np.zeros((64, 64)); mask[24:40, 24:40] = 1
    err = np.abs(render(decompose(img, mask=mask)) - img).max()
    print(f"reflectance round-trip max abs error : {err:.2e}  (expect ~0)")
    ref = np.clip(0.5 + 0.1 * rng.standard_normal((64, 64, 3)), 0, 1)
    eng = CounterfactualEngine(EngineConfig(views_per_image=2), reference_pool=[ref])
    views = eng.views(img, ["tone", "fourier", "photometric"], lesion_mask=mask)
    print("counterfactual views per axis        :",
          {k: len(v) for k, v in views.items()})

    # ---------------- Tier 2 ---------------------------------------------- #
    banner("Tier 2  counterfactual-diverse learner zoo (synthetic backbone)")
    import torch
    from pci_stack.losses import LearnerWeights, learner_objective
    from pci_stack.models import LearnerZoo

    zoo = LearnerZoo(synthetic=True)
    x = torch.rand(16, 3, 64, 64)
    y = torch.randint(0, 2, (16,))
    outs = zoo.forward(x)
    o1 = outs["M1"]
    s = torch.randint(0, 3, (16,)).float().unsqueeze(1)
    loss, comps = learner_objective(
        o1["logits"], y, LearnerWeights(lambda_con=0, lambda_adv=0),
        cf_logits=[zoo.M1(torch.rand(16, 3, 64, 64))["logits"]],
        repr_z=o1["z"], nuisance_s=s)
    print(f"M1 objective (ce+cf+dep)             : {float(loss.detach()):.4f}  {comps}")
    print("M3 emits concept logits              :", "concept_logits" in outs["M3"])
    print("M4 emits gradient-reversed nuisance  :", "nuisance_logits" in outs["M4"])

    # ---------------- Tier 3 ---------------------------------------------- #
    banner("Tier 3  out-of-fold level-1 + gated meta-fusion")
    from pci_stack.fusion import (
        MetaConfig,
        MetaFusion,
        OOFAssignment,
        build_oof_predictions,
        pairwise_disagreement,
    )

    n = 400
    patient_ids = np.repeat(np.arange(n // 2), 2)
    assign = OOFAssignment.make(n, n_folds=4, patient_ids=patient_ids)
    # toy learners with engineered disagreement
    def make_fp(bias):
        def fp(tr, pr):
            return np.clip(0.5 + bias + 0.2 * rng.standard_normal(len(pr)), 0, 1)
        return fp
    oof = {m: build_oof_predictions(make_fp(b), np.zeros(n), assign)
           for m, b in zip("M1 M2 M3 M4".split(), [0.1, -0.1, 0.05, -0.05])}
    P = np.stack([oof[m] for m in "M1 M2 M3 M4".split()], 1)
    decisions = (P > 0.5).astype(int)
    print(f"out-of-fold level-1 matrix shape     : {P.shape}")
    print(f"mean pairwise disagreement           : {pairwise_disagreement(decisions):.3f}")

    meta = MetaFusion(MetaConfig(n_learners=4, repr_dim=8))
    pt = torch.as_tensor(P, dtype=torch.float32)
    zt = torch.rand(n, 4, 8)
    dt = torch.rand(n, 4)
    fused_p, gates = meta(pt, zt, dt)
    print(f"fused prob shape / gates row-sum     : {tuple(fused_p.shape)} / "
          f"{float(gates.sum(1).mean()):.3f}")

    # ---------------- Tier 4 ---------------------------------------------- #
    banner("Tier 4  shift-aware group-conditional conformal + abstention")
    labels = rng.integers(0, 2, n)
    p_pos = np.clip(0.5 + 0.3 * (2 * labels - 1) + 0.2 * rng.standard_normal(n), .01, .99)
    Pm = np.stack([1 - p_pos, p_pos], 1)
    tone = rng.choice(["light", "intermediate", "dark"], n, p=[.5, .35, .15])
    dom = rng.choice(["dermoscopy", "clinical", "smartphone"], n)
    cal = MondrianCalibrator(alpha=0.10, min_cell_count=50).fit(
        nonconformity(Pm, labels), tone, dom)
    sets = prediction_set(Pm, tone, dom, cal)
    lp = np.clip(p_pos[:, None] + 0.1 * rng.standard_normal((n, 4)), 0, 1)
    kappa = calibrate_margin(lp, p_pos, delta=0.10)
    ab = abstain(sets, lp, p_pos, kappa)
    print(f"marginal coverage (target 0.90)      : {coverage(sets, labels):.3f}")
    print(f"mean set size                        : {mean_set_size(sets):.3f}")
    print(f"calibrated kappa / abstain fraction  : {kappa:.3f} / {ab.mean():.3f}")
    fitz = np.where(tone == "light", "I-II", np.where(tone == "dark", "V-VI", "III-IV"))
    print(f"worst-group AUROC (by stratum)       : {worst_group_auroc(labels, p_pos, fitz):.3f}")

    # ---------------- Tier 5 ---------------------------------------------- #
    banner("Tier 5  explanation audit")
    yy, xx = np.mgrid[0:32, 0:32]
    blob = np.exp(-(((yy - 16) ** 2 + (xx - 16) ** 2) / 40.0))
    cams = [np.clip(blob + 0.1 * rng.standard_normal((32, 32)), 0, None) for _ in range(4)]
    fm = fused_cam(cams, np.array([0.4, 0.2, 0.2, 0.2]))
    cf_maps = [np.clip(blob + 0.05 * rng.standard_normal((32, 32)), 0, None) for _ in range(3)]
    print(f"Attribution Agreement Index (eq 29)  : {attribution_agreement_index(cams):.3f}")
    print(f"Counterfactual Attrib. Stability (30): "
          f"{counterfactual_attribution_stability(fm, cf_maps):.3f}")

    banner("ALL TIERS OK")
    print("Synthetic wiring verified. For the reported numbers, obtain the datasets and "
          "backbones (docs/data_access.md) and run the numbered pipeline.")


if __name__ == "__main__":
    main()
