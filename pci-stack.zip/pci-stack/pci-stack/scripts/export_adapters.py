#!/usr/bin/env python
"""Export trained LoRA adapters (+ meta/conformal state) into the release layout and
regenerate checkpoints/MANIFEST.json with SHA-256 hashes.

Only adapters and heads are exported — never the base backbone weights (PanDerm research
license; see LICENSE-PANDERM-NOTE.md).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def export_learner(zoo, learner_name: str, out: Path):
    """Save only lora_* and head parameters for one learner."""
    import torch

    learner = zoo.learners[learner_name]
    state = {k: v for k, v in learner.state_dict().items()
             if "lora_" in k or k.startswith(("classifier", "repr_proj",
                                              "concept_head", "discriminator"))}
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        from safetensors.torch import save_file

        path = out.with_suffix(".safetensors")
        save_file(state, str(path))
    except Exception:
        path = out.with_suffix(".pt")
        torch.save(state, str(path))
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold", required=True)
    ap.add_argument("--ckpt-dir", default="checkpoints")
    args = ap.parse_args()

    from pci_stack.models import LearnerZoo

    # In a real export the zoo would be loaded from a training checkpoint; here we
    # instantiate the architecture to produce a correctly-structured (zero-init) export
    # and the manifest, so the release layout and loader can be validated.
    zoo = LearnerZoo(synthetic=False) if Path("data/backbones").exists() \
        else LearnerZoo(synthetic=True)

    root = Path(args.ckpt_dir)
    artifacts = []
    for name in zoo.order:
        p = export_learner(zoo, name, root / "adapters" / args.fold / name)
        artifacts.append({"path": str(p.relative_to(root)), "sha256": sha256(p),
                          "learner": name, "fold": args.fold})
        print(f"exported {p}")

    manifest = {
        "schema": "pci-stack/checkpoints/v1",
        "note": "LoRA adapters + heads only; base backbones not included "
                "(see LICENSE-PANDERM-NOTE.md).",
        "artifacts": artifacts,
    }
    (root / "MANIFEST.json").write_text(json.dumps(manifest, indent=2))
    print(f"wrote {root / 'MANIFEST.json'}")


if __name__ == "__main__":
    main()
