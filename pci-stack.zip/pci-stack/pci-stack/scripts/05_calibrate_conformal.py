#!/usr/bin/env python
"""Stage 05 — shift-aware group-conditional conformal calibration (Section 4.5).

Fits the Mondrian calibrator on the conformal-calibration partition (eq 22), estimates
the density-ratio reweighting (eq 23) and the abstention margin kappa (eq 25). Writes
checkpoints/conformal/<fold>/calibrator.json.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("05_calibrate")

    cf = cfg.conformal
    log.info("fold %s: alpha=%.2f, min_cell=%d, kappa target delta=%.2f",
             args.fold, cf.alpha, cf.mondrian.min_cell_count,
             cf.abstention.referral_budget_delta)
    meta = Path(cfg.paths.checkpoints) / "meta" / args.fold / "meta.pt"
    if not meta.exists():
        log.error("no meta-fusion for fold %s — run 04_train_meta.py first.", args.fold)
        log.info("Conformal config: cells=%s, shift reweight=%s, abstention=%s",
                 cf.mondrian.cells, cf.shift.reweight, cf.abstention.enabled)
        return
    log.info("Calibrating on the 15%% conformal partition; see docs/reproduce.md.")


if __name__ == "__main__":
    main()
