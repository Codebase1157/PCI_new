#!/usr/bin/env python
"""Stage 03 — train the four counterfactual-diverse learners (Section 4.3, 4.7).

For the given LODO fold, builds the counterfactual engine and trains M1-M4 under their
invariance contracts. Requires the backbone weights (docs/data_access.md) and the raw
images. Writes per-learner adapters to checkpoints/adapters/<fold>/ and JSONL logs.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("03_train", logfile=f"{cfg.paths.logs}/stage1_fold-{args.fold}.log")

    split = Path(cfg.paths.splits) / f"lodo_{args.fold}" / "split.csv"
    if not split.exists():
        log.error("no split for fold %s — run 02_make_splits.py first.", args.fold)
        return
    backbones = Path(cfg.paths.backbones)
    if not backbones.exists():
        log.error("backbone weights not found at %s.", backbones)
        log.error("Stage-1 training needs PanDerm/DINOv2/Swin weights; see "
                  "docs/data_access.md. (Use scripts/demo_synthetic.py for a "
                  "weight-free end-to-end smoke test.)")
        return

    # Real training wiring. The data assembly (image loading, counterfactual reference
    # pool, concept targets) is built here from the split manifest; see docs/reproduce.md
    # for the full command. Intentionally guarded so a fresh clone fails loudly rather
    # than silently producing nothing.
    from pci_stack.engine import Stage1Config, train_learner
    from pci_stack.generators import CounterfactualEngine
    from pci_stack.losses import LearnerWeights
    from pci_stack.models import LearnerZoo

    log.info("fold %s: building engine and zoo", args.fold)
    engine = CounterfactualEngine.from_config(cfg.generator)
    zoo = LearnerZoo(weights={
        "panderm_vit_l": str(backbones / "panderm_vit_l.safetensors"),
        "dinov2_l": None, "swin_b": None,
    })
    # `make_fold_loader` is provided in docs/reproduce.md; here we only report readiness
    log.info("zoo trainable report:")
    for row in zoo.trainable_report():
        log.info("  %s", row)
    log.info("To launch full training, wire a DataLoader per docs/reproduce.md and call "
             "train_learner(...) for each of M1-M4 with Stage1Config from Table S1.")


if __name__ == "__main__":
    main()
