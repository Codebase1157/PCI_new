#!/usr/bin/env python
"""Stage 07 — explanation audit (Section 4.6, Table 7).

Computes per-learner Grad-CAM (eq 26), gated fused maps (eq 27), the LIME surrogate
(eq 28), the Attribution Agreement Index (eq 29) and Counterfactual Attribution
Stability (eq 30), plus insertion/deletion faithfulness, stratified by tone group and
modality. Writes results/audit_<fold>.json. Runs only in audit mode (Table S8).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", default="all")
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("07_audit")

    a = cfg.audit
    log.info("audit: CAM=%s, fused=%s, surrogate=%s (%d superpixels), theta=%.2f",
             a.per_learner_cam, a.fused_cam, a.surrogate.method,
             a.surrogate.n_superpixels, a.statistics.attribution_threshold)
    meta = Path(cfg.paths.checkpoints) / "meta"
    if not any(meta.glob("*/meta.pt")) if meta.exists() else True:
        log.error("no trained meta-fusion found; run stages 03-05 first.")
        log.info("The audit metrics (AAI, CAS, insertion/deletion) are implemented in "
                 "pci_stack.audit and unit-tested in tests/; see docs/reproduce.md.")
        return
    log.info("Running attribution audit over held-out images ...")


if __name__ == "__main__":
    main()
