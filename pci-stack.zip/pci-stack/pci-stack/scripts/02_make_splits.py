#!/usr/bin/env python
"""Stage 02 — patient-level LODO splits (Section 3.3).

For each of the four training sources as held-out domain, writes a split manifest
(role in {learner_train, level1_oof, conformal_calib, val, heldout_test}) to
splits/lodo_<source>/split.csv, plus a per-role summary. External sets are untouched.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.constants import TRAINING_SOURCES
from pci_stack.data import SplitFractions, make_lodo_splits, split_summary
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("02_splits")

    man_path = Path(cfg.paths.harmonized) / "manifest.csv"
    if not man_path.exists():
        log.error("no manifest at %s — run 00_prepare_data.py first.", man_path)
        return
    manifest = pd.read_csv(man_path)

    part = cfg.protocol.partition
    fracs = SplitFractions(learner_train=part.learner_train,
                           level1_oof=part.level1_oof,
                           conformal_calib=part.conformal_calib)
    folds = TRAINING_SOURCES if args.fold in (None, "all") else [args.fold]
    for src in folds:
        fold_df = make_lodo_splits(manifest, src, fracs, seed=cfg.seed)
        out = Path(cfg.paths.splits) / f"lodo_{src}"
        out.mkdir(parents=True, exist_ok=True)
        fold_df.to_csv(out / "split.csv", index=False)
        summ = split_summary(fold_df)
        summ.to_csv(out / "summary.csv", index=False)
        log.info("fold %s: %s", src, {r.role: int(r.images) for r in summ.itertuples()})


if __name__ == "__main__":
    main()
