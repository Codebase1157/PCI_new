#!/usr/bin/env python
"""Stage 08 — rebuild the paper tables from results/tables/*.csv.

Reads the CSV reproductions of Tables 2-7 shipped under results/tables/ (which the
evaluation stage regenerates) and prints them, verifying the headline numbers quoted in
the abstract: worst-group AUROC 68.7 -> 82.2 and the light-to-dark gap 12.5 -> 4.6.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"


def show(name: str, path: Path):
    if not path.exists():
        print(f"[skip] {name}: {path.name} not found")
        return None
    df = pd.read_csv(path)
    print(f"\n=== {name} ({path.name}) ===")
    with pd.option_context("display.max_columns", None, "display.width", 160):
        print(df.to_string(index=False))
    return df


def main():
    print("PCI-Stack — table reproduction")
    show("Table 2  held-out-domain AUROC", TABLES / "table2_lodo_auroc.csv")
    t3 = show("Table 3  external validation", TABLES / "table3_external.csv")
    show("Table 4  framework ablation", TABLES / "table4_ablation.csv")
    show("Table 5  diversity & cost", TABLES / "table5_diversity_cost.csv")
    show("Table 6  conformal coverage", TABLES / "table6_conformal.csv")
    show("Table 7  explanation audit", TABLES / "table7_audit.csv")

    if t3 is not None:
        try:
            row = t3[t3["Method"].str.contains("PCI-Stack")].iloc[0]
            base = t3[t3["Method"].str.contains("ERM")].iloc[0]
            print("\n--- headline checks (abstract) ---")
            print(f"worst-group AUROC: {base['V-VI']} -> {row['V-VI']} "
                  f"(abstract: 68.7 -> 82.2)")
            print(f"light-to-dark gap: {base['Delta']} -> {row['Delta']} "
                  f"(abstract: 12.5 -> 4.6)")
        except Exception as e:  # pragma: no cover
            print(f"(could not parse headline checks: {e})")


if __name__ == "__main__":
    sys.exit(main())
