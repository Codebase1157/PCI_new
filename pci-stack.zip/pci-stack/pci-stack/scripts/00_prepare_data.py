#!/usr/bin/env python
"""Stage 00 — harmonize the six datasets into the binary task (Table 1, S4).

Reads each source's raw metadata table from <data_root>/<source>/metadata.csv (schema:
image_id, native_label, path[, patient_id, fitzpatrick, biopsy_confirmed]) and writes a
single harmonized manifest plus the Table S4 exclusion report.

Raw datasets are NOT vendored — see docs/data_access.md. If a source table is missing,
this script says so and skips it.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pci_stack.config import load_config
from pci_stack.constants import ALL_SOURCES
from pci_stack.data import harmonize_all
from pci_stack.utils import get_logger, seed_everything


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--fold", default=None)  # unused here; accepted for CLI uniformity
    args = ap.parse_args()
    cfg = load_config(args.config)
    seed_everything(cfg.seed)
    log = get_logger("00_prepare")

    data_root = Path(cfg.paths.data_root)
    out_dir = Path(cfg.paths.harmonized)
    out_dir.mkdir(parents=True, exist_ok=True)

    tables = {}
    for src in ALL_SOURCES:
        meta = data_root / src / "metadata.csv"
        if meta.exists():
            tables[src] = pd.read_csv(meta)
            log.info("loaded %s (%d rows)", src, len(tables[src]))
        else:
            log.warning("missing %s — skipping (see docs/data_access.md)", meta)

    if not tables:
        log.error("no source metadata found under %s. Nothing to harmonize.", data_root)
        log.error("See docs/data_access.md to obtain the public datasets.")
        return

    manifest, report = harmonize_all(tables)
    manifest.to_csv(out_dir / "manifest.csv", index=False)
    report.to_csv(out_dir / "exclusion_report_tableS4.csv", index=False)
    log.info("wrote %d harmonized rows -> %s", len(manifest), out_dir / "manifest.csv")
    log.info("malignant prevalence: %.3f", manifest["binary_label"].mean())


if __name__ == "__main__":
    main()
