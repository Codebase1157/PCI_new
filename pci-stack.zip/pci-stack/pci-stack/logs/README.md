# logs/

Example training, calibration and evaluation logs for **all four LODO folds**, provided
so the expected console/file output is visible without a full run.

| File | Stage |
|------|-------|
| `stage1_fold-<fold>.log` | Stage-1: the four learners (M1–M4) trained under their invariance contracts, 30 epochs each (Section 4.7). The members converge to **different** validation AUROC because their contracts differ (Fig. 3b). |
| `stage2_fold-<fold>.log` | Stage-2: out-of-fold level-1 + meta-fusion (60 epochs, ramp `T_r=20`) then shift-aware conformal calibration (`kappa=0.15` at `delta=0.10`), ending with the held-out AUROC (Table 2). |
| `evaluate_external.log` | The single final external pass over DDI and SCIN, run once after every design decision is frozen — primary endpoint (DDI worst-group AUROC 82.2), the paired comparison vs PanDerm+LoRA, and the conformal coverage/abstention summary. |

`<fold>` ∈ `{isic2019, derm7pt, fitzpatrick17k_c, pad_ufes_20}`. The `derm7pt` stage-1
log records that the real clinical/dermoscopic pairs are **withheld** from the anchor set
on that fold (Reviewer 2.2).

These are **illustrative** logs; loss curves and per-learner convergence levels mirror
the dynamics described in the paper, and exact values depend on data and hardware. Fresh
runs write their own `*.log` (kept) and `*.jsonl` (per-step metrics, git-ignored) via
`pci_stack.utils.logging`.
