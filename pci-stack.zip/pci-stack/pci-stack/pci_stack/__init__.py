"""PCI-Stack: physics-guided counterfactual meta-fusion for fair, generalizable
skin lesion diagnosis.

The package is organized by the five tiers of the framework:

    pci_stack.generators   Tier 1   physics-guided counterfactual engine        (3)-(8)
    pci_stack.models       Tier 2   counterfactual-diverse learner zoo          (LoRA, GRL)
    pci_stack.losses                invariance objectives                       (9)-(13),(18)-(20)
    pci_stack.fusion       Tier 3   out-of-fold stacking + gated meta-fusion    (14)-(20)
    pci_stack.conformal    Tier 4   shift-aware group-conditional conformal     (21)-(25)
    pci_stack.audit        Tier 5   explanation audit                           (26)-(30)
    pci_stack.data                  harmonization, tone estimation, splits
    pci_stack.engine                stage-1/2 trainers, LODO driver, evaluation
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
