"""Minimal YAML config loader with recursive `includes` merging and dotted access.

Usage:
    cfg = load_config("configs/default.yaml")
    cfg.generator.fourier.band_width        # -> 0.10
    cfg["conformal"]["alpha"]               # -> 0.10
"""
from __future__ import annotations

import os
from typing import Any

import yaml


class DotDict(dict):
    """dict with attribute access; nested dicts are wrapped on access."""

    def __getattr__(self, key: str) -> Any:
        try:
            val = self[key]
        except KeyError as exc:
            raise AttributeError(key) from exc
        return DotDict(val) if isinstance(val, dict) else val

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value

    def get_path(self, dotted: str, default: Any = None) -> Any:
        node: Any = self
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge `override` into `base` (override wins on leaves)."""
    out = dict(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_raw(path: str, _stack: tuple[str, ...] = ()) -> dict:
    """Load one file, resolving its `includes`. `_stack` is the chain of ancestor
    files on the current path, so a true cycle is caught while a diamond include
    (the same file reached by two different branches) is allowed."""
    path = os.path.abspath(path)
    if path in _stack:
        raise ValueError(f"circular include detected at {path}")
    stack = _stack + (path,)

    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    includes = data.pop("includes", []) or []
    merged: dict = {}
    base_dir = os.path.dirname(path)
    for inc in includes:
        inc_path = inc if os.path.isabs(inc) else os.path.join(_repo_root(base_dir), inc)
        merged = _deep_merge(merged, _load_raw(inc_path, stack))
    return _deep_merge(merged, data)


def _repo_root(start: str) -> str:
    """Walk up until a directory containing `configs/` is found; else cwd."""
    cur = os.path.abspath(start)
    for _ in range(6):
        if os.path.isdir(os.path.join(cur, "configs")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return os.getcwd()


def load_config(path: str, overrides: dict | None = None) -> DotDict:
    """Load a config file, resolving `includes`, then apply optional overrides."""
    raw = _load_raw(path)
    if overrides:
        raw = _deep_merge(raw, overrides)
    return DotDict(raw)
