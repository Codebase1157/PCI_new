r"""Out-of-fold level-1 feature construction, eq (14).

    p_j^{-kappa(i)}(x_i) = f_j^{-kappa(i)}(x_i),   kappa: {1..n} -> {1..J}          (14)

Each training example is assigned to one of J cross-validation folds; the prediction
recorded for it comes from a learner replica that never saw it. This is the classical
requirement of stacked generalization [19] and the point stacking most often leaks —
so the in-sample alternative is provided as an explicit ablation (`in_sample=True`).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class OOFAssignment:
    """Fold assignment kappa over n examples into J folds, patient-aware."""
    fold_of: np.ndarray            # (n,) fold index per example
    n_folds: int

    @classmethod
    def make(cls, n: int, n_folds: int, patient_ids=None, seed: int = 2026):
        rng = np.random.default_rng(seed)
        if patient_ids is None:
            fold = rng.integers(0, n_folds, size=n)
        else:
            patient_ids = np.asarray(patient_ids)
            clusters = np.unique(patient_ids)
            cluster_fold = {c: i % n_folds
                            for i, c in enumerate(rng.permutation(clusters))}
            fold = np.array([cluster_fold[p] for p in patient_ids])
        return cls(fold_of=fold, n_folds=n_folds)

    def train_idx(self, k: int) -> np.ndarray:
        return np.where(self.fold_of != k)[0]

    def heldout_idx(self, k: int) -> np.ndarray:
        return np.where(self.fold_of == k)[0]


def build_oof_predictions(fit_predict, X, assignment: OOFAssignment,
                          in_sample: bool = False) -> np.ndarray:
    r"""Produce out-of-fold predictions for one learner, eq (14).

    `fit_predict(train_idx, predict_idx) -> array` trains a replica on `train_idx`
    and returns its predictions on `predict_idx`. With `in_sample=True` a single
    replica is trained on all data and predicts everything (the leaky ablation).
    """
    n = len(X) if hasattr(X, "__len__") else X.shape[0]
    preds = np.empty(n, dtype=float)
    if in_sample:
        preds[:] = fit_predict(np.arange(n), np.arange(n))
        return preds
    for k in range(assignment.n_folds):
        tr = assignment.train_idx(k)
        ho = assignment.heldout_idx(k)
        if len(ho) == 0:
            continue
        preds[ho] = fit_predict(tr, ho)
    return preds


def stack_level1(oof_by_learner: dict[str, np.ndarray]) -> np.ndarray:
    """Stack per-learner OOF probability vectors into an (n, J) level-1 matrix."""
    names = sorted(oof_by_learner)
    return np.stack([oof_by_learner[k] for k in names], axis=1)
