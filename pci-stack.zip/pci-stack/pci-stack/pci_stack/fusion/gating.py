r"""Instance-dependent gating network, eq (16)-(17).

Per-learner level-1 feature, eq (16):
    u(x) = [ p_j(x); z_j(x); d_j(x) ]_{j=1..J}
    g_j(x) = exp(h_{phi,j}(u(x))) / sum_l exp(h_{phi,l}(u(x)))          (softmax)

Fused score, eq (17):
    p(x) = sum_j g_j(x) p_j(x),   sum_j g_j(x) = 1

Classical stacking with global weights is recovered exactly when the gating network
is constrained to ignore its input (`ignore_input=True`).
"""
from __future__ import annotations

import torch
import torch.nn as nn


class GatingNetwork(nn.Module):
    """Two-layer perceptron with softmax output over J learners, eq (16)."""

    def __init__(self, in_dim: int, n_learners: int, hidden: int = 64,
                 ignore_input: bool = False):
        super().__init__()
        self.n_learners = n_learners
        self.ignore_input = ignore_input
        if ignore_input:
            # vanilla stacking: a single global weight vector, input ignored
            self.global_logits = nn.Parameter(torch.zeros(n_learners))
        else:
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden), nn.ReLU(),
                nn.Linear(hidden, n_learners),
            )

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        """u: (n, in_dim) -> gates (n, J), rows sum to 1."""
        if self.ignore_input:
            logits = self.global_logits.unsqueeze(0).expand(u.shape[0], -1)
        else:
            logits = self.net(u)
        return torch.softmax(logits, dim=-1)


def build_u(p: torch.Tensor, z: torch.Tensor, d: torch.Tensor) -> torch.Tensor:
    r"""Assemble u(x) of eq (16) from stacked per-learner features.
        p : (n, J)        out-of-fold probabilities
        z : (n, J, dz)    low-dim representation projections
        d : (n, J)        counterfactual disagreement statistics
    Returns (n, J*(2 + dz))."""
    n, J = p.shape
    dz = z.shape[-1]
    z_flat = z.reshape(n, J * dz)
    # interleave per learner: [p_j, d_j] then the z block
    pd = torch.stack([p, d], dim=-1).reshape(n, J * 2)
    return torch.cat([pd, z_flat], dim=-1)


def fuse(gates: torch.Tensor, probs: torch.Tensor) -> torch.Tensor:
    """eq (17): fused positive-class probability p(x) = sum_j g_j p_j."""
    return (gates * probs).sum(dim=-1)
