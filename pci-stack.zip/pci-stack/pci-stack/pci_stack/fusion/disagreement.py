r"""Counterfactual disagreement statistic, eq (15).

    d_j(x) = Var_{x' ~ C(x)} p_j(x') = 1/|C(x)| sum_{x' in C(x)} ( p_j(x') - p_j_bar )^2   (15)

The variance of learner j's prediction over its own counterfactual views. This is a
label-free estimate of how much an expert's opinion about *this* image depends on
nuisance appearance, and it makes the fusion instance-dependent. Both numpy and torch
inputs are supported.
"""
from __future__ import annotations

import numpy as np


def disagreement(cf_probs) -> float:
    r"""eq (15) for a single learner / single image. `cf_probs` is an iterable of the
    learner's positive-class probabilities over its counterfactual views."""
    arr = np.asarray(list(cf_probs), dtype=float)
    if arr.size == 0:
        return 0.0
    return float(arr.var())           # population variance over |C(x)| views


def disagreement_batch(cf_probs_matrix: np.ndarray) -> np.ndarray:
    """Vectorized eq (15). `cf_probs_matrix` is (n, V) — V counterfactual views per
    image — returning the per-image variance (n,)."""
    m = np.asarray(cf_probs_matrix, dtype=float)
    if m.ndim == 1:
        m = m[None, :]
    return m.var(axis=1)


def pairwise_disagreement(decisions: np.ndarray) -> float:
    """Mean pairwise fraction of differing *decisions* across learners (Table 5).
    `decisions` is (n, J) binary. Used as a diversity diagnostic, not in fusion."""
    d = np.asarray(decisions)
    n, J = d.shape
    if J < 2:
        return 0.0
    total, pairs = 0.0, 0
    for a in range(J):
        for b in range(a + 1, J):
            total += (d[:, a] != d[:, b]).mean()
            pairs += 1
    return float(total / pairs)


def yule_q(decisions_a: np.ndarray, decisions_b: np.ndarray,
           correct: np.ndarray) -> float:
    """Yule's Q association between two learners' correctness (Table 5; lower = more
    diverse). `correct` is the ground-truth needed to score each as right/wrong."""
    a = np.asarray(decisions_a) == np.asarray(correct)
    b = np.asarray(decisions_b) == np.asarray(correct)
    n11 = float((a & b).sum())
    n00 = float((~a & ~b).sum())
    n10 = float((a & ~b).sum())
    n01 = float((~a & b).sum())
    denom = n11 * n00 + n10 * n01
    return float((n11 * n00 - n10 * n01) / denom) if denom else 0.0
