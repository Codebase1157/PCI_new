r"""Counterfactual-consistent stacked meta-learner (Tier 3, Section 4.4).

Wraps the gating network (eq 16-17) and trains it with the meta objective
(eq 18-20): cross-entropy on the fused score, a fusion-level counterfactual-
consistency penalty, a dependence penalty on the fused score, and a gating-entropy
regularizer, with the consistency weight following the linear ramp of eq (20).

The structural difference from the stacked ensembles of Section 2.1: the fused output,
not merely each member, is required to be invariant.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from ..losses.objectives import MetaWeights, meta_objective
from .gating import GatingNetwork, build_u, fuse


@dataclass
class MetaConfig:
    n_learners: int = 4
    repr_dim: int = 32
    hidden: int = 64
    epochs: int = 60
    lr: float = 1e-3
    batch_size: int = 256
    ignore_input: bool = False        # True -> vanilla global-weight stacking
    weights: MetaWeights = None

    def __post_init__(self):
        if self.weights is None:
            self.weights = MetaWeights()


class MetaFusion(nn.Module):
    """The gated meta-learner. `forward` returns the fused positive-class probability
    and the gates; a 2-logit tensor is derived for the cross-entropy term."""

    def __init__(self, cfg: MetaConfig):
        super().__init__()
        self.cfg = cfg
        in_dim = cfg.n_learners * (2 + cfg.repr_dim)
        self.gate = GatingNetwork(in_dim, cfg.n_learners, cfg.hidden,
                                  ignore_input=cfg.ignore_input)

    def forward(self, p, z, d):
        u = build_u(p, z, d)
        gates = self.gate(u)
        fused_p = fuse(gates, p).clamp(1e-6, 1 - 1e-6)
        return fused_p, gates

    @staticmethod
    def to_logits(prob: torch.Tensor) -> torch.Tensor:
        """Map a positive-class probability to a 2-class logit tensor for CE."""
        p = prob.clamp(1e-6, 1 - 1e-6)
        return torch.stack([torch.log(1 - p), torch.log(p)], dim=-1)


def train_meta(model: MetaFusion, data, device: str = "cpu"):
    """Train the meta-learner, eq (18)-(20).

    `data` provides, per batch, a dict with keys:
        p (n,J), z (n,J,dz), d (n,J), y (n,),
        cf_probs: list of fused-view probability tensors (optional),
        paired: (prob_a, prob_b) tensors (optional),
        s: nuisance variable (n, ...) (optional).
    `data` is any iterable of such dicts; `data.epochs`/`.reset(epoch)` optional.
    """
    model.to(device).train()
    opt = torch.optim.AdamW(model.parameters(), lr=model.cfg.lr)
    history = []
    for epoch in range(model.cfg.epochs):
        if hasattr(data, "reset"):
            data.reset(epoch)
        ep_loss = 0.0
        n_batches = 0
        for batch in data:
            p = batch["p"].to(device)
            z = batch["z"].to(device)
            d = batch["d"].to(device)
            y = batch["y"].to(device)
            fused_p, gates = model(p, z, d)
            logits = model.to_logits(fused_p)
            loss, comps = meta_objective(
                logits, y, gates, model.cfg.weights, epoch,
                fused_prob=fused_p,
                cf_probs=batch.get("cf_probs"),
                paired=batch.get("paired"),
                nuisance_s=batch.get("s"),
            )
            opt.zero_grad()
            loss.backward()
            opt.step()
            ep_loss += float(loss.detach())
            n_batches += 1
        history.append({"epoch": epoch, "loss": ep_loss / max(n_batches, 1)})
    return history
