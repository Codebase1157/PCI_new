"""Tier 3 — counterfactual-consistent stacked meta-fusion (eq 14-20)."""
from .oof import OOFAssignment, build_oof_predictions, stack_level1
from .disagreement import (
    disagreement,
    disagreement_batch,
    pairwise_disagreement,
    yule_q,
)
from .gating import GatingNetwork, build_u, fuse
from .meta_learner import MetaConfig, MetaFusion, train_meta

__all__ = [
    "OOFAssignment", "build_oof_predictions", "stack_level1",
    "disagreement", "disagreement_batch", "pairwise_disagreement", "yule_q",
    "GatingNetwork", "build_u", "fuse",
    "MetaFusion", "MetaConfig", "train_meta",
]
