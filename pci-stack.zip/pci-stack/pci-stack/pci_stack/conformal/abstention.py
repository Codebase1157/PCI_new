r"""Disagreement-triggered abstention, eq (25).

    abstain(x) = 1{ |C_alpha(x)| > 1  OR  max_j |p_j(x) - p(x)| > kappa }           (25)

The layer abstains when the prediction set is ambiguous *and* when the base learners
disagree with the fused score by more than a calibrated margin — a rule with no
counterpart in single-model conformal pipelines. The margin kappa is the (1 - delta)
quantile of max_j |p_j(x) - p(x)| on the calibration split under a fixed referral
budget delta, giving kappa = 0.15 at delta = 0.10.
"""
from __future__ import annotations

import numpy as np


def calibrate_margin(learner_probs: np.ndarray, fused_prob: np.ndarray,
                     delta: float = 0.10) -> float:
    r"""kappa = (1 - delta)-quantile of max_j |p_j(x) - p(x)| on calibration data.
        learner_probs : (n, J) per-learner positive-class probabilities
        fused_prob    : (n,)   fused positive-class probability
    """
    lp = np.asarray(learner_probs, dtype=float)
    fp = np.asarray(fused_prob, dtype=float)[:, None]
    max_disagreement = np.abs(lp - fp).max(axis=1)
    return float(np.quantile(max_disagreement, 1 - delta))


def max_disagreement(learner_probs: np.ndarray, fused_prob: np.ndarray) -> np.ndarray:
    lp = np.asarray(learner_probs, dtype=float)
    fp = np.asarray(fused_prob, dtype=float)[:, None]
    return np.abs(lp - fp).max(axis=1)


def abstain(pred_sets, learner_probs: np.ndarray, fused_prob: np.ndarray,
            kappa: float = 0.15) -> np.ndarray:
    r"""eq (25). Returns a boolean (n,) abstention mask."""
    sizes = np.array([len(s) for s in pred_sets])
    md = max_disagreement(learner_probs, fused_prob)
    return (sizes > 1) | (md > kappa)
