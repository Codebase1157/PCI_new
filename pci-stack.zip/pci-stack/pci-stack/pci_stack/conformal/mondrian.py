r"""Mondrian (group-conditional) calibration, eq (22), with optional shift weighting.

A separate quantile is estimated for each tone-by-domain cell so coverage is equalized
across cells rather than only on average:

    q_{tau,d} = Quantile( { s(x_i, y_i) : i in I_{tau,d} };
                          ceil((n_{tau,d} + 1)(1 - alpha)) / n_{tau,d} )             (22)

Cells with fewer than `min_cell_count` scores are pooled with the adjacent tone bin of
the same modality before the quantile is taken (Table S3). Under covariate shift the
empirical distribution of calibration scores is replaced by its self-normalized
weighted counterpart (eq 23 weights), giving the threshold of [48].
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..constants import TONE_BINS
from .shift import self_normalized_weights

# tone-bin pooling order: dark -> intermediate, light -> intermediate
_ADJACENT = {"dark": "intermediate", "light": "intermediate", "intermediate": "intermediate"}


@dataclass
class MondrianCalibrator:
    alpha: float = 0.10
    min_cell_count: int = 50
    cells: dict[tuple[str, str], np.ndarray] = field(default_factory=dict)
    thresholds: dict[tuple[str, str], float] = field(default_factory=dict)
    pooled_into: dict[tuple[str, str], tuple[str, str]] = field(default_factory=dict)

    # ---- fit ---------------------------------------------------------------- #
    def fit(self, scores: np.ndarray, tone: np.ndarray, domain: np.ndarray,
            weights: np.ndarray | None = None) -> "MondrianCalibrator":
        """Collect per-cell calibration scores, pool thin cells, store thresholds."""
        scores = np.asarray(scores, dtype=float)
        tone = np.asarray(tone)
        domain = np.asarray(domain)
        w = np.ones_like(scores) if weights is None else np.asarray(weights, float)

        # gather raw cells
        raw: dict[tuple[str, str], list[int]] = {}
        for i in range(len(scores)):
            raw.setdefault((str(tone[i]), str(domain[i])), []).append(i)

        # pool thin cells into the adjacent tone bin of the same modality
        pooled: dict[tuple[str, str], list[int]] = {}
        for (t, d), idx in raw.items():
            if len(idx) >= self.min_cell_count:
                pooled.setdefault((t, d), []).extend(idx)
            else:
                tgt = (_ADJACENT.get(t, "intermediate"), d)
                self.pooled_into[(t, d)] = tgt
                pooled.setdefault(tgt, []).extend(idx)

        for cell, idx in pooled.items():
            idx = np.array(idx)
            s = scores[idx]
            cw = w[idx]
            self.cells[cell] = s
            self.thresholds[cell] = _weighted_conformal_quantile(
                s, cw, self.alpha, test_weight=1.0)
        return self

    def _resolve(self, tone: str, domain: str) -> tuple[str, str]:
        cell = (str(tone), str(domain))
        if cell in self.thresholds:
            return cell
        if cell in self.pooled_into and self.pooled_into[cell] in self.thresholds:
            return self.pooled_into[cell]
        # fall back to intermediate tone, same modality, then any cell of that domain
        alt = (_ADJACENT.get(str(tone), "intermediate"), str(domain))
        if alt in self.thresholds:
            return alt
        same_domain = [c for c in self.thresholds if c[1] == str(domain)]
        if same_domain:
            return same_domain[0]
        return next(iter(self.thresholds))

    def threshold(self, tone: str, domain: str,
                  weights: np.ndarray | None = None,
                  test_weight: float = 1.0) -> float:
        """Return q_{tau,d}. If per-test shift weights are given, recompute the
        weighted quantile for this cell on the fly (eq 23 reweighting)."""
        cell = self._resolve(tone, domain)
        if weights is None:
            return self.thresholds[cell]
        return _weighted_conformal_quantile(self.cells[cell], weights, self.alpha,
                                            test_weight=test_weight)

    def pooled_target_threshold(self, tone: str, weights: np.ndarray | None = None,
                                test_weight: float = 1.0) -> float:
        """For an unseen target domain: pool scores across modalities within the tone
        bin and take the (weighted) quantile (Section 4.5, point 2)."""
        idx_scores = [s for (t, _d), s in self.cells.items() if t == str(tone)]
        if not idx_scores:
            idx_scores = list(self.cells.values())
        s = np.concatenate(idx_scores)
        w = np.ones_like(s) if weights is None else np.asarray(weights, float)
        if len(w) != len(s):
            w = np.ones_like(s)
        return _weighted_conformal_quantile(s, w, self.alpha, test_weight=test_weight)

    def occupancy(self) -> dict[tuple[str, str], int]:
        return {c: int(len(s)) for c, s in self.cells.items()}


def _weighted_conformal_quantile(scores: np.ndarray, weights: np.ndarray,
                                 alpha: float, test_weight: float = 1.0) -> float:
    r"""Smallest q with sum_i w̃_i 1{s_i <= q} >= 1 - alpha, using the self-normalized
    weights of [48] (eq 22-23). With uniform weights this reduces to the standard
    split-conformal quantile ceil((n+1)(1-alpha))/n."""
    scores = np.asarray(scores, dtype=float)
    n = len(scores)
    if n == 0:
        return 1.0
    w_tilde = self_normalized_weights(np.asarray(weights, float), test_weight)
    order = np.argsort(scores, kind="mergesort")
    s_sorted = scores[order]
    cum = np.cumsum(w_tilde[order])
    # first score whose cumulative self-normalized weight reaches 1 - alpha
    target = 1 - alpha
    hit = np.searchsorted(cum, target, side="left")
    if hit >= n:
        return float(s_sorted[-1])
    return float(s_sorted[hit])
