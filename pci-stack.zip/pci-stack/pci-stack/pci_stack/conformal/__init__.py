"""Tier 4 — shift-aware group-conditional conformal layer (eq 21-25)."""
from .nonconformity import all_label_scores, nonconformity
from .mondrian import MondrianCalibrator
from .shift import DomainClassifierStub, density_ratio_weights, self_normalized_weights
from .predict_set import prediction_set
from .abstention import abstain, calibrate_margin, max_disagreement

__all__ = [
    "nonconformity", "all_label_scores",
    "MondrianCalibrator",
    "density_ratio_weights", "self_normalized_weights", "DomainClassifierStub",
    "prediction_set",
    "abstain", "calibrate_margin", "max_disagreement",
]
