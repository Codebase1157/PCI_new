r"""Covariate-shift likelihood-ratio reweighting, eq (23).

    w(x) = dP_tgt/dP_src (x) = [ rho(x) / (1 - rho(x)) ] * [ (1 - pi_tgt) / pi_tgt ]  (23)

rho is the output of a domain classifier trained on training-domain images alone, with
the held-out source as the target class; no DDI or SCIN image contributes to the
density-ratio estimation. The weights enter the Mondrian quantile (eq 22) through the
self-normalized form of [48].
"""
from __future__ import annotations

import numpy as np


def density_ratio_weights(rho: np.ndarray, pi_tgt: float) -> np.ndarray:
    r"""eq (23). `rho` is the domain-classifier probability that x belongs to the
    target domain; `pi_tgt` is the target-class prior used when training it."""
    rho = np.clip(np.asarray(rho, dtype=float), 1e-6, 1 - 1e-6)
    pi_tgt = float(np.clip(pi_tgt, 1e-6, 1 - 1e-6))
    return (rho / (1 - rho)) * ((1 - pi_tgt) / pi_tgt)


def self_normalized_weights(cal_w: np.ndarray, test_w: float) -> np.ndarray:
    r"""Self-normalized calibration weights w̃_i of [48]:
        w̃_i = w(x_i) / ( sum_j w(x_j) + w(x_test) ).
    Returns the normalized weights over the calibration cell (length = len(cal_w))."""
    cal_w = np.asarray(cal_w, dtype=float)
    denom = cal_w.sum() + float(test_w)
    return cal_w / denom if denom > 0 else np.full_like(cal_w, 1.0 / len(cal_w))


class DomainClassifierStub:
    """Placeholder for the fitted domain classifier supplying rho (eq 23).

    The real classifier (configs.conformal.shift.domain_classifier) is an MLP trained
    on training-domain images with the held-out source as the positive class. At
    evaluation it outputs rho(x). This stub lets the conformal layer be unit-tested
    without a trained model; swap in the real `predict_proba`.
    """

    def __init__(self, predict_proba=None, pi_tgt: float = 0.5):
        self._predict = predict_proba
        self.pi_tgt = pi_tgt

    def rho(self, x) -> np.ndarray:
        if self._predict is None:
            raise RuntimeError("no fitted domain classifier; provide predict_proba")
        return np.asarray(self._predict(x), dtype=float)

    def weights(self, x) -> np.ndarray:
        return density_ratio_weights(self.rho(x), self.pi_tgt)
