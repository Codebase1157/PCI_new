r"""Prediction-set construction, eq (24).

    C_alpha(x) = { y in Y : s(x, y) <= q_{tau(x), d(x)}^w }                          (24)

Group membership tau(x) uses the estimated ITA bin of Section 3.2 (no Fitzpatrick
label exists at deployment); d(x) is the acquisition modality. For an unseen target
domain the threshold is the pooled, shift-reweighted quantile of eq (22)-(23).
"""
from __future__ import annotations

import numpy as np

from .mondrian import MondrianCalibrator
from .nonconformity import all_label_scores


def prediction_set(prob_matrix: np.ndarray, tone: np.ndarray, domain: np.ndarray,
                   calibrator: MondrianCalibrator,
                   shift_weights=None, labels=None,
                   unseen_target: bool = False) -> list[set]:
    r"""Build C_alpha(x) for every row of `prob_matrix` (n, C), eq (24).

    Parameters
    ----------
    tone, domain : (n,) cell coordinates (estimated ITA bin, acquisition modality).
    shift_weights : optional dict cell -> calibration-weight array for eq (23).
    unseen_target : if True, use the pooled cross-modality threshold per tone bin.
    """
    P = np.asarray(prob_matrix, dtype=float)
    n, C = P.shape
    labels = list(range(C)) if labels is None else labels
    S = all_label_scores(P)                      # (n, C)
    sets: list[set] = []
    for i in range(n):
        t, d = str(tone[i]), str(domain[i])
        w = None if shift_weights is None else shift_weights.get((t, d))
        if unseen_target:
            q = calibrator.pooled_target_threshold(t, weights=w)
        else:
            q = calibrator.threshold(t, d, weights=w)
        sets.append({labels[y] for y in range(C) if S[i, y] <= q})
    return sets
