r"""Non-conformity score, eq (21).

    s(x, y) = 1 - p_y(x)

The complement of the fused probability assigned to the candidate label.
"""
from __future__ import annotations

import numpy as np


def nonconformity(prob_matrix: np.ndarray, label: int | np.ndarray) -> np.ndarray:
    r"""eq (21). `prob_matrix` is (n, C) class probabilities; `label` an int or (n,).
    Returns the score s(x, y) for the given label(s)."""
    P = np.asarray(prob_matrix, dtype=float)
    if np.isscalar(label):
        return 1.0 - P[:, int(label)]
    label = np.asarray(label, dtype=int)
    return 1.0 - P[np.arange(len(P)), label]


def all_label_scores(prob_matrix: np.ndarray) -> np.ndarray:
    """s(x, y) for every candidate label y, returning (n, C)."""
    return 1.0 - np.asarray(prob_matrix, dtype=float)
