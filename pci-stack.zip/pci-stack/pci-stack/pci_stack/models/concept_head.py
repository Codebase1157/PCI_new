r"""Clinical-concept head (Section 4.3): a linear layer producing the 22 concept
logits consumed by the masked concept BCE of eq (11). Attached to M3.
"""
from __future__ import annotations

import torch.nn as nn


class ConceptHead(nn.Module):
    def __init__(self, in_dim: int, num_concepts: int = 22):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(in_dim, in_dim // 2), nn.GELU(),
            nn.Linear(in_dim // 2, num_concepts),
        )

    def forward(self, feat):
        return self.proj(feat)        # (B, 22) pre-sigmoid concept logits
