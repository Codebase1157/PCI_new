r"""Backbone wrappers for the learner zoo (Section 4.3).

    M1, M3 : PanDerm ViT-L   (shared frozen backbone pass)
    M2     : DINOv2-L
    M4     : Swin-B

Each backbone is loaded frozen; LoRA adapters (models/lora.py) supply the trainable
parameters. Weights are NOT vendored (see LICENSE-PANDERM-NOTE.md / docs/data_access.md).
A `SyntheticBackbone` is provided so the architecture, training loop and audit can be
exercised end-to-end without any downloaded weights (used by the synthetic demo/tests).
"""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn


@dataclass
class BackboneSpec:
    name: str
    timm_id: str
    feature_dim: int
    weights: str          # how to obtain (research license / hub)
    reshape_hw: tuple[int, int] | None = None   # spatial grid for CAM reshape


BACKBONES = {
    "panderm_vit_l": BackboneSpec("panderm_vit_l", "vit_large_patch14_dinov2",
                                  1024, "PanDerm research license [11]", (16, 16)),
    "dinov2_l": BackboneSpec("dinov2_l", "vit_large_patch14_dinov2",
                             1024, "facebookresearch/dinov2 (Apache-2.0)", (16, 16)),
    "swin_b": BackboneSpec("swin_b", "swin_base_patch4_window12_384",
                           1024, "microsoft/Swin (MIT) via timm", (12, 12)),
}


class TimmBackbone(nn.Module):
    """Wrap a timm model as a frozen feature extractor returning pooled features and,
    optionally, the final spatial token map for Grad-CAM."""

    def __init__(self, spec: BackboneSpec, pretrained: bool = True,
                 weights_path: str | None = None):
        super().__init__()
        import timm

        self.spec = spec
        self.model = timm.create_model(spec.timm_id, pretrained=pretrained,
                                       num_classes=0)
        if weights_path:
            sd = torch.load(weights_path, map_location="cpu")
            self.model.load_state_dict(sd, strict=False)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.feature_dim = spec.feature_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)                 # pooled (B, feature_dim)

    def forward_tokens(self, x: torch.Tensor) -> torch.Tensor:
        """Return token features (B, N, C) for CAM reshaping, when supported."""
        if hasattr(self.model, "forward_features"):
            return self.model.forward_features(x)
        return self.forward(x).unsqueeze(1)


class SyntheticBackbone(nn.Module):
    """A tiny CNN standing in for a frozen foundation backbone, so the full framework
    runs without any downloaded weights. Not used in reported experiments."""

    def __init__(self, feature_dim: int = 256, grid: int = 8):
        super().__init__()
        self.feature_dim = feature_dim
        self.grid = grid
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, 3, 2, 1), nn.GELU(),
            nn.Conv2d(32, 64, 3, 2, 1), nn.GELU(),
            nn.Conv2d(64, feature_dim, 3, 2, 1), nn.GELU(),
            nn.AdaptiveAvgPool2d(grid),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self._last_map: torch.Tensor | None = None

    def forward(self, x):
        fmap = self.stem(x)                  # (B, C, grid, grid)
        self._last_map = fmap
        return self.pool(fmap).flatten(1)    # (B, C)

    def forward_tokens(self, x):
        fmap = self.stem(x)
        self._last_map = fmap
        b, c, h, w = fmap.shape
        return fmap.flatten(2).transpose(1, 2)   # (B, H*W, C)


def build_backbone(name: str, pretrained: bool = True, synthetic: bool = False,
                   weights_path: str | None = None) -> nn.Module:
    if synthetic:
        return SyntheticBackbone()
    spec = BACKBONES[name]
    return TimmBackbone(spec, pretrained=pretrained, weights_path=weights_path)
