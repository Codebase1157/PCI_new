r"""Gradient reversal layer for adversarial nuisance invariance (eq 12, M4).

Forward is the identity; backward multiplies the gradient by -lambda. Placed between
the encoder and the nuisance discriminator so that minimizing the discriminator's loss
*maximizes* it with respect to the encoder, pushing nuisance information out of z.
`lambda` follows the DANN schedule, ramping 0 -> 1 over training.
"""
from __future__ import annotations

import torch
from torch.autograd import Function


class _GradReverse(Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.lambd, None


def grad_reverse(x: torch.Tensor, lambd: float = 1.0) -> torch.Tensor:
    return _GradReverse.apply(x, lambd)


def dann_lambda(step: int, total_steps: int, gamma: float = 10.0) -> float:
    """DANN schedule: 2 / (1 + exp(-gamma * p)) - 1, p = step / total."""
    p = step / max(total_steps, 1)
    return float(2.0 / (1.0 + torch.exp(torch.tensor(-gamma * p))) - 1.0)


class GradientReversal(torch.nn.Module):
    def __init__(self, lambd: float = 1.0):
        super().__init__()
        self.lambd = lambd

    def set_lambda(self, lambd: float) -> None:
        self.lambd = lambd

    def forward(self, x):
        return grad_reverse(x, self.lambd)
