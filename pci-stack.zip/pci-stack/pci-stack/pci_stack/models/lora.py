r"""Low-rank adapters (LoRA) [18].

A frozen linear layer y = W x + b is adapted as

    y = W x + b + (alpha / r) * B (A x),   A in R^{r x in}, B in R^{out x r}

with A, B the only trainable parameters. Only ~1.7% of the backbone stack is updated
(Section 4.3); rank r = 16 (Table S1). `inject_lora` wraps the attention projection
layers of a timm/torch backbone in place.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn


class LoRALinear(nn.Module):
    """A frozen base Linear with an additive low-rank update."""

    def __init__(self, base: nn.Linear, r: int = 16, alpha: int = 16,
                 dropout: float = 0.05):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)
        self.r = r
        self.scaling = alpha / r
        self.lora_A = nn.Parameter(torch.zeros(r, base.in_features))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, r))
        self.dropout = nn.Dropout(dropout)
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)                 # start as identity (no change)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.base(x)
        update = self.dropout(x) @ self.lora_A.t() @ self.lora_B.t()
        return out + self.scaling * update


def inject_lora(module: nn.Module, targets=("qkv", "proj"), r: int = 16,
                alpha: int = 16, dropout: float = 0.05) -> int:
    """Replace matching nn.Linear submodules with LoRALinear in place.

    Returns the number of layers adapted. Matching is by attribute name containing any
    of `targets` (covers timm ViT/Swin attention `qkv`/`proj` and DINOv2 blocks).
    """
    count = 0
    for name, child in list(module.named_children()):
        if isinstance(child, nn.Linear) and any(t in name for t in targets):
            setattr(module, name, LoRALinear(child, r=r, alpha=alpha, dropout=dropout))
            count += 1
        else:
            count += inject_lora(child, targets, r, alpha, dropout)
    return count


def mark_only_lora_trainable(model: nn.Module) -> None:
    for n, p in model.named_parameters():
        p.requires_grad_("lora_" in n or n.endswith(("head.weight", "head.bias")))


def count_trainable(model: nn.Module) -> tuple[int, int]:
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    return trainable, total
