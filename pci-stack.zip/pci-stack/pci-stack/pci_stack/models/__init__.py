"""Tier 2 — backbones, LoRA, GRL, concept head, and the four-learner zoo."""
from .lora import LoRALinear, count_trainable, inject_lora, mark_only_lora_trainable
from .grl import GradientReversal, dann_lambda, grad_reverse
from .concept_head import ConceptHead
from .backbones import BACKBONES, SyntheticBackbone, TimmBackbone, build_backbone
from .learner import BaseLearner, LearnerSpec
from .zoo import ZOO_SPECS, LearnerZoo

__all__ = [
    "LoRALinear", "inject_lora", "mark_only_lora_trainable", "count_trainable",
    "grad_reverse", "GradientReversal", "dann_lambda",
    "ConceptHead",
    "build_backbone", "TimmBackbone", "SyntheticBackbone", "BACKBONES",
    "BaseLearner", "LearnerSpec",
    "LearnerZoo", "ZOO_SPECS",
]
