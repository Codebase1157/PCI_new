r"""A single counterfactual-diverse base learner (Section 4.3).

A frozen backbone + LoRA adapters + a classification head, plus the optional pieces its
invariance contract needs: a low-dimensional representation projection (for the HSIC
dependence penalty and the level-1 feature), a concept head (M3) and a gradient-reversed
nuisance discriminator (M4). The learner exposes everything the per-learner objective
(eq 13) and the meta-fusion level-1 features (eq 16) require.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import torch
import torch.nn as nn

from ..losses.adversarial import NuisanceDiscriminator
from .backbones import build_backbone
from .concept_head import ConceptHead
from .grl import grad_reverse
from .lora import count_trainable, inject_lora


@dataclass
class LearnerSpec:
    name: str
    backbone: str
    contract: str
    counterfactual_views: list[str]
    active_terms: list[str] = field(default_factory=lambda: ["ce"])
    num_classes: int = 2
    num_concepts: int = 22
    num_nuisance: int = 3                 # tone bins or domains
    repr_dim: int = 32
    lora_rank: int = 16
    lora_alpha: int = 16
    lora_dropout: float = 0.05
    synthetic: bool = False


class BaseLearner(nn.Module):
    def __init__(self, spec: LearnerSpec, backbone: nn.Module | None = None,
                 weights_path: str | None = None):
        super().__init__()
        self.spec = spec
        self.backbone = backbone or build_backbone(
            spec.backbone, synthetic=spec.synthetic, weights_path=weights_path)
        # adapt only the attention projections
        if not spec.synthetic:
            inject_lora(self.backbone, r=spec.lora_rank, alpha=spec.lora_alpha,
                        dropout=spec.lora_dropout)
        d = self.backbone.feature_dim
        self.classifier = nn.Linear(d, spec.num_classes)
        self.repr_proj = nn.Linear(d, spec.repr_dim)     # z_j projection (eq 16)
        self.concept_head = (ConceptHead(d, spec.num_concepts)
                             if "con" in spec.active_terms else None)
        self.discriminator = (NuisanceDiscriminator(spec.repr_dim, spec.num_nuisance)
                              if "adv" in spec.active_terms else None)

    # ---- forward ------------------------------------------------------------ #
    def features(self, x: torch.Tensor) -> torch.Tensor:
        return self.backbone(x)

    def forward(self, x: torch.Tensor, grl_lambda: float = 1.0) -> dict:
        feat = self.features(x)
        logits = self.classifier(feat)
        z = self.repr_proj(feat)
        out = {"logits": logits, "feat": feat, "z": z,
               "prob": torch.softmax(logits, dim=-1)[:, 1]}
        if self.concept_head is not None:
            out["concept_logits"] = self.concept_head(feat)
        if self.discriminator is not None:
            out["nuisance_logits"] = self.discriminator(grad_reverse(z, grl_lambda))
        return out

    def level1_features(self, x: torch.Tensor):
        """(prob, z) for the meta-fusion level-1 vector u(x), eq (16)."""
        o = self.forward(x)
        return o["prob"].detach(), o["z"].detach()

    def trainable_report(self):
        tr, tot = count_trainable(self)
        return {"learner": self.spec.name, "trainable": tr, "total": tot,
                "percent": round(100 * tr / max(tot, 1), 2)}
