r"""The four-learner counterfactual-diverse zoo (Section 4.3).

M1 (tone), M2 (acquisition), M3 (concept), M4 (joint). M1 and M3 share a single frozen
PanDerm ViT-L backbone pass (three backbone evaluations per image, not four — Table S8),
realized here by handing the same backbone object to both learners.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from ..constants import CF_FOURIER, CF_PHOTOMETRIC, CF_TONE
from .backbones import build_backbone
from .learner import BaseLearner, LearnerSpec

# the four contracts (mirrors configs/learners/*.yaml)
ZOO_SPECS = {
    "M1": LearnerSpec("M1", "panderm_vit_l", "tone_invariance",
                      [CF_TONE], active_terms=["ce", "cf", "dep"]),
    "M2": LearnerSpec("M2", "dinov2_l", "acquisition_invariance",
                      [CF_FOURIER, CF_PHOTOMETRIC], active_terms=["ce", "cf", "dep"]),
    "M3": LearnerSpec("M3", "panderm_vit_l", "concept_invariance",
                      [CF_TONE, CF_FOURIER], active_terms=["ce", "cf", "dep", "con"]),
    "M4": LearnerSpec("M4", "swin_b", "joint_invariance",
                      [CF_TONE, CF_FOURIER, CF_PHOTOMETRIC],
                      active_terms=["ce", "cf", "dep", "adv"]),
}


class LearnerZoo(nn.Module):
    def __init__(self, synthetic: bool = False, weights: dict | None = None):
        super().__init__()
        weights = weights or {}
        specs = {k: _with_synth(v, synthetic) for k, v in ZOO_SPECS.items()}

        # shared PanDerm backbone for M1 and M3 (Table S8)
        shared = build_backbone("panderm_vit_l", synthetic=synthetic,
                                weights_path=weights.get("panderm_vit_l"))
        self.M1 = BaseLearner(specs["M1"], backbone=shared)
        self.M3 = BaseLearner(specs["M3"], backbone=shared)
        self.M2 = BaseLearner(specs["M2"],
                              weights_path=weights.get("dinov2_l"))
        self.M4 = BaseLearner(specs["M4"],
                              weights_path=weights.get("swin_b"))
        self.learners = nn.ModuleDict({"M1": self.M1, "M2": self.M2,
                                       "M3": self.M3, "M4": self.M4})
        self.order = ["M1", "M2", "M3", "M4"]

    def forward(self, x: torch.Tensor) -> dict:
        return {name: self.learners[name](x) for name in self.order}

    def probs(self, x: torch.Tensor) -> torch.Tensor:
        """(B, J) positive-class probabilities, in zoo order."""
        outs = self.forward(x)
        return torch.stack([outs[n]["prob"] for n in self.order], dim=1)

    def level1(self, x: torch.Tensor):
        """Return stacked (prob (B,J), z (B,J,dz)) for the meta-fusion."""
        p, z = [], []
        for n in self.order:
            pr, zz = self.learners[n].level1_features(x)
            p.append(pr)
            z.append(zz)
        return torch.stack(p, dim=1), torch.stack(z, dim=1)

    def trainable_report(self):
        rows = [self.learners[n].trainable_report() for n in self.order]
        tr = sum(r["trainable"] for r in rows)
        tot = sum(r["total"] for r in rows)
        rows.append({"learner": "ZOO total", "trainable": tr, "total": tot,
                     "percent": round(100 * tr / max(tot, 1), 2)})
        return rows


def _with_synth(spec: LearnerSpec, synthetic: bool) -> LearnerSpec:
    spec.synthetic = synthetic
    return spec
