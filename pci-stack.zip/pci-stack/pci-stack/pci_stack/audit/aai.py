r"""Attribution Agreement Index, eq (29).

    AAI(x) = 2 / (J(J-1)) * sum_{j<l} |B_j ∩ B_l| / |B_j ∪ B_l|,
    B_j = 1{ A_j(x) >= theta }                                                       (29)

The mean pairwise Jaccard overlap between thresholded per-learner maps — it answers
whether the committee reads the same evidence. theta is relative to each map's max
(default 0.5, Table S1).
"""
from __future__ import annotations

from itertools import combinations

import numpy as np


def threshold_map(cam: np.ndarray, theta: float = 0.5) -> np.ndarray:
    """B_j = 1{ A_j >= theta * max(A_j) }."""
    cam = np.asarray(cam, dtype=float)
    return (cam >= theta * (cam.max() + 1e-8)).astype(bool)


def jaccard(a: np.ndarray, b: np.ndarray) -> float:
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter / union) if union else 1.0


def attribution_agreement_index(learner_cams: list[np.ndarray],
                                theta: float = 0.5) -> float:
    r"""eq (29). Mean pairwise Jaccard over J thresholded per-learner maps."""
    J = len(learner_cams)
    if J < 2:
        return float("nan")
    masks = [threshold_map(c, theta) for c in learner_cams]
    vals = [jaccard(masks[j], masks[l]) for j, l in combinations(range(J), 2)]
    return float(np.mean(vals))
