r"""Faithfulness diagnostics complementing AAI/CAS (Table 7, Section 6.8):
insertion and deletion area, surrogate fidelity (reported by the surrogate) and the
top-superpixel lesion overlap.

Insertion: progressively reveal the most salient pixels and track the model score;
higher area is better. Deletion: progressively remove them; lower area is better.
"""
from __future__ import annotations

import numpy as np

# np.trapz was renamed to np.trapezoid in NumPy 2.0
_trapz = getattr(np, "trapezoid", getattr(np, "trapz", None))


def _ordered_pixels(cam: np.ndarray) -> np.ndarray:
    """Pixel indices sorted by descending saliency."""
    flat = cam.ravel()
    return np.argsort(flat)[::-1]


def insertion_deletion(image: np.ndarray, cam: np.ndarray, predict_fn,
                       steps: int = 50, baseline: str = "blur") -> dict:
    r"""Compute insertion and deletion curves and their areas (AUC).

    `predict_fn(img) -> float` returns the fused positive-class probability.
    insertion starts from a baseline and reveals salient pixels; deletion starts from
    the image and removes them.
    """
    h, w = cam.shape
    n = h * w
    order = _ordered_pixels(cam)
    if baseline == "blur":
        try:
            import cv2

            base = cv2.GaussianBlur(image, (0, 0), 11)
        except Exception:
            base = np.full_like(image, image.mean())
    else:
        base = np.zeros_like(image)

    chunk = max(1, n // steps)
    ins_scores, del_scores = [], []
    ins_img = base.copy()
    del_img = image.copy()
    img_flat_src = image.reshape(n, -1)
    base_flat = base.reshape(n, -1)
    ins_flat = ins_img.reshape(n, -1)
    del_flat = del_img.reshape(n, -1)

    for s in range(0, n, chunk):
        idx = order[s:s + chunk]
        ins_flat[idx] = img_flat_src[idx]      # reveal salient pixels
        del_flat[idx] = base_flat[idx]         # remove salient pixels
        ins_scores.append(float(predict_fn(ins_flat.reshape(image.shape))))
        del_scores.append(float(predict_fn(del_flat.reshape(image.shape))))

    ins_auc = float(_trapz(ins_scores) / len(ins_scores))
    del_auc = float(_trapz(del_scores) / len(del_scores))
    return {"insertion": ins_auc, "deletion": del_auc,
            "insertion_curve": ins_scores, "deletion_curve": del_scores}
