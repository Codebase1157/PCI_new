r"""Per-learner Grad-CAM, eq (26).

    A_j(x) = ReLU( sum_k alpha_k^j F_k^j(x) ),
    alpha_k^j = 1/(H W) sum_{u,v} d p_j(x) / d F_{k,uv}^j                            (26)

A gradient-weighted class-activation map at the final spatial layer [40]. A lightweight
self-contained implementation (no external grad-cam dependency required); it hooks the
target layer's activations and gradients.
"""
from __future__ import annotations

import numpy as np

try:
    import torch
    import torch.nn.functional as F
except Exception:  # pragma: no cover
    torch = None


class GradCAM:
    """Grad-CAM for a single learner. `target_layer` is the final conv/spatial module.

    For ViT/Swin backbones, pass the module whose output is reshaped to (B, C, H, W);
    a `reshape_transform` callable converts token sequences to spatial maps.
    """

    def __init__(self, model, target_layer, reshape_transform=None):
        if torch is None:
            raise ImportError("GradCAM requires torch")
        self.model = model
        self.target_layer = target_layer
        self.reshape_transform = reshape_transform
        self._act = None
        self._grad = None
        self._h1 = target_layer.register_forward_hook(self._save_act)
        self._h2 = target_layer.register_full_backward_hook(self._save_grad)

    def _save_act(self, _m, _i, out):
        self._act = out

    def _save_grad(self, _m, _gin, gout):
        self._grad = gout[0]

    def _to_spatial(self, t):
        return self.reshape_transform(t) if self.reshape_transform else t

    def __call__(self, x: "torch.Tensor", class_idx: int | None = None) -> np.ndarray:
        """Return the (H, W) CAM for the batch's first image, normalized to [0, 1]."""
        self.model.zero_grad()
        logits = self.model(x)
        if class_idx is None:
            class_idx = int(logits.argmax(dim=-1)[0])
        score = logits[:, class_idx].sum()
        score.backward(retain_graph=True)

        act = self._to_spatial(self._act)              # (B, C, H, W)
        grad = self._to_spatial(self._grad)
        alpha = grad.mean(dim=(2, 3), keepdim=True)    # eq (26) channel weights
        cam = F.relu((alpha * act).sum(dim=1))         # (B, H, W)
        cam = cam[0].detach().cpu().numpy()
        cam = cam - cam.min()
        denom = cam.max() + 1e-8
        return cam / denom

    def close(self):
        self._h1.remove()
        self._h2.remove()


def vit_reshape_transform(height: int = 24, width: int = 24):
    """Reshape (B, 1 + H*W, C) ViT tokens to (B, C, H, W), dropping the CLS token."""
    def _fn(t):
        tokens = t[:, 1:, :]
        b, n, c = tokens.shape
        return tokens.reshape(b, height, width, c).permute(0, 3, 1, 2)
    return _fn
