r"""Local interpretable surrogate over superpixels, eq (28).

    xi(x) = argmin_{g in G} L(p, g, pi_x) + Omega(g),
    pi_x(v) = exp( -D(x, v)^2 / varsigma^2 )                                         (28)

A sparse linear surrogate is fitted over SLIC superpixels of the image for the fused
model, weighting perturbed samples by proximity to the original [41]. Self-contained
(no external `lime` dependency required): SLIC segmentation + weighted ridge/lasso.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

try:
    from skimage.segmentation import slic
except Exception:  # pragma: no cover
    slic = None

try:
    from sklearn.linear_model import Ridge
except Exception:  # pragma: no cover
    Ridge = None


@dataclass
class SurrogateResult:
    segments: np.ndarray            # (H, W) superpixel labels
    weights: np.ndarray             # per-superpixel surrogate coefficient
    intercept: float
    fidelity: float                 # R^2 of the surrogate on perturbed samples
    top_segments: np.ndarray        # indices of the most positive superpixels


def superpixels(image: np.ndarray, n_segments: int = 50) -> np.ndarray:
    if slic is not None:
        return slic(np.clip(image, 0, 1), n_segments=n_segments, start_label=0)
    # fallback: regular grid
    h, w = image.shape[:2]
    gh = gw = int(round(np.sqrt(n_segments)))
    ys = (np.arange(h) * gh // h)
    xs = (np.arange(w) * gw // w)
    return (ys[:, None] * gw + xs[None, :]).astype(int)


def fit_surrogate(image: np.ndarray, predict_fn, n_segments: int = 50,
                  n_samples: int = 300, kernel_width: float = 0.25,
                  seed: int = 2026) -> SurrogateResult:
    r"""Fit the surrogate of eq (28). `predict_fn(imgs) -> (m,)` returns the fused
    positive-class probability for a batch of masked images."""
    rng = np.random.default_rng(seed)
    seg = superpixels(image, n_segments)
    seg_ids = np.unique(seg)
    d = len(seg_ids)

    # binary masks over superpixels (1 = keep, 0 = occlude to mean colour)
    Z = rng.integers(0, 2, size=(n_samples, d))
    Z[0] = 1                                    # the original image is a sample
    mean_colour = image.reshape(-1, image.shape[-1]).mean(0)

    imgs = np.empty((n_samples,) + image.shape, dtype=float)
    for i in range(n_samples):
        masked = image.copy()
        off = seg_ids[Z[i] == 0]
        if len(off):
            m = np.isin(seg, off)
            masked[m] = mean_colour
        imgs[i] = masked
    y = np.asarray(predict_fn(imgs), dtype=float)

    # proximity weights pi_x, eq (28): distance in the masking space
    frac_on = Z.mean(axis=1)
    dist = 1.0 - frac_on                        # cosine-style distance to all-on
    pi = np.exp(-(dist ** 2) / (kernel_width ** 2))

    if Ridge is not None:
        reg = Ridge(alpha=1.0)
        reg.fit(Z, y, sample_weight=pi)
        coef, intercept = reg.coef_, float(reg.intercept_)
        pred = reg.predict(Z)
    else:
        # weighted least squares fallback
        W = np.diag(pi)
        A = np.hstack([Z, np.ones((n_samples, 1))])
        beta = np.linalg.lstsq(A.T @ W @ A, A.T @ W @ y, rcond=None)[0]
        coef, intercept = beta[:-1], float(beta[-1])
        pred = A @ beta

    ss_res = float((pi * (y - pred) ** 2).sum())
    ss_tot = float((pi * (y - np.average(y, weights=pi)) ** 2).sum()) + 1e-8
    fidelity = 1.0 - ss_res / ss_tot

    top = seg_ids[np.argsort(coef)[::-1]]
    return SurrogateResult(segments=seg, weights=coef, intercept=intercept,
                           fidelity=float(fidelity), top_segments=top)


def superpixel_hit(result: SurrogateResult, lesion_mask: np.ndarray,
                   top_k: int = 3) -> float:
    """Fraction of the top-k surrogate superpixels that overlap the lesion mask
    (the 'Hit' column of Table 7)."""
    lesion = np.asarray(lesion_mask) > 0
    hits = 0
    for sid in result.top_segments[:top_k]:
        region = result.segments == sid
        if (region & lesion).sum() / (region.sum() + 1e-8) > 0.5:
            hits += 1
    return float(hits / top_k)
