r"""Gated fused attribution, eq (27).

    A_fus(x) = sum_j g_j(x) * A_j(x) / || A_j(x) ||_inf                              (27)

The explanation of the fusion is the gate-weighted explanation of its experts, reusing
the same gating weights that produced the prediction. This is an *approximation*, not
the gradient attribution of the fused predictor: differentiating
p(x) = sum_j g_j(x) p_j(x) also yields terms p_j(x) d g_j/d x, which (27) omits by
treating the gating weights as constants (Section 4.6). The fused map is therefore a
gate-weighted composite of expert evidence; the audit statistics measure explanation
*consistency*, not causal or clinical validity.
"""
from __future__ import annotations

import numpy as np


def normalize_inf(cam: np.ndarray) -> np.ndarray:
    """Divide by the max (L-infinity) norm, eq (27)."""
    cam = np.asarray(cam, dtype=float)
    m = np.abs(cam).max() + 1e-8
    return cam / m


def fused_cam(learner_cams: list[np.ndarray], gates: np.ndarray) -> np.ndarray:
    r"""eq (27). `learner_cams` is a list of J (H, W) maps; `gates` is (J,) the gating
    weights for this image. Returns the fused (H, W) map, normalized to [0, 1]."""
    assert len(learner_cams) == len(gates), "one gate per learner map"
    H, W = learner_cams[0].shape
    out = np.zeros((H, W), dtype=float)
    for g, cam in zip(gates, learner_cams):
        out += float(g) * normalize_inf(cam)
    out = out - out.min()
    return out / (out.max() + 1e-8)
