r"""Counterfactual Attribution Stability, eq (30).

    CAS(x) = 1/|C(x)| sum_{x' in C(x)} <A_fus(x), A_fus(x')> / (||A_fus(x)||_2 ||A_fus(x')||_2)   (30)

The mean cosine similarity between the fused attribution map of an image and those of
its counterfactual views — it answers whether that evidence survives a change of tone
or device. Computed per tone group (tone counterfactuals) and overall (acquisition
counterfactuals), as in Table 7.
"""
from __future__ import annotations

import numpy as np


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    denom = (np.linalg.norm(a) * np.linalg.norm(b)) + 1e-8
    return float(np.dot(a, b) / denom)


def counterfactual_attribution_stability(fused_map: np.ndarray,
                                         cf_fused_maps: list[np.ndarray]) -> float:
    r"""eq (30). Mean cosine similarity of the fused map to its counterfactual-view
    fused maps."""
    if not cf_fused_maps:
        return float("nan")
    return float(np.mean([cosine(fused_map, m) for m in cf_fused_maps]))


def cas_by_group(records: list[dict]) -> dict:
    """Aggregate CAS per tone group / modality from a list of per-image records,
    each {'cas': float, 'tone': str, 'modality': str}. Returns nested means mirroring
    the Table 7 layout."""
    out: dict[str, dict[str, list]] = {"tone": {}, "modality": {}}
    for r in records:
        out["tone"].setdefault(r.get("tone", "na"), []).append(r["cas"])
        out["modality"].setdefault(r.get("modality", "na"), []).append(r["cas"])
    return {k: {g: float(np.nanmean(v)) for g, v in d.items()} for k, d in out.items()}
