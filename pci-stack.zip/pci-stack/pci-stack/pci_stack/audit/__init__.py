"""Tier 5 — explanation-audit package (eq 26-30).

Grad-CAM (26), gated fused CAM (27), LIME surrogate (28), the Attribution Agreement
Index (29) and Counterfactual Attribution Stability (30), plus insertion/deletion
faithfulness. The CAM-level pieces need torch; AAI, CAS, the surrogate and
faithfulness are numpy-only and run anywhere.
"""
from .fused_cam import fused_cam, normalize_inf
from .lime_surrogate import SurrogateResult, fit_surrogate, superpixel_hit, superpixels
from .aai import attribution_agreement_index, jaccard, threshold_map
from .cas import cas_by_group, cosine, counterfactual_attribution_stability
from .faithfulness import insertion_deletion

__all__ = [
    "fused_cam", "normalize_inf",
    "fit_surrogate", "SurrogateResult", "superpixels", "superpixel_hit",
    "attribution_agreement_index", "threshold_map", "jaccard",
    "counterfactual_attribution_stability", "cas_by_group", "cosine",
    "insertion_deletion",
]

# GradCAM imported lazily to avoid a hard torch dependency at import time.
def __getattr__(name):  # pragma: no cover
    if name in ("GradCAM", "vit_reshape_transform"):
        from . import gradcam
        return getattr(gradcam, name)
    raise AttributeError(name)
