"""Tier 1 — physics-guided counterfactual engine (Section 4.2, eq 3-8)."""
from .engine import CounterfactualEngine, EngineConfig
from .ita import estimate_ita, ita_category, ita_from_lab
from .reflectance import ChromophoreMaps, decompose, render
from .tone_cf import (
    ToneCFConfig,
    lesion_iou,
    render_tone,
    solve_offset,
    tone_counterfactual,
    tone_views,
)
from .fourier import amplitude_exchange, fourier_views
from .photometric import PhotometricRanges, photometric_counterfactual
from .paired_anchor import PairedAnchorSet, PairedRecord

__all__ = [
    "CounterfactualEngine", "EngineConfig",
    "decompose", "render", "ChromophoreMaps",
    "estimate_ita", "ita_category", "ita_from_lab",
    "ToneCFConfig", "solve_offset", "render_tone", "tone_counterfactual",
    "tone_views", "lesion_iou",
    "amplitude_exchange", "fourier_views",
    "PhotometricRanges", "photometric_counterfactual",
    "PairedAnchorSet", "PairedRecord",
]
