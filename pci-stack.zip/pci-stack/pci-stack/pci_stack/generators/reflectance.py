r"""Two-chromophore reflectance decomposition, eq (3).

Optical density is modeled as a sum of melanin and hemoglobin absorption plus a
scattering residual:

    log(1 / R(lambda)) = c_m * mu_m(lambda) + c_h * mu_h(lambda) + sigma(lambda)      (3)

We solve per pixel for the non-negative chromophore coefficients (c_m, c_h) by
projecting the linearized, white-balanced RGB optical density onto the absorption
basis integrated against the sRGB camera sensitivity curves. The recovered maps are
*relative* (Section 4.2, condition 1): they inherit any error in the white-balance /
illuminant estimate and are not absolute concentrations.

The absorption spectra follow Tsumura et al. (1999) [31]; the sRGB sensitivities
follow Jiang et al. (2013). Because we only ever *edit* the melanin coefficient and
re-render, the exact spectral scale cancels and only the per-channel absorption
*direction* matters, which is what the 3x2 basis below encodes.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# sRGB inverse-gamma linearization ------------------------------------------------
_A = 0.055


def srgb_to_linear(img: np.ndarray) -> np.ndarray:
    """Inverse sRGB companding. `img` in [0, 1]."""
    img = np.clip(img, 0.0, 1.0)
    low = img <= 0.04045
    out = np.empty_like(img)
    out[low] = img[low] / 12.92
    out[~low] = ((img[~low] + _A) / (1 + _A)) ** 2.4
    return out


def linear_to_srgb(img: np.ndarray) -> np.ndarray:
    img = np.clip(img, 0.0, 1.0)
    low = img <= 0.0031308
    out = np.empty_like(img)
    out[low] = img[low] * 12.92
    out[~low] = (1 + _A) * (img[~low] ** (1 / 2.4)) - _A
    return np.clip(out, 0.0, 1.0)


def gray_world_white_balance(linear_rgb: np.ndarray,
                             mask: np.ndarray | None = None) -> np.ndarray:
    """Divide each channel by its (masked) mean so the average is gray."""
    flat = linear_rgb.reshape(-1, 3)
    if mask is not None:
        sel = flat[mask.reshape(-1) > 0]
    else:
        sel = flat
    means = sel.mean(axis=0) + 1e-6
    gray = means.mean()
    gains = gray / means
    return np.clip(linear_rgb * gains, 1e-6, 1.0)


# Per-channel absorption basis (R, G, B) x (melanin, hemoglobin). Columns are the
# directions that melanin and hemoglobin push optical density in sRGB space, derived
# by integrating the [31] spectra against the Jiang-2013 sensitivities. Normalized;
# absolute scale is irrelevant because we only add a melanin offset and re-render.
ABSORPTION_BASIS = np.array(
    [[0.610, 0.300],     # R: melanin high, hemoglobin moderate
     [0.600, 0.780],     # G: hemoglobin strongest in green
     [0.517, 0.548]],    # B: melanin rises toward blue
    dtype=np.float64,
)


@dataclass
class ChromophoreMaps:
    """Per-pixel chromophore coefficients and the scattering residual."""
    c_m: np.ndarray           # melanin map   (H, W)
    c_h: np.ndarray           # hemoglobin map (H, W)
    sigma: np.ndarray         # scattering residual per channel (H, W, 3)
    basis: np.ndarray         # (3, 2) absorption basis used
    gains: np.ndarray         # white-balance gains applied (3,)

    def shape(self):
        return self.c_m.shape


def decompose(rgb: np.ndarray, mask: np.ndarray | None = None,
              basis: np.ndarray = ABSORPTION_BASIS) -> ChromophoreMaps:
    """Solve eq (3) per pixel via non-negative least squares (closed-form 2x2).

    Parameters
    ----------
    rgb : (H, W, 3) float array in [0, 1] (sRGB).
    mask : optional (H, W) skin mask used for the white-balance estimate.

    Returns
    -------
    ChromophoreMaps with melanin / hemoglobin maps and the residual needed to
    re-render exactly (so a zero edit is an identity transform).
    """
    rgb = np.asarray(rgb, dtype=np.float64)
    assert rgb.ndim == 3 and rgb.shape[2] == 3, "expected (H, W, 3) image"
    h, w, _ = rgb.shape

    linear = srgb_to_linear(rgb)
    # record gains so re-render is in the same space
    flat = linear.reshape(-1, 3)
    sel = flat[mask.reshape(-1) > 0] if mask is not None else flat
    means = sel.mean(axis=0) + 1e-6
    gains = means.mean() / means
    balanced = np.clip(linear * gains, 1e-6, 1.0)

    od = -np.log(balanced)                      # optical density, (H, W, 3)
    od_flat = od.reshape(-1, 3)                 # (N, 3)

    # least squares od ~= basis @ [c_m, c_h];  coeffs = (B^T B)^-1 B^T od, clipped >= 0
    bt_b = basis.T @ basis                      # (2, 2)
    bt_b_inv = np.linalg.inv(bt_b + 1e-8 * np.eye(2))
    coeffs = od_flat @ basis @ bt_b_inv.T       # (N, 2)
    coeffs = np.clip(coeffs, 0.0, None)         # non-negativity

    # residual that makes reconstruction exact given the clipped coefficients
    recon_od = coeffs @ basis.T                 # (N, 3)
    sigma = (od_flat - recon_od).reshape(h, w, 3)

    c_m = coeffs[:, 0].reshape(h, w)
    c_h = coeffs[:, 1].reshape(h, w)
    return ChromophoreMaps(c_m=c_m, c_h=c_h, sigma=sigma, basis=basis, gains=gains)


def render(maps: ChromophoreMaps) -> np.ndarray:
    """Re-render an sRGB image from chromophore maps (inverse of `decompose`).

    With an unmodified `ChromophoreMaps`, `render(decompose(x)) == x` up to clipping.
    """
    h, w = maps.shape()
    coeffs = np.stack([maps.c_m.reshape(-1), maps.c_h.reshape(-1)], axis=1)   # (N, 2)
    od = coeffs @ maps.basis.T + maps.sigma.reshape(-1, 3)                     # (N, 3)
    balanced = np.exp(-od).reshape(h, w, 3)
    linear = np.clip(balanced / maps.gains, 1e-6, 1.0)   # undo white balance
    return linear_to_srgb(linear)
