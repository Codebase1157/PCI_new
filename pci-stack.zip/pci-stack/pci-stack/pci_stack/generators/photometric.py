r"""Randomized photometric acquisition chain, eq (8).

    x_a = h_K ∘ ... ∘ h_1(x),   h_k ~ H                                            (8)

A composition of device-level perturbations: blur, JPEG compression, colour-
temperature shift, vignetting, specular-highlight insertion and a resolution
round-trip. Ranges are from Table S1. Like the Fourier exchange, this is a heuristic
acquisition augmentation (Section 4.2).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class PhotometricRanges:
    blur_sigma: tuple[float, float] = (0.0, 1.5)
    jpeg_quality: tuple[int, int] = (60, 95)
    color_temperature_k: tuple[float, float] = (-600.0, 600.0)
    vignette_strength: tuple[float, float] = (0.0, 0.3)
    specular_strength: tuple[float, float] = (0.0, 0.1)
    resize_scale: tuple[float, float] = (0.75, 1.0)
    operations: list[str] = field(default_factory=lambda: [
        "blur", "jpeg", "color_temperature", "vignette", "specular", "resize"])


def _u(rng, lo, hi):
    return float(rng.uniform(lo, hi))


def _blur(img, sigma):
    if sigma <= 0:
        return img
    try:
        import cv2

        k = int(2 * round(3 * sigma) + 1)
        return cv2.GaussianBlur(img, (k, k), sigma)
    except Exception:
        from scipy.ndimage import gaussian_filter

        return np.stack([gaussian_filter(img[..., c], sigma) for c in range(3)], -1)


def _jpeg(img, quality):
    try:
        import cv2

        enc = [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)]
        ok, buf = cv2.imencode(".jpg", (img * 255).astype(np.uint8), enc)
        if not ok:
            return img
        dec = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        return dec.astype(np.float64) / 255.0
    except Exception:
        # quantization proxy
        levels = max(2, int(quality / 4))
        return np.round(img * levels) / levels


def _color_temperature(img, delta_k):
    """Approximate CT shift: warm (+) boosts red, cools blue, and vice versa."""
    scale = delta_k / 600.0
    gains = np.array([1 + 0.08 * scale, 1.0, 1 - 0.08 * scale])
    return np.clip(img * gains, 0, 1)


def _vignette(img, strength):
    if strength <= 0:
        return img
    h, w = img.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w]
    cy, cx = h / 2, w / 2
    d = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    d = d / d.max()
    falloff = 1 - strength * (d ** 2)
    return np.clip(img * falloff[..., None], 0, 1)


def _specular(img, strength, rng):
    if strength <= 0:
        return img
    h, w = img.shape[:2]
    out = img.copy()
    n_spots = rng.integers(1, 4)
    for _ in range(n_spots):
        cy, cx = rng.integers(0, h), rng.integers(0, w)
        r = rng.integers(2, max(3, min(h, w) // 20))
        yy, xx = np.mgrid[0:h, 0:w]
        g = np.exp(-((yy - cy) ** 2 + (xx - cx) ** 2) / (2 * r ** 2))
        out = np.clip(out + strength * g[..., None], 0, 1)
    return out


def _resize_roundtrip(img, scale):
    if scale >= 1.0:
        return img
    h, w = img.shape[:2]
    small = (max(1, int(h * scale)), max(1, int(w * scale)))
    try:
        import cv2

        down = cv2.resize(img, (small[1], small[0]), interpolation=cv2.INTER_AREA)
        return cv2.resize(down, (w, h), interpolation=cv2.INTER_LINEAR)
    except Exception:
        from skimage.transform import resize

        down = resize(img, small, anti_aliasing=True)
        return resize(down, (h, w), anti_aliasing=True)


def photometric_counterfactual(rgb: np.ndarray,
                               ranges: PhotometricRanges | None = None,
                               rng: np.random.Generator | None = None) -> np.ndarray:
    """Apply the randomized chain once, eq (8)."""
    ranges = ranges or PhotometricRanges()
    rng = rng or np.random.default_rng()
    img = np.asarray(rgb, dtype=np.float64).copy()
    for op in ranges.operations:
        if op == "blur":
            img = _blur(img, _u(rng, *ranges.blur_sigma))
        elif op == "jpeg":
            img = _jpeg(img, int(_u(rng, *ranges.jpeg_quality)))
        elif op == "color_temperature":
            img = _color_temperature(img, _u(rng, *ranges.color_temperature_k))
        elif op == "vignette":
            img = _vignette(img, _u(rng, *ranges.vignette_strength))
        elif op == "specular":
            img = _specular(img, _u(rng, *ranges.specular_strength), rng)
        elif op == "resize":
            img = _resize_roundtrip(img, _u(rng, *ranges.resize_scale))
    return np.clip(img, 0, 1)


def photometric_views(rgb: np.ndarray, n: int = 1,
                      ranges: PhotometricRanges | None = None,
                      rng: np.random.Generator | None = None) -> list[np.ndarray]:
    rng = rng or np.random.default_rng()
    return [photometric_counterfactual(rgb, ranges, rng) for _ in range(n)]
