r"""Acquisition counterfactual by Fourier amplitude exchange, eq (7).

    A' = (1 - M_beta) ⊙ A(x) + M_beta ⊙ A(x_r),   x_a = F^{-1}[ A' e^{i P(x)} ]     (7)

The low-frequency amplitude of the source is replaced with that of a reference image
from another device, retaining the source phase (and therefore the lesion geometry).
M_beta selects a centered band of relative width beta (default 0.10, Table S1).
Device shift is empirically well described by low-frequency amplitude statistics, so
this is a heuristic acquisition augmentation (Section 4.2, condition 3), not a
physically grounded edit.
"""
from __future__ import annotations

import numpy as np


def _centered_band_mask(h: int, w: int, beta: float) -> np.ndarray:
    """Centered low-frequency square band of relative half-width beta/2 (in the
    fftshifted spectrum). Returns a (H, W) float mask in {0, 1}."""
    bh = max(1, int(round(beta * h / 2)))
    bw = max(1, int(round(beta * w / 2)))
    mask = np.zeros((h, w), dtype=np.float64)
    cy, cx = h // 2, w // 2
    mask[cy - bh:cy + bh + 1, cx - bw:cx + bw + 1] = 1.0
    return mask


def amplitude_exchange(src: np.ndarray, ref: np.ndarray,
                       beta: float = 0.10) -> np.ndarray:
    """eq (7), applied per channel. `src` and `ref` are (H, W, 3) in [0, 1];
    `ref` is resized to `src` if needed."""
    src = np.asarray(src, dtype=np.float64)
    ref = np.asarray(ref, dtype=np.float64)
    h, w, c = src.shape
    if ref.shape[:2] != (h, w):
        ref = _resize(ref, (h, w))
    mask = _centered_band_mask(h, w, beta)
    out = np.empty_like(src)
    for ch in range(c):
        fs = np.fft.fftshift(np.fft.fft2(src[..., ch]))
        fr = np.fft.fftshift(np.fft.fft2(ref[..., ch]))
        amp_s, phase_s = np.abs(fs), np.angle(fs)
        amp_r = np.abs(fr)
        amp_new = (1 - mask) * amp_s + mask * amp_r      # swap low-freq amplitude
        f_new = amp_new * np.exp(1j * phase_s)           # keep source phase
        out[..., ch] = np.real(np.fft.ifft2(np.fft.ifftshift(f_new)))
    return np.clip(out, 0.0, 1.0)


def _resize(img: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    try:
        import cv2

        return cv2.resize(img, (size[1], size[0]), interpolation=cv2.INTER_AREA)
    except Exception:
        from skimage.transform import resize

        return resize(img, size, anti_aliasing=True)


def fourier_views(src: np.ndarray, reference_pool: list[np.ndarray],
                  beta: float = 0.10, n: int = 1,
                  rng: np.random.Generator | None = None) -> list[np.ndarray]:
    """Generate `n` acquisition counterfactuals using random references drawn from a
    cross-device reference pool."""
    rng = rng or np.random.default_rng()
    if not reference_pool:
        return []
    idx = rng.integers(0, len(reference_pool), size=n)
    return [amplitude_exchange(src, reference_pool[i], beta) for i in idx]
