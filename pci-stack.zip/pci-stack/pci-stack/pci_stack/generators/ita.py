r"""Individual Typology Angle (ITA), eq (4), and healthy-skin annulus sampling
(Section 3.2).

    ITA(x) = arctan( (L* - 50) / b* ) * 180 / pi                                   (4)

ITA is computed on a healthy-skin annulus sampled between 1.2 and 2.0 lesion radii,
excluding hair and specular pixels, converted to CIELAB and summarized by the median
L* and b*. The result is binned with the Del Bino categories (constants.ita_to_bin).
"""
from __future__ import annotations

import numpy as np

from ..constants import ita_to_bin  # noqa: F401  (re-exported for convenience)

try:
    from skimage.color import rgb2lab
except Exception:  # pragma: no cover
    rgb2lab = None


def _rgb2lab(rgb: np.ndarray) -> np.ndarray:
    """RGB [0,1] -> CIELAB. Uses skimage if present, else a D65 fallback."""
    if rgb2lab is not None:
        return rgb2lab(np.clip(rgb, 0, 1))
    # minimal sRGB(D65) -> Lab fallback
    from .reflectance import srgb_to_linear

    lin = srgb_to_linear(rgb)
    m = np.array([[0.4124, 0.3576, 0.1805],
                  [0.2126, 0.7152, 0.0722],
                  [0.0193, 0.1192, 0.9505]])
    xyz = lin.reshape(-1, 3) @ m.T
    white = np.array([0.95047, 1.0, 1.08883])
    xyz = xyz / white

    def f(t):
        d = 6 / 29
        return np.where(t > d ** 3, np.cbrt(t), t / (3 * d ** 2) + 4 / 29)

    fx, fy, fz = f(xyz[:, 0]), f(xyz[:, 1]), f(xyz[:, 2])
    L = 116 * fy - 16
    a = 500 * (fx - fy)
    b = 200 * (fy - fz)
    return np.stack([L, a, b], axis=1).reshape(rgb.shape)


def ita_from_lab(L: np.ndarray, b: np.ndarray) -> np.ndarray:
    """eq (4). Accepts scalars or arrays."""
    return np.degrees(np.arctan2(np.asarray(L) - 50.0, np.asarray(b) + 1e-8))


def annulus_mask(lesion_mask: np.ndarray, r_inner: float = 1.2,
                 r_outer: float = 2.0) -> np.ndarray:
    """Healthy-skin ring between r_inner and r_outer lesion radii around the lesion
    centroid. `lesion_mask` is a binary (H, W) array."""
    lesion_mask = np.asarray(lesion_mask) > 0
    h, w = lesion_mask.shape
    ys, xs = np.nonzero(lesion_mask)
    if len(xs) == 0:
        # no lesion: treat the whole image as skin
        return np.ones((h, w), dtype=bool)
    cy, cx = ys.mean(), xs.mean()
    area = lesion_mask.sum()
    radius = np.sqrt(area / np.pi)
    yy, xx = np.mgrid[0:h, 0:w]
    dist = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    ring = (dist >= r_inner * radius) & (dist <= r_outer * radius)
    return ring & (~lesion_mask)


def _exclude_hair_specular(rgb: np.ndarray, skin: np.ndarray) -> np.ndarray:
    """Drop obvious hair (dark, low-saturation strands) and specular (near-white)
    pixels from the skin support with simple colourimetric thresholds."""
    lab = _rgb2lab(rgb)
    L = lab[..., 0]
    maxc = rgb.max(axis=2)
    minc = rgb.min(axis=2)
    sat = (maxc - minc) / (maxc + 1e-6)
    specular = (L > 92) & (sat < 0.08)
    hair = (L < 25)
    return skin & (~specular) & (~hair)


def estimate_ita(rgb: np.ndarray, lesion_mask: np.ndarray | None = None,
                 r_inner: float = 1.2, r_outer: float = 2.0) -> float:
    """Median-ITA of the healthy-skin annulus. If no lesion mask is given the whole
    image (minus hair/specular) is used."""
    rgb = np.asarray(rgb, dtype=np.float64)
    if lesion_mask is not None:
        skin = annulus_mask(lesion_mask, r_inner, r_outer)
    else:
        skin = np.ones(rgb.shape[:2], dtype=bool)
    skin = _exclude_hair_specular(rgb, skin)
    if skin.sum() < 16:                       # too few pixels — fall back to all
        skin = np.ones(rgb.shape[:2], dtype=bool)
    lab = _rgb2lab(rgb)
    L = np.median(lab[..., 0][skin])
    b = np.median(lab[..., 2][skin])
    return float(ita_from_lab(L, b))


def ita_category(rgb: np.ndarray, lesion_mask: np.ndarray | None = None) -> str:
    return ita_to_bin(estimate_ita(rgb, lesion_mask))
