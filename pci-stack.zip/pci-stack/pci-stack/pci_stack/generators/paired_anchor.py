r"""Real paired acquisition anchor (Section 4.2).

The Derm7pt clinical/dermoscopic pairs of the *same lesion* are real observations
under two acquisition conditions and enter the same consistency objectives as an
anchor. Crucially, when Derm7pt is the held-out domain of a fold, its paired images
are withheld from the anchor set for that fold (Reviewer 2.2), so no image of the
evaluation domain enters any training objective.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

import numpy as np


@dataclass
class PairedRecord:
    lesion_id: str
    clinical_path: str
    dermoscopic_path: str
    label: int
    patient_id: str


class PairedAnchorSet:
    """Holds the Derm7pt real acquisition pairs used as consistency anchors."""

    def __init__(self, records: list[PairedRecord], held_out_fold: str | None = None):
        self.records = records
        self.held_out_fold = held_out_fold

    @property
    def active(self) -> bool:
        """False when Derm7pt is the held-out domain — the anchor is disabled then."""
        return self.held_out_fold != "derm7pt"

    def __len__(self) -> int:
        return len(self.records) if self.active else 0

    def __iter__(self) -> Iterator[PairedRecord]:
        if self.active:
            yield from self.records

    @classmethod
    def from_manifest(cls, df, held_out_fold: str | None = None) -> "PairedAnchorSet":
        """Build from a dataframe with columns:
        lesion_id, clinical_path, dermoscopic_path, label, patient_id."""
        recs = [
            PairedRecord(
                lesion_id=str(r.lesion_id),
                clinical_path=str(r.clinical_path),
                dermoscopic_path=str(r.dermoscopic_path),
                label=int(r.label),
                patient_id=str(r.patient_id),
            )
            for r in df.itertuples(index=False)
        ]
        if held_out_fold == "derm7pt":
            recs = []  # explicit: withheld in the Derm7pt fold
        return cls(recs, held_out_fold=held_out_fold)

    def consistency_pairs(self, loader) -> list[tuple[np.ndarray, np.ndarray, int]]:
        """Materialize (clinical, dermoscopic, label) image triples. `loader(path)`
        returns an (H, W, 3) float image in [0, 1]."""
        out = []
        for rec in self:
            out.append((loader(rec.clinical_path),
                        loader(rec.dermoscopic_path), rec.label))
        return out
