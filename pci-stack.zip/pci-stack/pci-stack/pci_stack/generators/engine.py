r"""Unified physics-guided counterfactual engine (Tier 1).

Combines the tone edit (eq 5-6), Fourier amplitude exchange (eq 7), photometric
chain (eq 8) and the real Derm7pt anchor into a single object that yields the
counterfactual views each learner's contract requires. No generative model is
trained; the engine is label-free and runs at ~2.1 ms/image for the physical edit
(Section 4.7).

Example
-------
>>> eng = CounterfactualEngine.from_config(cfg.generator)
>>> views = eng.views(image, axes=["tone"], lesion_mask=mask)   # dict axis -> [imgs]
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..constants import CF_FOURIER, CF_PAIRED, CF_PHOTOMETRIC, CF_TONE
from . import fourier, photometric
from . import tone_cf
from .photometric import PhotometricRanges


@dataclass
class EngineConfig:
    tone_support: str = "skin_mask"
    tone_tol_deg: float = 1.0
    tone_bracket: tuple[float, float] = (-0.5, 0.5)
    fourier_beta: float = 0.10
    views_per_image: int = 2
    photometric: PhotometricRanges = field(default_factory=PhotometricRanges)
    diffusion_refiner: bool = False

    @classmethod
    def from_dict(cls, g: dict) -> "EngineConfig":
        pr = PhotometricRanges()
        pm = (g.get("photometric") or {}).get("ranges", {})
        for k in ("blur_sigma", "jpeg_quality", "color_temperature_k",
                  "vignette_strength", "specular_strength", "resize_scale"):
            if k in pm:
                setattr(pr, k, tuple(pm[k]))
        ops = (g.get("photometric") or {}).get("operations")
        if ops:
            pr.operations = list(ops)
        tone = g.get("tone_cf", {})
        return cls(
            tone_support=tone.get("support", "skin_mask"),
            tone_tol_deg=tone.get("search_tol_deg", 1.0),
            tone_bracket=tuple(tone.get("search_bracket", (-0.5, 0.5))),
            fourier_beta=(g.get("fourier", {}) or {}).get("band_width", 0.10),
            views_per_image=(g.get("runtime", {}) or {}).get("views_per_image", 2),
            photometric=pr,
            diffusion_refiner=(g.get("diffusion_refiner", {}) or {}).get("enabled", False),
        )


class CounterfactualEngine:
    def __init__(self, cfg: EngineConfig | None = None,
                 reference_pool: list[np.ndarray] | None = None,
                 seed: int = 2026):
        self.cfg = cfg or EngineConfig()
        self.reference_pool = reference_pool or []
        self.rng = np.random.default_rng(seed)
        self._tone_cfg = tone_cf.ToneCFConfig(
            support=self.cfg.tone_support,
            tol_deg=self.cfg.tone_tol_deg,
            bracket=self.cfg.tone_bracket,
        )

    @classmethod
    def from_config(cls, generator_cfg, reference_pool=None, seed: int = 2026):
        g = dict(generator_cfg) if not isinstance(generator_cfg, dict) else generator_cfg
        return cls(EngineConfig.from_dict(g), reference_pool=reference_pool, seed=seed)

    def set_reference_pool(self, pool: list[np.ndarray]) -> None:
        self.reference_pool = pool

    # ---- individual axes ---------------------------------------------------- #
    def tone(self, img, lesion_mask=None, targets=None):
        return list(tone_cf.tone_views(img, lesion_mask, targets, self._tone_cfg).values())

    def fourier(self, img, n=None):
        n = n or self.cfg.views_per_image
        return fourier.fourier_views(img, self.reference_pool, self.cfg.fourier_beta,
                                     n=n, rng=self.rng)

    def photometric(self, img, n=None):
        n = n or self.cfg.views_per_image
        return photometric.photometric_views(img, n=n, ranges=self.cfg.photometric,
                                             rng=self.rng)

    # ---- combined ----------------------------------------------------------- #
    def views(self, img: np.ndarray, axes: list[str],
              lesion_mask: np.ndarray | None = None,
              paired_partner: np.ndarray | None = None) -> dict[str, list[np.ndarray]]:
        """Return a dict axis -> list of counterfactual images for the requested axes.
        `paired_partner` is the same-lesion image under the other acquisition (Derm7pt)."""
        out: dict[str, list[np.ndarray]] = {}
        for ax in axes:
            if ax == CF_TONE:
                out[ax] = self.tone(img, lesion_mask)
            elif ax == CF_FOURIER:
                out[ax] = self.fourier(img)
            elif ax == CF_PHOTOMETRIC:
                out[ax] = self.photometric(img)
            elif ax == CF_PAIRED:
                out[ax] = [paired_partner] if paired_partner is not None else []
            else:
                raise ValueError(f"unknown counterfactual axis: {ax}")
        return out

    def all_views(self, img, axes, lesion_mask=None, paired_partner=None):
        """Flat list of all counterfactual views across the requested axes."""
        d = self.views(img, axes, lesion_mask, paired_partner)
        flat = []
        for v in d.values():
            flat.extend([x for x in v if x is not None])
        return flat
