r"""Tone counterfactual, eq (5)-(6).

A spatially constant melanin offset is added over the healthy-skin support only and
the image is re-rendered:

    x_tau = R(c_m + Delta c_m * 1_{Omega_s}, c_h, sigma)                            (5)

The offset is chosen so the annulus ITA of the rendered image reaches a target
category, via a one-dimensional search:

    Delta c_m* = argmin_{Delta c_m} | ITA(N(x_tau)) - tau |                         (6)

Two variants are produced: skin-only (default, lesion interior numerically untouched)
and whole-image. The label is preserved by construction — this is a monotone
recoloring of a physically interpretable coefficient, with no generative model.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar

from . import reflectance as refl
from .ita import annulus_mask, estimate_ita
from ..constants import TONE_BINS

# representative target ITA (degrees) at the centre of each Del Bino band, used as
# the objective target in eq (6).
TARGET_ITA = {"light": 55.0, "intermediate": 25.0, "dark": 0.0}


@dataclass
class ToneCFConfig:
    support: str = "skin_mask"          # "skin_mask" (default) or "whole_image"
    tol_deg: float = 1.0
    bracket: tuple[float, float] = (-0.5, 0.5)


def _skin_support(rgb: np.ndarray, lesion_mask: np.ndarray | None,
                  support: str) -> np.ndarray:
    if support == "whole_image" or lesion_mask is None:
        return np.ones(rgb.shape[:2], dtype=bool)
    # skin-only: annulus ring, i.e. everything that is healthy skin, lesion excluded
    return annulus_mask(lesion_mask, 1.2, 2.0)


def apply_melanin_offset(maps: refl.ChromophoreMaps, delta_cm: float,
                         support: np.ndarray) -> refl.ChromophoreMaps:
    """eq (5): add Delta c_m over the support only, leaving c_h and sigma intact."""
    new_cm = maps.c_m + float(delta_cm) * (support > 0)
    new_cm = np.clip(new_cm, 0.0, None)
    return refl.ChromophoreMaps(c_m=new_cm, c_h=maps.c_h, sigma=maps.sigma,
                                basis=maps.basis, gains=maps.gains)


def render_tone(rgb: np.ndarray, delta_cm: float, lesion_mask: np.ndarray | None,
                support: str = "skin_mask") -> np.ndarray:
    maps = refl.decompose(rgb, mask=lesion_mask)
    sup = _skin_support(rgb, lesion_mask, support)
    edited = apply_melanin_offset(maps, delta_cm, sup)
    return refl.render(edited)


def solve_offset(rgb: np.ndarray, target_category: str,
                 lesion_mask: np.ndarray | None = None,
                 cfg: ToneCFConfig | None = None) -> float:
    r"""One-dimensional search of eq (6): find Delta c_m whose rendered annulus ITA
    is closest to the target category's representative ITA.

    Because optical density is logarithmic in reflectance, d(ITA)/d(Delta c_m)
    flattens at high melanin — the inversion is ill-conditioned at extreme tones
    (Section 7). We report that by returning the best offset found within the bracket.
    """
    cfg = cfg or ToneCFConfig()
    assert target_category in TONE_BINS, target_category
    target = TARGET_ITA[target_category]
    maps = refl.decompose(rgb, mask=lesion_mask)
    sup = _skin_support(rgb, lesion_mask, cfg.support)

    def objective(delta_cm: float) -> float:
        edited = apply_melanin_offset(maps, delta_cm, sup)
        rendered = refl.render(edited)
        return abs(estimate_ita(rendered, lesion_mask) - target)

    res = minimize_scalar(objective, bounds=cfg.bracket, method="bounded",
                          options={"xatol": 1e-3})
    return float(res.x)


def tone_counterfactual(rgb: np.ndarray, target_category: str,
                        lesion_mask: np.ndarray | None = None,
                        cfg: ToneCFConfig | None = None) -> np.ndarray:
    """Convenience: solve eq (6) then render eq (5) for a single target category."""
    cfg = cfg or ToneCFConfig()
    delta = solve_offset(rgb, target_category, lesion_mask, cfg)
    return render_tone(rgb, delta, lesion_mask, cfg.support)


def tone_views(rgb: np.ndarray, lesion_mask: np.ndarray | None = None,
               targets: list[str] | None = None,
               cfg: ToneCFConfig | None = None) -> dict[str, np.ndarray]:
    """Generate one counterfactual per target tone category."""
    targets = targets or TONE_BINS
    return {t: tone_counterfactual(rgb, t, lesion_mask, cfg) for t in targets}


def lesion_iou(mask_a: np.ndarray, mask_b: np.ndarray) -> float:
    """IoU of two binary lesion masks (Fig. 2 reports 0.999 for skin-only editing)."""
    a = np.asarray(mask_a) > 0
    b = np.asarray(mask_b) > 0
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter / union) if union else 1.0
