"""Evaluation metrics (Section 5): AUROC, worst-group AUROC, light-to-dark gap,
equal-opportunity difference, sensitivity at fixed specificity, expected
calibration error, and patient-level bootstrap confidence intervals.

All functions take numpy arrays and are dependency-light (numpy + optional sklearn).
"""
from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np

try:
    from sklearn.metrics import roc_auc_score
except Exception:  # pragma: no cover - sklearn optional
    roc_auc_score = None


# --------------------------------------------------------------------------- #
# discrimination
# --------------------------------------------------------------------------- #
def auroc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """Area under the ROC curve. Falls back to a rank-based estimator (equivalent
    to the Mann-Whitney U statistic) when sklearn is unavailable."""
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    if len(np.unique(y_true)) < 2:
        return float("nan")
    if roc_auc_score is not None:
        return float(roc_auc_score(y_true, y_score))
    # rank-based AUROC
    order = np.argsort(y_score, kind="mergesort")
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(y_score) + 1)
    # average ties
    _, inv, counts = np.unique(y_score, return_inverse=True, return_counts=True)
    tie_mean = np.zeros(len(counts))
    sums = np.zeros(len(counts))
    np.add.at(sums, inv, ranks)
    tie_mean = sums / counts
    ranks = tie_mean[inv]
    n_pos = int(y_true.sum())
    n_neg = len(y_true) - n_pos
    sum_pos = ranks[y_true == 1].sum()
    return float((sum_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def worst_group_auroc(y_true: np.ndarray, y_score: np.ndarray,
                      groups: Sequence) -> float:
    """min over tone groups of per-group AUROC, eq (31)."""
    groups = np.asarray(groups)
    vals = []
    for g in np.unique(groups):
        m = groups == g
        if m.sum() > 1:
            vals.append(auroc(y_true[m], y_score[m]))
    vals = [v for v in vals if not np.isnan(v)]
    return float(min(vals)) if vals else float("nan")


def light_to_dark_gap(y_true: np.ndarray, y_score: np.ndarray,
                      fitzpatrick: Sequence,
                      light: str = "I-II", dark: str = "V-VI") -> float:
    """AUROC(light) - AUROC(dark), eq (31)."""
    fitz = np.asarray(fitzpatrick)
    a_light = auroc(y_true[fitz == light], y_score[fitz == light])
    a_dark = auroc(y_true[fitz == dark], y_score[fitz == dark])
    return float(a_light - a_dark)


def equal_opportunity_difference(y_true: np.ndarray, y_pred: np.ndarray,
                                 fitzpatrick: Sequence,
                                 light: str = "I-II", dark: str = "V-VI") -> float:
    """|TPR(light) - TPR(dark)| at the deployed threshold, eq (32).
    y_pred is the thresholded binary decision."""
    fitz = np.asarray(fitzpatrick)
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)

    def tpr(mask):
        pos = mask & (y_true == 1)
        return float((y_pred[pos] == 1).mean()) if pos.sum() else float("nan")

    return float(abs(tpr(fitz == light) - tpr(fitz == dark)))


def sensitivity_at_specificity(y_true: np.ndarray, y_score: np.ndarray,
                               target_specificity: float = 0.95) -> float:
    """Se@95Sp: sensitivity at the threshold achieving the target specificity."""
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    neg = y_score[y_true == 0]
    if len(neg) == 0:
        return float("nan")
    thr = np.quantile(neg, target_specificity)
    pos = y_score[y_true == 1]
    return float((pos >= thr).mean()) if len(pos) else float("nan")


# --------------------------------------------------------------------------- #
# calibration
# --------------------------------------------------------------------------- #
def expected_calibration_error(y_true: np.ndarray, y_prob: np.ndarray,
                               n_bins: int = 15) -> float:
    """ECE with equal-width bins."""
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    n = len(y_prob)
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (y_prob > lo) & (y_prob <= hi)
        if m.sum() == 0:
            continue
        acc = y_true[m].mean()
        conf = y_prob[m].mean()
        ece += (m.sum() / n) * abs(acc - conf)
    return float(ece)


# --------------------------------------------------------------------------- #
# confusion counts (Table S11)
# --------------------------------------------------------------------------- #
def confusion_counts(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    tpr = tp / (tp + fn) if (tp + fn) else float("nan")
    spec = tn / (tn + fp) if (tn + fp) else float("nan")
    denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / denom if denom else float("nan")
    return {"TP": tp, "FN": fn, "FP": fp, "TN": tn,
            "TPR": tpr, "Specificity": spec, "MCC": float(mcc)}


# --------------------------------------------------------------------------- #
# bootstrap CIs (patient-level)
# --------------------------------------------------------------------------- #
def bootstrap_ci(metric_fn, *arrays, patient_ids: Sequence | None = None,
                 n_resamples: int = 2000, alpha: float = 0.05,
                 seed: int = 2026) -> tuple[float, float, float]:
    """Patient-level bootstrap. Resamples clusters (patients) with replacement.
    Returns (point, lo, hi). `metric_fn` takes the resampled arrays positionally.
    """
    rng = np.random.default_rng(seed)
    arrays = [np.asarray(a) for a in arrays]
    n = len(arrays[0])
    if patient_ids is None:
        patient_ids = np.arange(n)
    patient_ids = np.asarray(patient_ids)
    clusters = np.unique(patient_ids)
    idx_by_cluster = {c: np.where(patient_ids == c)[0] for c in clusters}

    point = float(metric_fn(*arrays))
    stats = np.empty(n_resamples)
    for b in range(n_resamples):
        chosen = rng.choice(clusters, size=len(clusters), replace=True)
        idx = np.concatenate([idx_by_cluster[c] for c in chosen])
        stats[b] = metric_fn(*[a[idx] for a in arrays])
    lo = float(np.nanpercentile(stats, 100 * alpha / 2))
    hi = float(np.nanpercentile(stats, 100 * (1 - alpha / 2)))
    return point, lo, hi


# --------------------------------------------------------------------------- #
# conformal reporting (Table 6)
# --------------------------------------------------------------------------- #
def coverage(pred_sets: Iterable[set], y_true: Sequence) -> float:
    """Fraction of prediction sets that contain the true label."""
    cov = [int(y in s) for s, y in zip(pred_sets, y_true)]
    return float(np.mean(cov)) if cov else float("nan")


def mean_set_size(pred_sets: Iterable[set]) -> float:
    sizes = [len(s) for s in pred_sets]
    return float(np.mean(sizes)) if sizes else float("nan")
