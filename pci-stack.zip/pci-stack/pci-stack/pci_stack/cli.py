"""`pci-stack` console entry point — a thin dispatcher over the numbered scripts."""
from __future__ import annotations

import argparse
import sys


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    parser = argparse.ArgumentParser(prog="pci-stack",
                                     description="PCI-Stack pipeline CLI")
    sub = parser.add_subparsers(dest="command")
    for name in ["prepare", "tone", "splits", "train", "meta", "calibrate",
                 "evaluate", "audit", "tables", "demo"]:
        p = sub.add_parser(name)
        p.add_argument("--config", default="configs/default.yaml")
        p.add_argument("--fold", default="isic2019")

    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0

    import runpy
    script = {
        "prepare": "scripts/00_prepare_data.py",
        "tone": "scripts/01_estimate_tone.py",
        "splits": "scripts/02_make_splits.py",
        "train": "scripts/03_train_learners.py",
        "meta": "scripts/04_train_meta.py",
        "calibrate": "scripts/05_calibrate_conformal.py",
        "evaluate": "scripts/06_evaluate.py",
        "audit": "scripts/07_run_audit.py",
        "tables": "scripts/08_reproduce_tables.py",
        "demo": "scripts/demo_synthetic.py",
    }[args.command]
    sys.argv = [script, "--config", args.config, "--fold", args.fold]
    runpy.run_path(script, run_name="__main__")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
