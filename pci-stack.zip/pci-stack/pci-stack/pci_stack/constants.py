"""Fixed constants from the paper: datasets, Del Bino tone bins, concept layer,
label map. Values trace to Table 1, Section 3.2, Tables S4b and S5.
"""
from __future__ import annotations

# ----- datasets (Table 1) ----------------------------------------------------
TRAINING_SOURCES = ["isic2019", "derm7pt", "fitzpatrick17k_c", "pad_ufes_20"]
EXTERNAL_SOURCES = ["ddi", "scin"]
ALL_SOURCES = TRAINING_SOURCES + EXTERNAL_SOURCES

MODALITY = {
    "isic2019": "dermoscopy",
    "derm7pt": "dermoscopy",            # + paired clinical
    "fitzpatrick17k_c": "clinical",
    "pad_ufes_20": "smartphone",
    "ddi": "clinical",
    "scin": "smartphone",
}

# ----- Del Bino tone bins (Section 3.2, Table S3), in ITA degrees -------------
TONE_BINS = ["light", "intermediate", "dark"]
DEL_BINO_LIGHT_GT = 41.0            # light  : ITA > 41
DEL_BINO_DARK_LT = 10.0            # dark   : ITA < 10   (intermediate: [10, 41])


def ita_to_bin(ita_deg: float) -> str:
    """Map an ITA value (degrees) to a Del Bino tone bin."""
    if ita_deg > DEL_BINO_LIGHT_GT:
        return "light"
    if ita_deg < DEL_BINO_DARK_LT:
        return "dark"
    return "intermediate"


# ----- Fitzpatrick strata used for fairness reporting (Section 6) ------------
FITZPATRICK_STRATA = ["I-II", "III-IV", "V-VI"]

# ----- binary label map (Table S4b) ------------------------------------------
# actinic_keratosis is non-malignant but tracked separately (Section 3.1).
NATIVE_TO_BINARY = {
    "melanoma": "malignant",
    "basal_cell_carcinoma": "malignant",
    "squamous_cell_carcinoma": "malignant",
    "lentigo_maligna_in_situ": "malignant",
    "actinic_keratosis": "non_malignant",          # reported separately
    "melanocytic_nevus": "non_malignant",
    "seborrheic_keratosis": "non_malignant",
    "benign_keratosis": "non_malignant",
    "dermatofibroma": "non_malignant",
    "vascular_lesion": "non_malignant",
    "solar_lentigo": "non_malignant",
    "blue_nevus": "non_malignant",
}
BINARY_CLASSES = ["non_malignant", "malignant"]    # index 0, 1
ACTINIC_KERATOSIS_SEPARATE = True

# ----- the 22-concept clinical layer (Table S5) ------------------------------
CONCEPTS = [
    # 1-7: Derm7pt seven-point checklist (full coverage, expert)
    "atypical_pigment_network", "blue_white_veil", "atypical_vascular_pattern",
    "irregular_streaks", "irregular_pigmentation", "irregular_dots_globules",
    "regression_structures",
    # 8-15: SkinCon (20.6% coverage, expert)
    "asymmetry", "border_irregularity", "erythema", "scale_crust", "ulceration",
    "hyperpigmentation", "hypopigmentation", "telangiectasia",
    # 16-22: MONET pseudo-labels (100% coverage, validated vs expert subset)
    "nodular_morphology", "papular_morphology", "plaque_morphology",
    "milia_like_cysts", "comedo_like_openings", "pink_coloration",
    "brown_black_coloration",
]
assert len(CONCEPTS) == 22

CONCEPT_SOURCE = (
    ["derm7pt_checklist"] * 7 + ["skincon"] * 8 + ["monet_pseudo"] * 7
)
CONCEPT_PSEUDO_LABELLED = [False] * 15 + [True] * 7

# ----- counterfactual axes ---------------------------------------------------
CF_TONE = "tone"
CF_FOURIER = "fourier"
CF_PHOTOMETRIC = "photometric"
CF_PAIRED = "paired"
CF_AXES = [CF_TONE, CF_FOURIER, CF_PHOTOMETRIC, CF_PAIRED]

# split roles (Section 3.3)
SPLIT_ROLES = ["learner_train", "level1_oof", "conformal_calib", "val"]
