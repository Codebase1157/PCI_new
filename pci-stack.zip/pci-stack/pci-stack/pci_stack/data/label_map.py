r"""Native-diagnosis -> binary-target mapping (Section 3.1, Table S4b).

Melanoma, BCC and SCC are malignant in all sources; actinic keratosis is treated as
non-malignant and reported separately (merging it into the positive class would inflate
PAD-UFES-20 prevalence from 47.4% to 79.2%). A three-way variant is also supported.
"""
from __future__ import annotations

import re

from ..constants import NATIVE_TO_BINARY, BINARY_CLASSES

# normalization of raw label strings across the six sources' native taxonomies
_ALIASES = {
    "mel": "melanoma", "melanoma": "melanoma",
    "bcc": "basal_cell_carcinoma", "basal cell carcinoma": "basal_cell_carcinoma",
    "scc": "squamous_cell_carcinoma", "squamous cell carcinoma": "squamous_cell_carcinoma",
    "ak": "actinic_keratosis", "akiec": "actinic_keratosis",
    "actinic keratosis": "actinic_keratosis",
    "nv": "melanocytic_nevus", "nevus": "melanocytic_nevus",
    "melanocytic nevus": "melanocytic_nevus",
    "bkl": "benign_keratosis", "seborrheic keratosis": "seborrheic_keratosis",
    "benign keratosis": "benign_keratosis",
    "df": "dermatofibroma", "dermatofibroma": "dermatofibroma",
    "vasc": "vascular_lesion", "vascular lesion": "vascular_lesion",
    "sl": "solar_lentigo", "solar lentigo": "solar_lentigo",
    "blue nevus": "blue_nevus",
    "lentigo maligna": "lentigo_maligna_in_situ",
    "lmis": "lentigo_maligna_in_situ",
}


def normalize_label(raw: str) -> str:
    """Lower-case, strip, and resolve aliases to a canonical native label key."""
    key = re.sub(r"[\s\-]+", " ", str(raw).strip().lower())
    if key in _ALIASES:
        return _ALIASES[key]
    return key.replace(" ", "_")


def to_binary(raw: str, actinic_separate: bool = True) -> int | None:
    """Return 1 (malignant), 0 (non-malignant), or None if the label is excluded
    (e.g. actinic keratosis when reported separately and filtered out upstream).

    Actinic keratosis maps to non-malignant (0) by default; callers that report it
    separately can drop it before training."""
    native = normalize_label(raw)
    target = NATIVE_TO_BINARY.get(native)
    if target is None:
        return None
    return BINARY_CLASSES.index(target)


def to_three_way(raw: str) -> str:
    """Three-way variant: {malignant, actinic_keratosis, non_malignant}."""
    native = normalize_label(raw)
    if native == "actinic_keratosis":
        return "actinic_keratosis"
    bt = NATIVE_TO_BINARY.get(native)
    return bt if bt is not None else "unknown"


def is_actinic_keratosis(raw: str) -> bool:
    return normalize_label(raw) == "actinic_keratosis"
