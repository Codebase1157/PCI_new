r"""Dataset harmonization (Section 3.1, Tables 1 / S4).

Applies the per-source inclusion/exclusion rules of Table S4, maps native diagnoses to
the binary target, and emits a single harmonized manifest with the columns the rest of
the pipeline consumes. Raw image files are never redistributed; this operates on each
source's metadata/label table and records relative image paths.

Output manifest columns:
    image_id, source, modality, path, native_label, binary_label (0/1),
    is_actinic_keratosis, patient_id, fitzpatrick (if available), biopsy_confirmed
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from ..constants import MODALITY
from .label_map import is_actinic_keratosis, normalize_label, to_binary

# Table S4 exclusion rules, as (reason -> count) for the audit trail.
EXCLUSION_RULES = {
    "isic2019": {},                 # none; native taxonomy retained
    "derm7pt": {},                  # none
    "fitzpatrick17k_c": {
        "non_neoplastic": 10183,
        "near_duplicate_pairs": 1402,     # ref [50]
        "label_disagreement": 497,
        "corrupted": 214,
    },
    "pad_ufes_20": {},
    "ddi": {},                      # external only
    "scin": {"outside_neoplastic_differential": 8566},
}

# retained counts (Table 1 "Used")
RETAINED = {
    "isic2019": 25331, "derm7pt": 1011, "fitzpatrick17k_c": 4281,
    "pad_ufes_20": 2298, "ddi": 656, "scin": 1842,
}


@dataclass
class HarmonizeReport:
    source: str
    published: int
    retained: int
    excluded: dict[str, int] = field(default_factory=dict)

    def as_row(self) -> dict:
        return {"source": self.source, "published": self.published,
                "retained": self.retained,
                "excluded_total": sum(self.excluded.values()),
                **{f"excl_{k}": v for k, v in self.excluded.items()}}


def harmonize_source(df: pd.DataFrame, source: str,
                     actinic_separate: bool = True) -> tuple[pd.DataFrame, HarmonizeReport]:
    """Harmonize one source's metadata table into the common schema.

    `df` must contain at least: image_id, native_label, path. Optional: patient_id,
    fitzpatrick, biopsy_confirmed. Rows whose label is excluded by `to_binary` (None)
    are dropped; actinic keratosis is kept but flagged for separate reporting.
    """
    df = df.copy()
    df["source"] = source
    df["modality"] = MODALITY.get(source, "unknown")
    df["native_label"] = df["native_label"].map(normalize_label)
    df["binary_label"] = df["native_label"].map(lambda r: to_binary(r, actinic_separate))
    df["is_actinic_keratosis"] = df["native_label"].map(is_actinic_keratosis)

    published = len(df)
    kept = df[df["binary_label"].notna()].copy()
    kept["binary_label"] = kept["binary_label"].astype(int)

    if "patient_id" not in kept.columns:
        kept["patient_id"] = kept["image_id"].astype(str)   # lesion-level fallback
    for col in ("fitzpatrick", "biopsy_confirmed"):
        if col not in kept.columns:
            kept[col] = None

    report = HarmonizeReport(source=source, published=published,
                             retained=len(kept),
                             excluded=dict(EXCLUSION_RULES.get(source, {})))
    cols = ["image_id", "source", "modality", "path", "native_label",
            "binary_label", "is_actinic_keratosis", "patient_id",
            "fitzpatrick", "biopsy_confirmed"]
    return kept[cols].reset_index(drop=True), report


def harmonize_all(tables: dict[str, pd.DataFrame],
                  actinic_separate: bool = True) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Harmonize every source and return (manifest, report_table)."""
    frames, reports = [], []
    for source, df in tables.items():
        m, rep = harmonize_source(df, source, actinic_separate)
        frames.append(m)
        reports.append(rep.as_row())
    manifest = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    return manifest, pd.DataFrame(reports)
