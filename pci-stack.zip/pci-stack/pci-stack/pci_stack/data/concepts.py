r"""22-concept clinical layer provenance and masking (Section 4.3, Table S5).

Provides the concept list, their sources and coverage, and a builder that assembles the
per-image concept target matrix `C` and availability mask `M` consumed by the masked
concept BCE of eq (11). Missing annotations are masked out; only concepts with an
available label contribute to the per-image loss.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..constants import CONCEPTS, CONCEPT_PSEUDO_LABELLED, CONCEPT_SOURCE

# coverage per source group (Table S5)
COVERAGE = {"derm7pt_checklist": 1.00, "skincon": 0.206, "monet_pseudo": 1.00}

# MONET pseudo-label validation vs the expert subset (n = 892), Cohen's kappa
MONET_KAPPA = {
    "nodular_morphology": 0.78, "papular_morphology": 0.81, "plaque_morphology": 0.76,
    "milia_like_cysts": 0.72, "comedo_like_openings": 0.75, "pink_coloration": 0.83,
    "brown_black_coloration": 0.86,
}


def concept_table() -> pd.DataFrame:
    """Reproduce the Table S5 provenance table."""
    rows = []
    for i, name in enumerate(CONCEPTS):
        src = CONCEPT_SOURCE[i]
        rows.append({
            "index": i + 1,
            "concept": name,
            "source": src,
            "coverage": COVERAGE[src],
            "pseudo_labelled": CONCEPT_PSEUDO_LABELLED[i],
            "kappa_vs_expert": MONET_KAPPA.get(name, np.nan),
        })
    return pd.DataFrame(rows)


def build_concept_targets(annotations: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """From a per-image annotation frame (image_id index, one column per concept with
    values in {0, 1, NaN}) build the target matrix C and the availability mask M for
    eq (11).

    Returns (C, M), both (n, 22); NaN entries become mask = 0 and target 0 (ignored).
    """
    cols = [c for c in CONCEPTS]
    A = annotations.reindex(columns=cols)
    M = (~A.isna()).astype(np.float32).to_numpy()
    C = A.fillna(0.0).astype(np.float32).to_numpy()
    return C, M


def coverage_report(C_mask: np.ndarray) -> pd.DataFrame:
    """Observed per-concept annotation coverage from a mask matrix M (n, 22)."""
    cov = C_mask.mean(axis=0)
    return pd.DataFrame({"concept": CONCEPTS, "observed_coverage": np.round(cov, 3)})
