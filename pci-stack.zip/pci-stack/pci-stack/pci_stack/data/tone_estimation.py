r"""Label-free skin-tone estimation (Section 3.2).

Skin tone is *estimated*, not assumed, because two of the six datasets carry no tone
annotation and the other four record it on incompatible scales. The estimate is the
annulus-ITA of generators.ita (eq 4), binned with the Del Bino categories.

Two safeguards (Section 3.2):
  * agreement with the recorded Fitzpatrick label is quantified on the two training
    sources that carry one (quadratic-weighted kappa, exact 3-category agreement) —
    see `agreement`, reproducing Table S6;
  * ITA enters only the dependence penalty (eq 10) and the counterfactual target
    search (eq 6); it is NEVER a grouping variable for fairness reporting, which is
    always stratified by the externally supplied Fitzpatrick annotation.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..constants import ita_to_bin
from ..generators.ita import estimate_ita


def estimate_tone_for_manifest(manifest: pd.DataFrame, image_loader,
                               mask_loader=None) -> pd.DataFrame:
    """Add `ita` and `ita_bin` columns to a harmonized manifest.

    `image_loader(path) -> (H, W, 3)` in [0, 1]; `mask_loader(path) -> (H, W)` lesion
    mask (optional; without it the whole image minus hair/specular is used).
    """
    df = manifest.copy()
    itas, bins = [], []
    for row in df.itertuples(index=False):
        img = image_loader(row.path)
        mask = mask_loader(row.path) if mask_loader else None
        ita = estimate_ita(img, mask)
        itas.append(ita)
        bins.append(ita_to_bin(ita))
    df["ita"] = itas
    df["ita_bin"] = bins
    return df


# --------------------------------------------------------------------------- #
# Table S6 agreement safeguards
# --------------------------------------------------------------------------- #
def _fitz_to_three(fitz: str) -> str:
    """Collapse a Fitzpatrick label to the three Del Bino-aligned categories."""
    f = str(fitz).upper().replace(" ", "")
    if f in ("I", "II", "I-II", "1", "2"):
        return "light"
    if f in ("III", "IV", "III-IV", "3", "4"):
        return "intermediate"
    if f in ("V", "VI", "V-VI", "5", "6"):
        return "dark"
    return "unknown"


_ORDER = {"light": 0, "intermediate": 1, "dark": 2}


def quadratic_weighted_kappa(a: list[int], b: list[int], k: int = 3) -> float:
    """Cohen's quadratic-weighted kappa for ordinal categories 0..k-1."""
    a = np.asarray(a)
    b = np.asarray(b)
    O = np.zeros((k, k))
    for i, j in zip(a, b):
        O[i, j] += 1
    w = np.zeros((k, k))
    for i in range(k):
        for j in range(k):
            w[i, j] = (i - j) ** 2 / (k - 1) ** 2
    act_hist = O.sum(axis=1)
    pred_hist = O.sum(axis=0)
    E = np.outer(act_hist, pred_hist) / O.sum()
    num = (w * O).sum()
    den = (w * E).sum()
    return float(1 - num / den) if den > 0 else 0.0


def agreement(df: pd.DataFrame) -> dict:
    """Reproduce the Table S6 agreement statistics for a source carrying a Fitzpatrick
    label. Expects `ita_bin` and `fitzpatrick` columns."""
    sub = df[df["fitzpatrick"].notna()].copy()
    sub["est3"] = sub["ita_bin"].map(_ORDER)
    sub["rec3"] = sub["fitzpatrick"].map(_fitz_to_three).map(_ORDER)
    sub = sub[sub["rec3"].notna() & sub["est3"].notna()]
    est = sub["est3"].astype(int).tolist()
    rec = sub["rec3"].astype(int).tolist()
    if not est:
        return {"n": 0, "qwk": float("nan"), "exact3": float("nan")}
    qwk = quadratic_weighted_kappa(est, rec)
    exact = float(np.mean(np.array(est) == np.array(rec)) * 100)
    return {"n": len(est), "qwk": round(qwk, 2), "exact3": round(exact, 1)}


def confusion(df: pd.DataFrame) -> pd.DataFrame:
    """Category-level confusion (estimated rows x recorded columns), Table S6."""
    sub = df[df["fitzpatrick"].notna()].copy()
    sub["est"] = sub["ita_bin"]
    sub["rec"] = sub["fitzpatrick"].map(_fitz_to_three)
    order = ["light", "intermediate", "dark"]
    return pd.crosstab(sub["est"], sub["rec"]).reindex(index=order, columns=order,
                                                       fill_value=0)
