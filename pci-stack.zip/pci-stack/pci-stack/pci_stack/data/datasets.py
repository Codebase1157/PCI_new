r"""Dataset / loader glue.

A thin image loader and a torch-free manifest dataset that yields rows for the trainer.
The actual pixel loading depends on the raw files, which are not redistributed (see
docs/data_access.md); `ImageLoader` resolves a manifest `path` against `data_root`.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


class ImageLoader:
    """Load an (H, W, 3) float image in [0, 1] from a manifest-relative path."""

    def __init__(self, data_root: str = "data", size: int | None = 384):
        self.root = Path(data_root)
        self.size = size

    def __call__(self, path: str) -> np.ndarray:
        full = self.root / path if not Path(path).is_absolute() else Path(path)
        try:
            from PIL import Image

            img = Image.open(full).convert("RGB")
            if self.size:
                img = img.resize((self.size, self.size))
            return np.asarray(img, dtype=np.float32) / 255.0
        except FileNotFoundError:
            raise FileNotFoundError(
                f"image not found: {full}. Raw datasets are not vendored; "
                f"see docs/data_access.md.")


class ManifestDataset:
    """Index a harmonized (and split) manifest. Framework-agnostic; a torch Dataset
    wrapper can subclass this and call `load(i)`."""

    def __init__(self, manifest: pd.DataFrame, loader: ImageLoader,
                 role: str | None = None):
        df = manifest
        if role is not None:
            df = df[df["role"] == role]
        self.df = df.reset_index(drop=True)
        self.loader = loader

    def __len__(self) -> int:
        return len(self.df)

    def row(self, i: int):
        return self.df.iloc[i]

    def load(self, i: int):
        r = self.df.iloc[i]
        img = self.loader(r["path"])
        return {
            "image": img,
            "label": int(r["binary_label"]),
            "ita": float(r.get("ita", np.nan)),
            "ita_bin": r.get("ita_bin", "na"),
            "modality": r["modality"],
            "source": r["source"],
            "image_id": r["image_id"],
            "patient_id": r["patient_id"],
        }
