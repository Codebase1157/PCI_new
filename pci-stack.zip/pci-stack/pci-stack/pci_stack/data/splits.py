r"""Leave-one-domain-out (LODO) split generation (Section 3.3).

Each LODO fold trains on three sources and is evaluated on the fourth. Within each fold
the three training sources are split at patient level into disjoint partitions:

    learner_train (70%)  |  level1_oof (15%)  |  conformal_calib (15%)

none overlapping the training-domain validation set used for model selection, so no
image serves two roles. Splits are patient-level where identifiers exist and lesion-
level otherwise, preventing the train-test overlap documented for derived benchmarks
[50]. The external sets (DDI, SCIN) are never touched during training.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from ..constants import TRAINING_SOURCES


@dataclass
class SplitFractions:
    learner_train: float = 0.70
    level1_oof: float = 0.15
    conformal_calib: float = 0.15
    val: float = 0.0            # training-domain validation carved from learner_train

    def normalized(self):
        s = self.learner_train + self.level1_oof + self.conformal_calib
        return (self.learner_train / s, self.level1_oof / s, self.conformal_calib / s)


def _assign_patient_level(df: pd.DataFrame, fracs: SplitFractions,
                          seed: int) -> pd.Series:
    """Assign each patient (or lesion, when no patient id) to a role, patient-disjoint."""
    rng = np.random.default_rng(seed)
    lt, l1, cc = fracs.normalized()
    roles = np.empty(len(df), dtype=object)
    # group by patient so no patient spans two roles
    groups = df.groupby("patient_id").indices
    keys = list(groups.keys())
    rng.shuffle(keys)
    # distribute patients to roles by target fraction of *images*
    target = {"learner_train": lt, "level1_oof": l1, "conformal_calib": cc}
    counts = {k: 0 for k in target}
    total = len(df)
    for k in keys:
        idx = groups[k]
        # pick the role currently furthest below its target share
        deficits = {r: target[r] - counts[r] / max(total, 1) for r in target}
        role = max(deficits, key=deficits.get)
        roles[idx] = role
        counts[role] += len(idx)
    return pd.Series(roles, index=df.index)


def make_lodo_splits(manifest: pd.DataFrame, held_out: str,
                     fracs: SplitFractions | None = None,
                     val_fraction: float = 0.15,
                     seed: int = 2026) -> pd.DataFrame:
    """Build the split table for one LODO fold.

    Returns a copy of the training-source rows with a `role` column in
    {learner_train, level1_oof, conformal_calib, val}; the held-out source rows get
    role = 'heldout_test'. Model selection uses `val`, carved patient-disjointly from
    learner_train so no held-out-domain information reaches selection.
    """
    assert held_out in TRAINING_SOURCES, held_out
    fracs = fracs or SplitFractions()
    df = manifest[manifest["source"].isin(TRAINING_SOURCES)].copy()

    train_df = df[df["source"] != held_out].copy()
    held_df = df[df["source"] == held_out].copy()
    held_df["role"] = "heldout_test"

    train_df["role"] = _assign_patient_level(train_df, fracs, seed)

    # carve a training-domain validation set out of learner_train, patient-disjoint
    rng = np.random.default_rng(seed + 1)
    lt_mask = train_df["role"] == "learner_train"
    lt_patients = np.asarray(train_df.loc[lt_mask, "patient_id"].unique(), dtype=object)
    rng.shuffle(lt_patients)
    n_val = int(round(val_fraction * len(lt_patients)))
    val_patients = set(lt_patients[:n_val])
    train_df.loc[lt_mask & train_df["patient_id"].isin(val_patients), "role"] = "val"

    out = pd.concat([train_df, held_df], ignore_index=True)
    out["fold"] = held_out
    return out


def all_folds(manifest: pd.DataFrame, fracs: SplitFractions | None = None,
              seed: int = 2026) -> dict[str, pd.DataFrame]:
    """Generate the four LODO folds."""
    return {src: make_lodo_splits(manifest, src, fracs, seed=seed)
            for src in TRAINING_SOURCES}


def split_summary(fold_df: pd.DataFrame) -> pd.DataFrame:
    """Per-role image counts and malignant prevalence, for the split manifest README."""
    g = fold_df.groupby("role").agg(
        images=("image_id", "count"),
        patients=("patient_id", "nunique"),
        malignant=("binary_label", "sum"),
    )
    g["prevalence"] = (g["malignant"] / g["images"]).round(3)
    return g.reset_index()
