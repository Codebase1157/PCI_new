r"""Leave-one-domain-out driver (Section 3.3).

Orchestrates, per fold: stage-1 learner training, out-of-fold level-1 + meta-fusion,
conformal calibration, and held-out-domain evaluation. Hyper-parameters are frozen
after the first fold. The external sets (DDI, SCIN) are evaluated exactly once, after
all folds, by `evaluate_external`.

This module is the coordination layer; the per-fold data assembly (image loading) is
supplied by the caller because raw datasets are not vendored.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..constants import TRAINING_SOURCES
from ..utils.logging import get_logger


@dataclass
class FoldArtifacts:
    fold: str
    zoo: object = None
    meta: object = None
    calibrator: object = None
    kappa: float = 0.15
    metrics: dict = field(default_factory=dict)


class LODORunner:
    def __init__(self, cfg, fold_builder, device="cpu"):
        """`fold_builder(fold)` returns the data handles for one fold:
        learner loaders, engine, level-1 inputs, calibration inputs, held-out eval set.
        """
        self.cfg = cfg
        self.fold_builder = fold_builder
        self.device = device
        self.log = get_logger("lodo")
        self.frozen = False

    def run_fold(self, fold: str, train_stage1, train_stage2, calibrate, evaluate):
        self.log.info("=== LODO fold: held-out = %s ===", fold)
        handles = self.fold_builder(fold)
        art = FoldArtifacts(fold=fold)
        art.zoo = train_stage1(handles, frozen=self.frozen)
        art.meta = train_stage2(handles, art.zoo)
        art.calibrator, art.kappa = calibrate(handles, art.zoo, art.meta)
        art.metrics = evaluate(handles, art.zoo, art.meta, art.calibrator, art.kappa)
        self.frozen = True        # freeze hyper-parameters after the first fold
        return art

    def run_all(self, train_stage1, train_stage2, calibrate, evaluate,
                folds=None):
        folds = folds or TRAINING_SOURCES
        return {f: self.run_fold(f, train_stage1, train_stage2, calibrate, evaluate)
                for f in folds}
