r"""Evaluation (Sections 5-6): discrimination, fairness, calibration and conformal
coverage, with patient-level bootstrap CIs.

Takes fused probabilities, labels and the externally supplied Fitzpatrick annotation
(never the estimated ITA — Section 3.2) and returns the quantities reported in
Tables 2, 3, 6 and S11.
"""
from __future__ import annotations

import numpy as np

from ..conformal.abstention import abstain
from ..conformal.predict_set import prediction_set
from ..utils.metrics import (
    auroc,
    bootstrap_ci,
    confusion_counts,
    coverage,
    equal_opportunity_difference,
    expected_calibration_error,
    light_to_dark_gap,
    mean_set_size,
    sensitivity_at_specificity,
    worst_group_auroc,
)


def discrimination_report(y, prob, fitzpatrick=None, patient_ids=None,
                          threshold=0.5):
    """AUROC, worst-group AUROC, light-to-dark gap, EOD, Se@95Sp, ECE, with CIs."""
    y = np.asarray(y).astype(int)
    prob = np.asarray(prob, dtype=float)
    out = {}
    pt, lo, hi = bootstrap_ci(auroc, y, prob, patient_ids=patient_ids)
    out["auroc"] = {"point": pt, "ci": [lo, hi]}
    out["ece"] = expected_calibration_error(y, prob)
    out["se_at_95sp"] = sensitivity_at_specificity(y, prob, 0.95)

    if fitzpatrick is not None:
        fitz = np.asarray(fitzpatrick)
        out["worst_group_auroc"] = worst_group_auroc(y, prob, fitz)
        out["light_to_dark_gap"] = light_to_dark_gap(y, prob, fitz)
        y_pred = (prob >= threshold).astype(int)
        out["eod"] = equal_opportunity_difference(y, y_pred, fitz)
        out["per_stratum"] = {}
        for g in ["I-II", "III-IV", "V-VI"]:
            m = fitz == g
            if m.sum() > 1:
                out["per_stratum"][g] = {
                    "auroc": auroc(y[m], prob[m]),
                    **confusion_counts(y[m], y_pred[m]),
                }
    return out


def conformal_report(prob_matrix, y, tone, domain, calibrator, kappa,
                     learner_probs, fused_prob, shift_weights=None,
                     unseen_target=False):
    """Coverage and set size per Fitzpatrick stratum and worst cell, with and without
    the abstention referrals (Table 6, Section 6.7)."""
    sets = prediction_set(prob_matrix, tone, domain, calibrator,
                          shift_weights=shift_weights, unseen_target=unseen_target)
    mask = abstain(sets, learner_probs, fused_prob, kappa=kappa)
    y = np.asarray(y).astype(int)

    kept = ~mask
    report = {
        "abstain_frac": float(mask.mean()),
        "non_abstained": {
            "coverage": coverage([s for s, k in zip(sets, kept) if k], y[kept]),
            "mean_set_size": mean_set_size([s for s, k in zip(sets, kept) if k]),
        },
        "all_samples": {
            # deferred cases counted as miscoverages (Section 6.7)
            "coverage": float(np.mean([
                (yy in s) and keep for s, yy, keep in zip(sets, y, kept)
            ])),
            "mean_set_size": mean_set_size(sets),
        },
    }
    return report


def paired_difference(y, prob_a, prob_b, groups=None, patient_ids=None,
                      n_resamples=2000):
    """Patient-level bootstrap of the worst-group-AUROC difference between two models
    (Table S10)."""
    def diff(y_, pa_, pb_, g_):
        if groups is None:
            return auroc(y_, pa_) - auroc(y_, pb_)
        return worst_group_auroc(y_, pa_, g_) - worst_group_auroc(y_, pb_, g_)

    g = np.asarray(groups) if groups is not None else np.zeros(len(y))
    pt, lo, hi = bootstrap_ci(lambda yy, a, b, gg: diff(yy, a, b, gg),
                              np.asarray(y), np.asarray(prob_a), np.asarray(prob_b), g,
                              patient_ids=patient_ids, n_resamples=n_resamples)
    return {"difference": pt, "ci": [lo, hi]}
