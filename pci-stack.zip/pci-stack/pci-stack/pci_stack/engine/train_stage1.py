r"""Stage-1: train the four counterfactual-diverse learners (Section 4.7).

30 epochs, AdamW @ 1e-4 cosine, batch 32, counterfactual views generated on the fly.
Each learner minimizes its contract's objective (eq 13). This module provides the
training step and loop given a learner, a data iterator yielding batches of images +
labels + nuisance, and a CounterfactualEngine; the data plumbing (real image loading)
is the caller's responsibility since raw datasets are not vendored.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from ..generators.engine import CounterfactualEngine
from ..losses.objectives import LearnerWeights, learner_objective
from ..models.grl import dann_lambda
from ..utils.logging import JsonlLogger, get_logger


@dataclass
class Stage1Config:
    epochs: int = 30
    lr: float = 1e-4
    weight_decay: float = 0.05
    batch_size: int = 32
    weights: LearnerWeights = None

    def __post_init__(self):
        if self.weights is None:
            self.weights = LearnerWeights()


def _to_tensor(imgs: list[np.ndarray], device) -> torch.Tensor:
    arr = np.stack(imgs).astype(np.float32)          # (B, H, W, 3)
    return torch.from_numpy(arr).permute(0, 3, 1, 2).to(device)


def train_step(learner, batch, engine: CounterfactualEngine,
               weights: LearnerWeights, device, total_steps: int, step: int):
    """One optimization step for a learner under its contract (eq 13)."""
    images = batch["images"]                          # list of (H,W,3) float arrays
    labels = torch.as_tensor(batch["labels"], device=device).long()
    masks = batch.get("masks")
    nuisance = batch.get("nuisance")                  # (B,) tone/domain ids

    x = _to_tensor(images, device)
    grl_lambda = dann_lambda(step, total_steps) if "adv" in learner.spec.active_terms else 0.0
    out = learner(x, grl_lambda=grl_lambda)

    # counterfactual views required by this learner's contract (eq 9)
    cf_logits = None
    if "cf" in learner.spec.active_terms:
        cf_logits = []
        for i, img in enumerate(images):
            m = masks[i] if masks else None
            views = engine.all_views(img, learner.spec.counterfactual_views, m)
            if views:
                xv = _to_tensor(views, device)
                cf_logits.append(learner(xv)["logits"].mean(0, keepdim=True))
        cf_logits = [torch.cat(cf_logits, 0)] if cf_logits else None

    s = (torch.as_tensor(nuisance, device=device).float().unsqueeze(1)
         if nuisance is not None else None)
    loss, comps = learner_objective(
        out["logits"], labels, weights,
        cf_logits=cf_logits, repr_z=out.get("z"), nuisance_s=s,
        concept_logits=out.get("concept_logits"),
        concept_targets=batch.get("concept_targets"),
        concept_mask=batch.get("concept_mask"),
        nuisance_logits=out.get("nuisance_logits"),
        nuisance_target=(torch.as_tensor(nuisance, device=device)
                         if nuisance is not None else None),
    )
    return loss, comps


def train_learner(learner, data, engine, cfg: Stage1Config, device="cpu",
                  log_path: str | None = None, name: str = "M?"):
    """Full stage-1 training loop for one learner. `data` is any iterable of batches
    (with a `.reset(epoch)` and `__len__` if available)."""
    log = get_logger(f"stage1.{name}", logfile=log_path and log_path.replace(".jsonl", ".log"))
    jsonl = JsonlLogger(log_path) if log_path else None
    learner.to(device).train()
    opt = torch.optim.AdamW([p for p in learner.parameters() if p.requires_grad],
                            lr=cfg.lr, weight_decay=cfg.weight_decay)
    n_batches = len(data) if hasattr(data, "__len__") else 100
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg.epochs * n_batches)
    total_steps = cfg.epochs * n_batches
    step = 0
    for epoch in range(cfg.epochs):
        if hasattr(data, "reset"):
            data.reset(epoch)
        running = 0.0
        for batch in data:
            loss, comps = train_step(learner, batch, engine, cfg.weights,
                                     device, total_steps, step)
            opt.zero_grad()
            loss.backward()
            opt.step()
            sched.step()
            running += float(loss.detach())
            step += 1
            if jsonl:
                jsonl.log(epoch=epoch, step=step, loss=float(loss.detach()), **comps)
        log.info("epoch %d/%d  loss=%.4f", epoch + 1, cfg.epochs, running / max(n_batches, 1))
    if jsonl:
        jsonl.close()
    return learner
