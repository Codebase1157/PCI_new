r"""Stage-2: out-of-fold level-1 features + counterfactual-consistent meta-fusion
(Section 4.4, 4.7). 60 epochs on level-1 features.

`build_level1` produces the strictly out-of-fold level-1 matrix (eq 14) from trained
learner replicas; `train_meta_fusion` fits the gated meta-learner (eq 18-20).
"""
from __future__ import annotations

import numpy as np
import torch

from ..fusion.disagreement import disagreement_batch
from ..fusion.meta_learner import MetaConfig, MetaFusion, train_meta
from ..fusion.oof import OOFAssignment, build_oof_predictions
from ..utils.logging import get_logger


def build_level1(fit_predict_fns: dict, X, n_folds: int, patient_ids=None,
                 cf_probs_fns: dict | None = None, seed: int = 2026):
    """Construct out-of-fold level-1 features for every learner, eq (14).

    `fit_predict_fns[name](train_idx, predict_idx) -> prob array` trains a learner
    replica out of fold. `cf_probs_fns[name](idx) -> (len(idx), V)` optionally returns
    per-example counterfactual probabilities for the disagreement statistic (eq 15).

    Returns dict with 'p' (n,J), 'd' (n,J), learner order, and the fold assignment.
    """
    assignment = OOFAssignment.make(len(X), n_folds, patient_ids, seed)
    names = sorted(fit_predict_fns)
    P = np.stack([build_oof_predictions(fit_predict_fns[n], X, assignment)
                  for n in names], axis=1)                       # (n, J)
    if cf_probs_fns:
        D = np.stack([disagreement_batch(cf_probs_fns[n](np.arange(len(X))))
                      for n in names], axis=1)
    else:
        D = np.zeros_like(P)
    return {"p": P, "d": D, "order": names, "assignment": assignment}


class Level1Loader:
    """Minibatch iterator over precomputed level-1 features for the meta-learner."""

    def __init__(self, p, z, d, y, batch_size=256, cf_probs=None, s=None, seed=2026):
        self.p = torch.as_tensor(p, dtype=torch.float32)
        self.z = torch.as_tensor(z, dtype=torch.float32)
        self.d = torch.as_tensor(d, dtype=torch.float32)
        self.y = torch.as_tensor(y, dtype=torch.long)
        self.cf = None if cf_probs is None else torch.as_tensor(cf_probs, dtype=torch.float32)
        self.s = None if s is None else torch.as_tensor(s, dtype=torch.float32)
        self.bs = batch_size
        self.rng = np.random.default_rng(seed)
        self._perm = np.arange(len(self.y))

    def reset(self, epoch):
        self.rng.shuffle(self._perm)

    def __iter__(self):
        for i in range(0, len(self.y), self.bs):
            idx = self._perm[i:i + self.bs]
            batch = {"p": self.p[idx], "z": self.z[idx], "d": self.d[idx],
                     "y": self.y[idx]}
            if self.cf is not None:
                batch["cf_probs"] = [self.cf[idx]]
            if self.s is not None:
                batch["s"] = self.s[idx]
            yield batch

    def __len__(self):
        return (len(self.y) + self.bs - 1) // self.bs


def train_meta_fusion(level1, cfg: MetaConfig, device="cpu"):
    """Fit the meta-fusion network on level-1 features. `level1` is a Level1Loader."""
    log = get_logger("stage2.meta")
    model = MetaFusion(cfg)
    history = train_meta(model, level1, device=device)
    log.info("meta-fusion trained: final loss=%.4f", history[-1]["loss"])
    return model, history
