"""Training / evaluation engine: stage-1, stage-2, calibration, LODO, evaluation."""
from .train_stage1 import Stage1Config, train_learner, train_step
from .train_stage2 import Level1Loader, build_level1, train_meta_fusion
from .calibrate import calibrate_conformal
from .evaluate import conformal_report, discrimination_report, paired_difference
from .lodo import FoldArtifacts, LODORunner

__all__ = [
    "Stage1Config", "train_learner", "train_step",
    "build_level1", "Level1Loader", "train_meta_fusion",
    "calibrate_conformal",
    "discrimination_report", "conformal_report", "paired_difference",
    "LODORunner", "FoldArtifacts",
]
