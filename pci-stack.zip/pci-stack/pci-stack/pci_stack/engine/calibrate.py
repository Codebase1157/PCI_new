r"""Stage-2 tail: shift-aware group-conditional conformal calibration (Section 4.5).

Fits the Mondrian calibrator on the 15% conformal-calibration partition and calibrates
the abstention margin kappa. Adds ~4 minutes per fold (Section 4.7).
"""
from __future__ import annotations

import numpy as np

from ..conformal.abstention import calibrate_margin
from ..conformal.mondrian import MondrianCalibrator
from ..conformal.nonconformity import nonconformity
from ..utils.logging import get_logger


def calibrate_conformal(prob_matrix: np.ndarray, labels: np.ndarray,
                        tone: np.ndarray, domain: np.ndarray,
                        learner_probs: np.ndarray, fused_prob: np.ndarray,
                        alpha: float = 0.10, min_cell_count: int = 50,
                        delta: float = 0.10, weights: np.ndarray | None = None):
    """Fit the Mondrian calibrator (eq 22) and the abstention margin (eq 25).

    Returns (calibrator, kappa).
    """
    log = get_logger("calibrate")
    scores = nonconformity(prob_matrix, labels.astype(int))
    cal = MondrianCalibrator(alpha=alpha, min_cell_count=min_cell_count)
    cal.fit(scores, tone, domain, weights=weights)
    kappa = calibrate_margin(learner_probs, fused_prob, delta=delta)
    log.info("conformal calibrated: %d cells, kappa=%.3f (delta=%.2f)",
             len(cal.occupancy()), kappa, delta)
    return cal, kappa
