r"""Adapter / state checkpoint handling (the 'pretrained adapters' deliverable).

Only the trained LoRA adapters, the meta-fusion head, and the conformal calibration
state are released — not the base backbone weights (see LICENSE-PANDERM-NOTE.md). This
module reads `checkpoints/MANIFEST.json`, verifies integrity, and loads adapters into a
`LearnerZoo`. When the real adapter files are absent (a fresh clone, before the Zenodo
download), it reports clearly rather than failing silently.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_manifest(ckpt_dir: str = "checkpoints") -> dict:
    mp = Path(ckpt_dir) / "MANIFEST.json"
    if not mp.exists():
        raise FileNotFoundError(f"no checkpoint manifest at {mp}")
    return json.loads(mp.read_text())


def verify(ckpt_dir: str = "checkpoints") -> dict:
    """Check which adapter files are present and whether their hashes match."""
    manifest = read_manifest(ckpt_dir)
    root = Path(ckpt_dir)
    status = {}
    for entry in manifest.get("artifacts", []):
        p = root / entry["path"]
        if not p.exists():
            status[entry["path"]] = "MISSING (download from Zenodo)"
        elif entry.get("sha256") and entry["sha256"] != "<filled-at-release>":
            status[entry["path"]] = ("ok" if _sha256(p) == entry["sha256"]
                                     else "HASH MISMATCH")
        else:
            status[entry["path"]] = "present (hash not pinned)"
    return status


def load_adapters(zoo, fold: str, ckpt_dir: str = "checkpoints"):
    """Load per-learner LoRA adapter state for a given LODO fold into a LearnerZoo.

    Expects files under checkpoints/adapters/<fold>/<learner>.safetensors as declared
    in the manifest. Base backbone weights must already be present in the zoo.
    """
    import torch

    root = Path(ckpt_dir) / "adapters" / fold
    loaded = []
    for name in zoo.order:
        f = root / f"{name}.safetensors"
        if not f.exists():
            f = root / f"{name}.pt"
        if not f.exists():
            continue
        try:
            from safetensors.torch import load_file

            state = load_file(str(f))
        except Exception:
            state = torch.load(str(f), map_location="cpu")
        # load only lora_* and head params
        missing = zoo.learners[name].load_state_dict(state, strict=False)
        loaded.append(name)
    if not loaded:
        raise FileNotFoundError(
            f"no adapter files found under {root}. Download the release adapters "
            f"from Zenodo (see docs/data_access.md); the repo ships only the manifest.")
    return loaded
