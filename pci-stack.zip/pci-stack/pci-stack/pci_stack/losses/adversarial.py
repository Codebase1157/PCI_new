r"""Adversarial nuisance-invariance via gradient reversal, eq (12).

    L_adv = -E_x log q_psi( s | T_eta( z_4(x) ) )                                   (12)

A nuisance discriminator q_psi predicts s from a gradient-reversed projection of the
representation. The reversal (see models/grl.py) makes the encoder *maximize* the
discriminator's loss, pushing s-information out of z. Used by M4 (joint invariance).
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


class NuisanceDiscriminator(torch.nn.Module):
    """3-layer MLP head (512-256-K), GELU, dropout 0.1 (Table S1)."""

    def __init__(self, in_dim: int, num_nuisance: int,
                 hidden=(512, 256), dropout: float = 0.1):
        super().__init__()
        layers, d = [], in_dim
        for h in hidden:
            layers += [torch.nn.Linear(d, h), torch.nn.GELU(), torch.nn.Dropout(dropout)]
            d = h
        layers += [torch.nn.Linear(d, num_nuisance)]
        self.net = torch.nn.Sequential(*layers)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


def adversarial_loss(nuisance_logits: torch.Tensor,
                     nuisance_target: torch.Tensor) -> torch.Tensor:
    """Cross-entropy of the discriminator against the true nuisance label, eq (12).
    Because the input is gradient-reversed upstream, minimizing this w.r.t. the whole
    graph trains the encoder adversarially."""
    return F.cross_entropy(nuisance_logits, nuisance_target.long())
