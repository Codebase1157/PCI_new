r"""Composite training objectives.

Per-learner, eq (13):
    L_j = L_ce + lambda_cf L_cf^j + lambda_dep L_dep^j + lambda_con L_con
          + lambda_adv L_adv

Meta-learner, eq (19) with the consistency ramp eq (20):
    L_meta = L_ce + gamma_cf(t) L_cf^meta + gamma_dep HSIC(p(x), s) + gamma_e Omega_g
    gamma_cf(t) = gamma_cf^max * min(1, t / T_r)

Only the terms a learner's contract selects are active; weights come from Table S1.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F

from .adversarial import adversarial_loss
from .concept import masked_concept_bce
from .counterfactual import kl_consistency, paired_consistency, prob_consistency
from .hsic import class_conditional_hsic, hsic


@dataclass
class LearnerWeights:
    lambda_cf: float = 1.0
    lambda_dep: float = 0.5
    lambda_con: float = 0.3
    lambda_adv: float = 0.1


def learner_objective(
    logits: torch.Tensor,
    labels: torch.Tensor,
    weights: LearnerWeights,
    *,
    cf_logits: list[torch.Tensor] | None = None,
    repr_z: torch.Tensor | None = None,
    nuisance_s: torch.Tensor | None = None,
    concept_logits: torch.Tensor | None = None,
    concept_targets: torch.Tensor | None = None,
    concept_mask: torch.Tensor | None = None,
    nuisance_logits: torch.Tensor | None = None,
    nuisance_target: torch.Tensor | None = None,
    class_conditional_dep: bool = True,
) -> tuple[torch.Tensor, dict[str, float]]:
    """Return (total_loss, components). Terms with weight 0 or missing inputs are
    skipped, so the same function serves all four contracts (M1-M4)."""
    parts: dict[str, torch.Tensor] = {}
    ce = F.cross_entropy(logits, labels.long())
    parts["ce"] = ce
    total = ce

    if weights.lambda_cf and cf_logits:
        lcf = kl_consistency(logits, cf_logits)
        parts["cf"] = lcf
        total = total + weights.lambda_cf * lcf

    if weights.lambda_dep and repr_z is not None and nuisance_s is not None:
        if class_conditional_dep:
            ldep = class_conditional_hsic(repr_z, nuisance_s, labels)
        else:
            ldep = hsic(repr_z, nuisance_s)
        parts["dep"] = ldep
        total = total + weights.lambda_dep * ldep

    if weights.lambda_con and concept_logits is not None:
        lcon = masked_concept_bce(concept_logits, concept_targets, concept_mask)
        parts["con"] = lcon
        total = total + weights.lambda_con * lcon

    if weights.lambda_adv and nuisance_logits is not None:
        ladv = adversarial_loss(nuisance_logits, nuisance_target)
        parts["adv"] = ladv
        total = total + weights.lambda_adv * ladv

    return total, {k: float(v.detach()) for k, v in parts.items()}


@dataclass
class MetaWeights:
    gamma_cf_max: float = 1.0
    gamma_dep: float = 0.3
    gamma_e: float = 0.01
    T_r: int = 20


def consistency_ramp(epoch: int, gamma_cf_max: float, T_r: int) -> float:
    """eq (20): linear ramp so the invariance term cannot dominate early."""
    return float(gamma_cf_max * min(1.0, epoch / max(T_r, 1)))


def gating_entropy(gates: torch.Tensor) -> torch.Tensor:
    """Omega_g: mean entropy of the gating distribution (a mild regularizer).
    `gates` is (n, J), rows sum to 1."""
    ent = -(gates.clamp_min(1e-8).log() * gates).sum(dim=-1)
    return ent.mean()


def meta_objective(
    fused_logit: torch.Tensor,
    labels: torch.Tensor,
    gates: torch.Tensor,
    weights: MetaWeights,
    epoch: int,
    *,
    fused_prob: torch.Tensor | None = None,
    cf_probs: list[torch.Tensor] | None = None,
    paired: tuple[torch.Tensor, torch.Tensor] | None = None,
    nuisance_s: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, float]]:
    """eq (19)-(20). `fused_logit` is (n, C); `fused_prob` is the positive-class prob
    used for the consistency and dependence terms."""
    parts: dict[str, torch.Tensor] = {}
    ce = F.cross_entropy(fused_logit, labels.long())
    parts["ce"] = ce
    total = ce

    gamma_cf = consistency_ramp(epoch, weights.gamma_cf_max, weights.T_r)
    if gamma_cf and fused_prob is not None and (cf_probs or paired):
        lcf = prob_consistency(fused_prob, cf_probs or [])
        if paired is not None:
            lcf = lcf + paired_consistency(paired[0], paired[1])
        parts["cf_meta"] = lcf
        total = total + gamma_cf * lcf

    if weights.gamma_dep and fused_prob is not None and nuisance_s is not None:
        ldep = class_conditional_hsic(fused_prob.unsqueeze(-1), nuisance_s, labels)
        parts["dep"] = ldep
        total = total + weights.gamma_dep * ldep

    if weights.gamma_e:
        lent = gating_entropy(gates)
        parts["entropy"] = lent
        # entropy regularizer encourages non-degenerate gating -> subtract
        total = total - weights.gamma_e * lent

    out = {k: float(v.detach()) for k, v in parts.items()}
    out["gamma_cf"] = gamma_cf
    return total, out
