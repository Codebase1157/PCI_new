"""Invariance objectives (eq 9-13, 18-20)."""
from .hsic import HSICLoss, class_conditional_hsic, hsic
from .counterfactual import (
    LearnerConsistency,
    MetaConsistency,
    kl_consistency,
    paired_consistency,
    prob_consistency,
)
from .concept import ConceptLoss, masked_concept_bce
from .adversarial import NuisanceDiscriminator, adversarial_loss
from .objectives import (
    LearnerWeights,
    MetaWeights,
    consistency_ramp,
    gating_entropy,
    learner_objective,
    meta_objective,
)

__all__ = [
    "hsic", "class_conditional_hsic", "HSICLoss",
    "kl_consistency", "prob_consistency", "paired_consistency",
    "LearnerConsistency", "MetaConsistency",
    "masked_concept_bce", "ConceptLoss",
    "adversarial_loss", "NuisanceDiscriminator",
    "learner_objective", "meta_objective", "LearnerWeights", "MetaWeights",
    "consistency_ramp", "gating_entropy",
]
