r"""Clinical-concept layer loss, eq (11) — masked binary cross-entropy over the
22 concepts (Section 4.3, Table S5).

    L_con = -1/|K| * sum_{k in K} [ c_k log u_k + (1 - c_k) log(1 - u_k) ]          (11)

c_k in {0, 1} is the reference annotation for concept k, u_k the predicted concept
probability, |K| = 22. The term is evaluated only where an annotation for k exists
and is masked elsewhere (coverage varies: full for the 7 Derm7pt criteria, 20.6% for
the 8 SkinCon concepts, 100% for the 7 MONET pseudo-labels).
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def masked_concept_bce(concept_logits: torch.Tensor, targets: torch.Tensor,
                       mask: torch.Tensor) -> torch.Tensor:
    r"""eq (11). Shapes:
        concept_logits : (n, K) pre-sigmoid concept scores
        targets        : (n, K) in {0, 1}
        mask           : (n, K) in {0, 1}; 1 where an annotation exists
    """
    bce = F.binary_cross_entropy_with_logits(concept_logits, targets.float(),
                                             reduction="none")
    mask = mask.float()
    denom = mask.sum().clamp_min(1.0)
    return (bce * mask).sum() / denom


class ConceptLoss(torch.nn.Module):
    def __init__(self, num_concepts: int = 22):
        super().__init__()
        self.num_concepts = num_concepts

    def forward(self, concept_logits, targets, mask):
        assert concept_logits.shape[-1] == self.num_concepts
        return masked_concept_bce(concept_logits, targets, mask)
