r"""Hilbert-Schmidt Independence Criterion, eq (10), class-conditional (Reviewer 2.4).

    L_dep^j = HSIC(z_j(x), s) = 1/(n-1)^2 * tr(K H L H)                             (10)

K and L are the RBF kernel matrices of the representation z and the nuisance variable
s; H is the centering matrix. The target of eq (2) is independence *conditional on y*;
a plain HSIC penalizes unconditional dependence. The two coincide only when the
nuisance is independent of the label, which fails here (malignant prevalence differs
across tone bins). We therefore evaluate HSIC *within label strata* — separately over
the malignant and non-malignant members of each batch — and average, so label-
correlated signal is not suppressed along with the nuisance.
"""
from __future__ import annotations

import torch


def _rbf_kernel(x: torch.Tensor, sigma: float | None = None) -> torch.Tensor:
    """Gaussian (RBF) Gram matrix with the median heuristic for the bandwidth."""
    x = x.view(x.shape[0], -1).float()
    sq = torch.cdist(x, x) ** 2
    if sigma is None:
        with torch.no_grad():
            med = torch.median(sq[sq > 0]) if (sq > 0).any() else torch.tensor(1.0)
            sigma = torch.sqrt(0.5 * med + 1e-12).item()
    sigma = max(sigma, 1e-6)
    return torch.exp(-sq / (2 * sigma ** 2))


def _hsic_biased(K: torch.Tensor, L: torch.Tensor) -> torch.Tensor:
    """Biased HSIC estimator, eq (10). tr(K H L H) / (n-1)^2."""
    n = K.shape[0]
    if n < 2:
        return K.new_zeros(())
    H = torch.eye(n, device=K.device) - torch.full((n, n), 1.0 / n, device=K.device)
    Kc = H @ K @ H
    return torch.trace(Kc @ L) / ((n - 1) ** 2)


def hsic(z: torch.Tensor, s: torch.Tensor,
         sigma_z: float | None = None, sigma_s: float | None = None) -> torch.Tensor:
    """Unconditional HSIC between representation z and nuisance s."""
    K = _rbf_kernel(z, sigma_z)
    L = _rbf_kernel(s.float().view(s.shape[0], -1), sigma_s)
    return _hsic_biased(K, L)


def class_conditional_hsic(z: torch.Tensor, s: torch.Tensor, y: torch.Tensor,
                           sigma_z: float | None = None,
                           sigma_s: float | None = None) -> torch.Tensor:
    r"""HSIC evaluated within each label stratum and averaged, eq (10) as amended.

    Parameters
    ----------
    z : (n, d) representation.
    s : (n, ...) nuisance variable (ITA, domain id, or one-hot).
    y : (n,) binary labels; strata are y == 0 and y == 1.
    """
    vals = []
    for c in torch.unique(y):
        m = y == c
        if m.sum() >= 2:
            vals.append(hsic(z[m], s[m], sigma_z, sigma_s))
    if not vals:
        return z.new_zeros(())
    return torch.stack(vals).mean()


class HSICLoss(torch.nn.Module):
    """Module wrapper so the dependence penalty plugs into an objective registry."""

    def __init__(self, class_conditional: bool = True):
        super().__init__()
        self.class_conditional = class_conditional

    def forward(self, z: torch.Tensor, s: torch.Tensor,
                y: torch.Tensor | None = None) -> torch.Tensor:
        if self.class_conditional:
            if y is None:
                raise ValueError("class_conditional HSIC requires labels y")
            return class_conditional_hsic(z, s, y)
        return hsic(z, s)
