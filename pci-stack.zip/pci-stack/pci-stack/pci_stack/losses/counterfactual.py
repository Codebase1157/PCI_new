r"""Counterfactual-consistency penalties.

Per-learner, eq (9):
    L_cf^j = E_x E_{x' ~ C_j(x)} D_KL( f_j(x) || f_j(x') )

Meta-learner, eq (18) — symmetric squared difference over synthetic views plus the
real Derm7pt pairs:
    L_cf^meta = E_x E_{x' ~ C(x)} (p(x) - p(x'))^2 + E_{(x, x~) in P} (p(x) - p(x~))^2
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def kl_consistency(logits: torch.Tensor, cf_logits_list: list[torch.Tensor]) -> torch.Tensor:
    r"""eq (9). Mean KL( softmax(logits) || softmax(cf_logits) ) over counterfactual
    views. `cf_logits_list` is a list of (n, C) tensors, one per view."""
    if not cf_logits_list:
        return logits.new_zeros(())
    p = F.log_softmax(logits, dim=-1)
    total = logits.new_zeros(())
    for cf in cf_logits_list:
        q = F.softmax(cf, dim=-1)
        # KL(p || q) with p = softmax(logits): sum p (log p - log q)
        kl = F.kl_div(F.log_softmax(cf, dim=-1), F.softmax(logits, dim=-1),
                      reduction="batchmean", log_target=False)
        total = total + kl
    return total / len(cf_logits_list)


def prob_consistency(prob: torch.Tensor, cf_prob_list: list[torch.Tensor]) -> torch.Tensor:
    r"""Squared-difference consistency on the fused probability, the first term of
    eq (18). `prob` and each entry of `cf_prob_list` are (n,) positive-class probs."""
    if not cf_prob_list:
        return prob.new_zeros(())
    total = prob.new_zeros(())
    for cf in cf_prob_list:
        total = total + ((prob - cf) ** 2).mean()
    return total / len(cf_prob_list)


def paired_consistency(prob_a: torch.Tensor, prob_b: torch.Tensor) -> torch.Tensor:
    """Second term of eq (18): consistency over real Derm7pt acquisition pairs."""
    if prob_a is None or prob_b is None or prob_a.numel() == 0:
        return torch.zeros((), device=prob_a.device if prob_a is not None else "cpu")
    return ((prob_a - prob_b) ** 2).mean()


class LearnerConsistency(torch.nn.Module):
    """eq (9) wrapper for a single learner."""

    def forward(self, logits, cf_logits_list):
        return kl_consistency(logits, cf_logits_list)


class MetaConsistency(torch.nn.Module):
    """eq (18): synthetic-view + paired consistency on the fused score."""

    def forward(self, prob, cf_prob_list, paired=None):
        loss = prob_consistency(prob, cf_prob_list)
        if paired is not None:
            loss = loss + paired_consistency(paired[0], paired[1])
        return loss
