# Data and weight access

This repository ships **code, configs, splits, adapters (manifest), logs and result
tables** — but **no** raw images and **no** base backbone weights. Lesion photographs are
never reproduced here or in the paper figures, in accordance with the dataset licences.
This page lists where to obtain each piece and where to put it.

## Expected local layout

```
data/
├── isic2019/          metadata.csv + images/
├── derm7pt/           metadata.csv + images/  (+ clinical/dermoscopic pairs)
├── fitzpatrick17k_c/  metadata.csv + images/
├── pad_ufes_20/       metadata.csv + images/
├── ddi/               metadata.csv + images/   (external only)
├── scin/              metadata.csv + images/   (external only)
└── backbones/
    ├── panderm_vit_l.safetensors   (research license)
    ├── dinov2_l.safetensors        (Apache-2.0; or pulled by timm)
    └── swin_b.safetensors          (MIT; or pulled by timm)
```

`data_root` is set in `configs/default.yaml`. Each `metadata.csv` needs at minimum:
`image_id, native_label, path`, and optionally `patient_id, fitzpatrick,
biopsy_confirmed`. `scripts/00_prepare_data.py` harmonizes them.

## Datasets (Table 1)

| Dataset | Role | Source |
|---------|------|--------|
| ISIC 2019 (incl. HAM10000 [49]) | LODO train/test | https://challenge.isic-archive.com/data/ |
| Derm7pt [37] | LODO train/test (+ real acquisition pairs) | https://derm.cs.sfu.ca/ |
| Fitzpatrick17k-C [26,50] | LODO train/test | cleaned release of the Fitzpatrick17k dataset |
| PAD-UFES-20 [51] | LODO train/test | https://data.mendeley.com/datasets/zr7vgbcyr2 |
| DDI [2] | **external only** | https://ddi-dataset.github.io/ |
| SCIN [52] | **external only** | https://github.com/google-research-datasets/scin |

Use the exact released versions; harmonization counts (Table S4) assume them. The
Fitzpatrick17k-C reduction (16,577 → 4,281) and the SCIN restriction to the neoplastic
differential (10,408 → 1,842) are applied by `pci_stack.data.harmonize`.

## Backbones

| Backbone | Learners | License | Source |
|----------|----------|---------|--------|
| PanDerm ViT-L [11] | M1, M3 (shared pass) | **research license** | obtain from the PanDerm authors; see `../LICENSE-PANDERM-NOTE.md` |
| DINOv2-L | M2 | Apache-2.0 | `facebookresearch/dinov2` (or `timm`) |
| Swin-B | M4 | MIT | `microsoft/Swin` (or `timm`) |

PanDerm weights are **not** redistributed. Our released LoRA adapters attach to the
official PanDerm weights; downloading PanDerm implies acceptance of its research license.

## Concept annotations (Table S5)

The 22-concept layer draws on the Derm7pt seven-point checklist [37] (full coverage),
SkinCon [36] (20.6%), and MONET [39] pseudo-labels (100%, validated against the expert
subset, n = 892). The MONET model is used under its released terms; we release the
per-image pseudo-label manifests, not the model.

## Pretrained adapters

The trained adapters (`checkpoints/adapters/<fold>/*.safetensors`), the meta-fusion
networks and the conformal calibrators are distributed via the Zenodo record
(DOI 10.5281/zenodo.XXXXXXX, minted at acceptance). Place them per
`checkpoints/MANIFEST.json`; `pci_stack.checkpoints.verify()` checks their hashes.
