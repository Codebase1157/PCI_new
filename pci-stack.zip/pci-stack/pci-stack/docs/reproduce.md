# Reproducing the paper

This walks through regenerating Tables 2–7 end to end. It assumes you have obtained the
six datasets and the three backbones (see [`data_access.md`](data_access.md)).

## 0. Environment

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .
make test          # 47 unit tests over the self-contained numerics
make demo          # synthetic end-to-end smoke test of all five tiers (no data/weights)
```

## 1. Protocol in one paragraph

Leave-one-domain-out over the four training sources. Within each fold the three training
sources are split **patient-level** into learner-train (70%) / level-1 (15%) /
conformal-calibration (15%), with a training-domain validation set for model selection.
Hyper-parameters are **frozen after the first fold**. The external sets (DDI, SCIN) are
evaluated **exactly once**, after every design decision is final. The primary endpoint,
fixed before any result was inspected, is **worst-group AUROC on DDI**.

## 2. Full pipeline

```bash
CFG=configs/default.yaml

python scripts/00_prepare_data.py  --config $CFG           # harmonize -> manifest (Table 1/S4)
python scripts/01_estimate_tone.py --config $CFG           # label-free ITA (Section 3.2, S6)
python scripts/02_make_splits.py   --config $CFG           # LODO splits (Section 3.3)

for FOLD in isic2019 derm7pt fitzpatrick17k_c pad_ufes_20; do
  python scripts/03_train_learners.py    --config $CFG --fold $FOLD   # stage-1 (eq 13)
  python scripts/04_train_meta.py        --config $CFG --fold $FOLD   # stage-2 (eq 14-20)
  python scripts/05_calibrate_conformal.py --config $CFG --fold $FOLD # eq 22-25
done

python scripts/06_evaluate.py  --config $CFG               # Tables 2/3/6 + external (once)
python scripts/07_run_audit.py --config $CFG               # Table 7 (eq 26-30)
python scripts/08_reproduce_tables.py                      # print tables + headline checks
```

`make pipeline FOLD=isic2019` runs stages 00–06 for a single fold.

## 3. What each stage writes

| Stage | Output |
|-------|--------|
| 00 | `data/harmonized/manifest.csv`, `exclusion_report_tableS4.csv` |
| 01 | `ita`/`ita_bin` columns on the manifest; Table S6 agreement in the log |
| 02 | `splits/lodo_<fold>/split.csv` + `summary.csv` |
| 03 | `checkpoints/adapters/<fold>/{M1..M4}.safetensors`; `logs/stage1_fold-<fold>.log` |
| 04 | `checkpoints/meta/<fold>/meta.pt` |
| 05 | `checkpoints/conformal/<fold>/calibrator.json` |
| 06 | `results/predictions/`, `results/metrics_<fold>.json`, `results/external.json` |
| 07 | `results/audit_<fold>.json` |
| 08 | prints `results/tables/table{2..7}*.csv` with abstract headline checks |

## 4. Wiring the data loader (stages 03–07)

Stages 03–07 need a loader that yields batches of `{images, labels, masks, nuisance,
concept_targets, concept_mask}` from a `split.csv`. Minimal sketch:

```python
import numpy as np, pandas as pd
from pci_stack.config import load_config
from pci_stack.data import ImageLoader
from pci_stack.generators import CounterfactualEngine
from pci_stack.models import LearnerZoo
from pci_stack.engine import Stage1Config, train_learner
from pci_stack.losses import LearnerWeights

cfg = load_config("configs/default.yaml")
split = pd.read_csv("splits/lodo_isic2019/split.csv")
train = split[split.role == "learner_train"]
loader = ImageLoader(cfg.paths.data_root, size=cfg.image_size)
engine = CounterfactualEngine.from_config(cfg.generator)

class FoldBatches:                       # yields dict batches; add .reset(epoch)/__len__
    def __init__(self, df, bs=32): ...
    def __iter__(self): ...

zoo = LearnerZoo(weights={"panderm_vit_l": "data/backbones/panderm_vit_l.safetensors"})
train_learner(zoo.M1, FoldBatches(train), engine,
              Stage1Config(weights=LearnerWeights(lambda_con=0, lambda_adv=0)),
              name="M1", log_path="logs/stage1_M1_isic2019.jsonl")
```

The counterfactual reference pool for M2 (`engine.set_reference_pool(...)`) is a set of
cross-device images; the Derm7pt real pairs feed the meta-consistency term (eq 18) via
`pci_stack.generators.PairedAnchorSet` — withheld automatically when Derm7pt is the
held-out fold (Reviewer 2.2).

## 5. Determinism

Everything is seeded from `cfg.seed`. PCI-Stack and the three strongest baselines use 5
seeds; the rest use 3. Point estimates are seed means; intervals are patient-level
bootstrap over 2,000 resamples (`pci_stack.utils.metrics.bootstrap_ci`), reported
separately from per-seed dispersion (Table S9).

## 6. Pre-submission checklist (from the manuscript review comments)

- [ ] **Reviewer 2.2** — confirm Derm7pt pairs are withheld in the Derm7pt fold
      (`PairedAnchorSet.active` is `False` there; see `tests` and `generators/paired_anchor.py`).
- [ ] **Reviewer 2.4** — HSIC is class-conditional (`configs/.../_shared.yaml:
      hsic.class_conditional: true`; `tests/test_losses.py`).
- [ ] **Reviewer 1.13** — mint the Zenodo DOI and replace `XXXXXXX` in `README.md`,
      `CITATION.cff`, `pyproject.toml`, `checkpoints/MANIFEST.json`; make the repo public.
- [ ] **Reviewer 1.6** — add patient-level bootstrap CIs to every Table 3 cell.
