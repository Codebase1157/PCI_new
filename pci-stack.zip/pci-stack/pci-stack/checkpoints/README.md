# checkpoints/

Pretrained **LoRA adapters** and downstream state for each LODO fold (the "pretrained
adapters" deliverable of Section 4.7).

## What is released here vs. fetched

| Released in the repo | Fetched from Zenodo | Never redistributed |
|----------------------|---------------------|---------------------|
| `MANIFEST.json` (this directory) | adapter `.safetensors`, `meta.pt`, `calibrator.json` | base PanDerm/DINOv2/Swin weights |

Only ~**12.4 M** trainable parameters (**1.7%** of the backbone stack, LoRA rank 16) are
updated, so the adapter payload is small. The adapters are **useless without the base
backbone weights**, which are obtained separately (see `../LICENSE-PANDERM-NOTE.md` and
`../docs/data_access.md`). PanDerm in particular is redistributed only under its research
license, so we ship adapters, not weights.

## Layout

```
checkpoints/
├── MANIFEST.json                       # artifact list + SHA-256 (verified on load)
├── adapters/<fold>/{M1,M2,M3,M4}.safetensors
├── meta/<fold>/meta.pt                 # gated meta-fusion network
└── conformal/<fold>/calibrator.json    # Mondrian thresholds + kappa
```

## Usage

```python
from pci_stack.checkpoints import verify, load_adapters
from pci_stack.models import LearnerZoo

print(verify("checkpoints"))            # which files are present / hash status

zoo = LearnerZoo(weights={"panderm_vit_l": "data/backbones/panderm_vit_l.safetensors"})
load_adapters(zoo, fold="isic2019")     # loads M1-M4 adapters for that fold
```

Re-export after (re)training with:

```bash
python scripts/export_adapters.py --fold isic2019
```

which writes the adapter files and regenerates `MANIFEST.json` with fresh hashes.
