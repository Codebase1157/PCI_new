"""Losses: HSIC (eq 10), counterfactual consistency (eq 9/18), concept BCE (eq 11),
objectives + ramp (eq 13/19/20)."""
import numpy as np
import pytest

torch = pytest.importorskip("torch")

from pci_stack.losses import (
    class_conditional_hsic,
    consistency_ramp,
    hsic,
    kl_consistency,
    masked_concept_bce,
    prob_consistency,
)


def test_hsic_zero_for_independent():
    g = torch.Generator().manual_seed(0)
    z = torch.randn(200, 8, generator=g)
    s = torch.randn(200, 1, generator=g)       # independent of z
    assert hsic(z, s).item() < hsic(z, z).item()


def test_hsic_detects_dependence():
    g = torch.Generator().manual_seed(0)
    z = torch.randn(200, 4, generator=g)
    s = z[:, :1] * 3.0                          # strongly dependent
    assert hsic(z, s).item() > 0


def test_class_conditional_hsic_runs_per_stratum():
    g = torch.Generator().manual_seed(0)
    z = torch.randn(100, 4, generator=g)
    s = torch.randint(0, 3, (100, 1)).float()
    y = torch.randint(0, 2, (100,))
    val = class_conditional_hsic(z, s, y)
    assert torch.isfinite(val)


def test_kl_consistency_zero_for_identical():
    logits = torch.randn(8, 2)
    assert kl_consistency(logits, [logits.clone()]).item() == pytest.approx(0.0, abs=1e-5)


def test_prob_consistency_positive_for_different():
    p = torch.rand(8)
    assert prob_consistency(p, [1 - p]).item() > 0


def test_masked_concept_bce_ignores_unlabelled():
    logits = torch.zeros(4, 22)
    targets = torch.ones(4, 22)
    mask = torch.zeros(4, 22)
    mask[:, 0] = 1                              # only concept 0 annotated
    loss = masked_concept_bce(logits, targets, mask)
    # equals BCE on a single logit-0 target-1 pair
    assert loss.item() == pytest.approx(0.6931, abs=1e-3)


def test_consistency_ramp_monotone_then_saturates():
    assert consistency_ramp(0, 1.0, 20) == 0.0
    assert consistency_ramp(10, 1.0, 20) == pytest.approx(0.5)
    assert consistency_ramp(40, 1.0, 20) == 1.0
