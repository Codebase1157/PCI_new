"""Data: label map (Table S4b), LODO splits (Section 3.3), concept layer (Table S5)."""
import numpy as np
import pandas as pd

from pci_stack.constants import TRAINING_SOURCES
from pci_stack.data import (
    concept_table,
    harmonize_all,
    make_lodo_splits,
    to_binary,
    to_three_way,
)


def test_label_map_malignant_benign():
    assert to_binary("melanoma") == 1
    assert to_binary("basal cell carcinoma") == 1
    assert to_binary("melanocytic nevus") == 0
    assert to_binary("actinic keratosis") == 0        # non-malignant, reported sep.


def test_three_way_variant():
    assert to_three_way("ak") == "actinic_keratosis"
    assert to_three_way("mel") == "malignant"


def test_concept_table_has_22_rows():
    t = concept_table()
    assert len(t) == 22
    assert t["source"].nunique() == 3                 # checklist / skincon / monet


def _fake_manifest():
    rng = np.random.default_rng(0)
    frames = {}
    labs = ["mel", "nv", "bcc", "scc"]
    for s in TRAINING_SOURCES:
        n = 60
        frames[s] = pd.DataFrame({
            "image_id": [f"{s}_{i}" for i in range(n)],
            "native_label": rng.choice(labs, n),
            "path": [f"{s}/{i}.jpg" for i in range(n)],
            "patient_id": [f"{s}_p{i // 3}" for i in range(n)],
        })
    man, _ = harmonize_all(frames)
    return man


def test_lodo_split_roles_present():
    man = _fake_manifest()
    fold = make_lodo_splits(man, "pad_ufes_20", seed=0)
    roles = set(fold["role"].unique())
    assert {"learner_train", "level1_oof", "conformal_calib", "val",
            "heldout_test"} <= roles


def test_lodo_patient_disjoint_training_roles():
    man = _fake_manifest()
    fold = make_lodo_splits(man, "isic2019", seed=0)
    train = fold[fold["role"].isin(
        ["learner_train", "level1_oof", "conformal_calib", "val"])]
    # no patient appears in more than one training role
    assert train.groupby("patient_id")["role"].nunique().max() == 1


def test_heldout_source_is_isolated():
    man = _fake_manifest()
    fold = make_lodo_splits(man, "derm7pt", seed=0)
    held = fold[fold["role"] == "heldout_test"]
    assert (held["source"] == "derm7pt").all()
    assert (fold[fold["role"] != "heldout_test"]["source"] != "derm7pt").all()
