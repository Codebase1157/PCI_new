"""Tier 5: AAI (eq 29), CAS (eq 30), fused CAM (eq 27), surrogate fidelity (eq 28)."""
import numpy as np

from pci_stack.audit import (
    attribution_agreement_index,
    counterfactual_attribution_stability,
    fit_surrogate,
    fused_cam,
    jaccard,
    threshold_map,
)


def _blob(h=32, w=32, jitter=0.0, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w]
    b = np.exp(-(((yy - h // 2) ** 2 + (xx - w // 2) ** 2) / 40.0))
    return np.clip(b + jitter * rng.standard_normal((h, w)), 0, None)


def test_aai_agree_exceeds_random():
    agree = [_blob(jitter=0.1, seed=i) for i in range(4)]
    rng = np.random.default_rng(9)
    rand = [rng.random((32, 32)) for _ in range(4)]
    assert attribution_agreement_index(agree) > attribution_agreement_index(rand)


def test_jaccard_bounds():
    a = threshold_map(_blob())
    assert jaccard(a, a) == 1.0


def test_cas_high_for_stable_maps():
    fm = _blob(seed=0)
    cf = [_blob(jitter=0.03, seed=i) for i in range(3)]
    assert counterfactual_attribution_stability(fm, cf) > 0.9


def test_fused_cam_normalized():
    cams = [_blob(jitter=0.1, seed=i) for i in range(4)]
    fm = fused_cam(cams, np.array([0.4, 0.2, 0.2, 0.2]))
    assert fm.min() >= 0 and fm.max() <= 1


def test_surrogate_fidelity_high_for_linear_model():
    rng = np.random.default_rng(0)
    img = np.clip(0.5 + 0.1 * rng.standard_normal((48, 48, 3)), 0, 1)

    def predict(imgs):
        imgs = np.asarray(imgs)
        if imgs.ndim == 3:
            imgs = imgs[None]
        return imgs[:, 18:30, 18:30, :].mean(axis=(1, 2, 3))

    res = fit_surrogate(img, predict, n_segments=36, n_samples=200)
    assert res.fidelity > 0.5
