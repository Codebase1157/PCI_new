"""Tier 3: out-of-fold leakage control (eq 14), disagreement (eq 15), gating (eq 16-17)."""
import numpy as np
import pytest

from pci_stack.fusion import (
    OOFAssignment,
    build_oof_predictions,
    disagreement,
    disagreement_batch,
    pairwise_disagreement,
)

torch = pytest.importorskip("torch")
from pci_stack.fusion import MetaConfig, MetaFusion, build_u, fuse  # noqa: E402


def test_oof_is_patient_disjoint():
    n = 100
    patient_ids = np.repeat(np.arange(50), 2)
    a = OOFAssignment.make(n, 4, patient_ids=patient_ids, seed=0)
    # a patient's two images share a fold
    for p in np.unique(patient_ids):
        folds = np.unique(a.fold_of[patient_ids == p])
        assert len(folds) == 1


def test_oof_prediction_never_sees_example():
    n = 40
    a = OOFAssignment.make(n, 4, seed=0)
    seen = {}

    def fit_predict(train_idx, predict_idx):
        for i in predict_idx:
            seen[i] = set(train_idx.tolist())
        return np.zeros(len(predict_idx))

    build_oof_predictions(fit_predict, np.zeros(n), a)
    for i, train in seen.items():
        assert i not in train              # eq (14): replica never saw i


def test_disagreement_matches_variance():
    views = [0.2, 0.4, 0.6]
    assert disagreement(views) == pytest.approx(np.var(views))


def test_disagreement_batch_shape():
    m = np.random.default_rng(0).random((10, 3))
    assert disagreement_batch(m).shape == (10,)


def test_gating_rows_sum_to_one():
    meta = MetaFusion(MetaConfig(n_learners=4, repr_dim=8))
    p = torch.rand(16, 4)
    z = torch.rand(16, 4, 8)
    d = torch.rand(16, 4)
    fused_p, gates = meta(p, z, d)
    assert torch.allclose(gates.sum(1), torch.ones(16), atol=1e-5)
    assert fused_p.shape == (16,)


def test_vanilla_stacking_ignores_input():
    meta = MetaFusion(MetaConfig(n_learners=4, repr_dim=8, ignore_input=True))
    p = torch.rand(8, 4)
    g1 = meta(p, torch.rand(8, 4, 8), torch.rand(8, 4))[1]
    g2 = meta(p, torch.rand(8, 4, 8), torch.rand(8, 4))[1]
    # gates depend only on the global vector, not the (different) z/d inputs
    assert torch.allclose(g1, g2, atol=1e-6)
