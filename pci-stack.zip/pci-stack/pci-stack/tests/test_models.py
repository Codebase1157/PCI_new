"""Tier 2: LoRA injection, the four-learner zoo, shared backbone (synthetic)."""
import pytest

torch = pytest.importorskip("torch")

from pci_stack.models import LearnerZoo, LoRALinear, inject_lora


def test_lora_linear_starts_as_identity():
    base = torch.nn.Linear(16, 8)
    lora = LoRALinear(base, r=4)
    x = torch.randn(3, 16)
    # B is zero-initialized -> update is zero at start
    assert torch.allclose(lora(x), base(x), atol=1e-6)


def test_inject_lora_counts_layers():
    block = torch.nn.Sequential(
        torch.nn.Linear(8, 8),           # name "0" — not a target
    )
    block.qkv = torch.nn.Linear(8, 24)   # target by name
    n = inject_lora(block, targets=("qkv",), r=2)
    assert n == 1
    assert isinstance(block.qkv, LoRALinear)


def test_zoo_four_learners_and_shared_backbone():
    zoo = LearnerZoo(synthetic=True)
    assert zoo.order == ["M1", "M2", "M3", "M4"]
    # M1 and M3 share one backbone object (Table S8)
    assert zoo.M1.backbone is zoo.M3.backbone
    assert zoo.M2.backbone is not zoo.M1.backbone


def test_zoo_forward_outputs():
    zoo = LearnerZoo(synthetic=True)
    x = torch.rand(4, 3, 64, 64)
    outs = zoo.forward(x)
    assert set(outs) == {"M1", "M2", "M3", "M4"}
    assert "concept_logits" in outs["M3"]        # concept head on M3
    assert "nuisance_logits" in outs["M4"]       # GRL discriminator on M4
    p = zoo.probs(x)
    assert p.shape == (4, 4)
