"""Tier 4: nonconformity (eq 21), Mondrian coverage (eq 22), shift weights (eq 23),
abstention (eq 25)."""
import numpy as np
import pytest

from pci_stack.conformal import (
    MondrianCalibrator,
    abstain,
    calibrate_margin,
    density_ratio_weights,
    nonconformity,
    prediction_set,
)
from pci_stack.utils.metrics import coverage


def _data(n=2000, seed=0):
    rng = np.random.default_rng(seed)
    y = rng.integers(0, 2, n)
    p = np.clip(0.5 + 0.3 * (2 * y - 1) + 0.2 * rng.standard_normal(n), 0.01, 0.99)
    P = np.stack([1 - p, p], 1)
    tone = rng.choice(["light", "intermediate", "dark"], n, p=[0.5, 0.35, 0.15])
    dom = rng.choice(["dermoscopy", "clinical", "smartphone"], n)
    return y, p, P, tone, dom


def test_nonconformity_is_one_minus_prob():
    P = np.array([[0.3, 0.7], [0.6, 0.4]])
    np.testing.assert_allclose(nonconformity(P, np.array([1, 0])), [0.3, 0.4])


def test_mondrian_coverage_near_target():
    y, p, P, tone, dom = _data()
    cal = MondrianCalibrator(alpha=0.10, min_cell_count=50).fit(
        nonconformity(P, y), tone, dom)
    sets = prediction_set(P, tone, dom, cal)
    assert coverage(sets, y) >= 0.86        # ~0.90 target, finite-sample slack


def test_thin_cells_are_pooled():
    # construct a source with a tiny dark/smartphone cell
    rng = np.random.default_rng(1)
    n = 600
    tone = np.array(["dark"] * 10 + ["intermediate"] * 300 + ["light"] * 290)
    dom = np.array(["smartphone"] * n)
    scores = rng.random(n)
    cal = MondrianCalibrator(min_cell_count=50).fit(scores, tone, dom)
    # the 10-score dark cell must have been pooled, not kept
    assert ("dark", "smartphone") in cal.pooled_into


def test_density_ratio_monotone_in_rho():
    w = density_ratio_weights(np.array([0.2, 0.5, 0.8]), pi_tgt=0.5)
    assert w[0] < w[1] < w[2]


def test_abstention_respects_budget():
    rng = np.random.default_rng(0)
    n = 1000
    p = rng.random(n)
    lp = np.clip(p[:, None] + 0.1 * rng.standard_normal((n, 4)), 0, 1)
    kappa = calibrate_margin(lp, p, delta=0.10)
    sets = [{0} for _ in range(n)]          # all singletons -> only disagreement triggers
    mask = abstain(sets, lp, p, kappa)
    assert abs(mask.mean() - 0.10) < 0.05   # ~delta by construction
