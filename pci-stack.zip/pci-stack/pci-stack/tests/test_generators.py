"""Tier 1: Fourier amplitude exchange (eq 7), photometric chain (eq 8), engine."""
import numpy as np

from pci_stack.generators import (
    CounterfactualEngine,
    EngineConfig,
    amplitude_exchange,
    photometric_counterfactual,
)


def _img(seed=0):
    rng = np.random.default_rng(seed)
    return np.clip(0.5 + 0.1 * rng.standard_normal((32, 32, 3)), 0, 1)


def test_fourier_preserves_shape_and_range():
    out = amplitude_exchange(_img(0), _img(1), beta=0.10)
    assert out.shape == (32, 32, 3)
    assert out.min() >= 0 and out.max() <= 1


def test_fourier_zero_band_is_near_identity():
    img = _img(0)
    # a near-zero band swaps almost nothing -> close to the source
    out = amplitude_exchange(img, _img(5), beta=0.0)
    assert np.abs(out - img).mean() < 0.05


def test_photometric_changes_image():
    img = _img(2)
    out = photometric_counterfactual(img, rng=np.random.default_rng(0))
    assert out.shape == img.shape
    assert not np.allclose(out, img)


def test_engine_dispatches_requested_axes():
    eng = CounterfactualEngine(EngineConfig(views_per_image=2),
                               reference_pool=[_img(3)])
    v = eng.views(_img(0), ["tone", "fourier", "photometric"])
    assert set(v) == {"tone", "fourier", "photometric"}
    assert len(v["fourier"]) == 2 and len(v["photometric"]) == 2
