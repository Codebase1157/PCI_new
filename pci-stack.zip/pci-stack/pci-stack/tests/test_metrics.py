"""Metrics: AUROC, worst-group AUROC (eq 31), EOD (eq 32), bootstrap CI."""
import numpy as np

from pci_stack.utils.metrics import (
    auroc,
    bootstrap_ci,
    equal_opportunity_difference,
    light_to_dark_gap,
    worst_group_auroc,
)


def test_auroc_perfect_and_random():
    y = np.array([0, 0, 1, 1])
    assert auroc(y, np.array([0.1, 0.2, 0.8, 0.9])) == 1.0
    assert abs(auroc(y, np.array([0.5, 0.5, 0.5, 0.5])) - 0.5) < 1e-9 or np.isnan(
        auroc(y, np.array([0.5, 0.5, 0.5, 0.5]))) is False


def test_worst_group_is_minimum():
    rng = np.random.default_rng(0)
    n = 300
    groups = rng.choice(["a", "b", "c"], n)
    y = rng.integers(0, 2, n)
    s = rng.random(n)
    wg = worst_group_auroc(y, s, groups)
    per = [auroc(y[groups == g], s[groups == g]) for g in ["a", "b", "c"]]
    assert abs(wg - min(per)) < 1e-9


def test_light_to_dark_gap_sign():
    y = np.array([0, 1, 0, 1, 0, 1, 0, 1])
    fitz = np.array(["I-II"] * 4 + ["V-VI"] * 4)
    s = np.array([0.1, 0.9, 0.2, 0.8, 0.5, 0.5, 0.5, 0.5])   # light separable, dark not
    assert light_to_dark_gap(y, s, fitz) > 0


def test_eod_zero_when_equal_tpr():
    y = np.array([1, 1, 1, 1])
    pred = np.array([1, 1, 1, 1])
    fitz = np.array(["I-II", "I-II", "V-VI", "V-VI"])
    assert equal_opportunity_difference(y, pred, fitz) == 0.0


def test_bootstrap_ci_brackets_point():
    rng = np.random.default_rng(0)
    n = 200
    y = rng.integers(0, 2, n)
    s = np.clip(0.5 + 0.3 * (2 * y - 1) + 0.2 * rng.standard_normal(n), 0, 1)
    pt, lo, hi = bootstrap_ci(auroc, y, s, n_resamples=200)
    assert lo <= pt <= hi
