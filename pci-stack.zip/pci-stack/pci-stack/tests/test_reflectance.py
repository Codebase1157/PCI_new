"""Tier 1: two-chromophore reflectance (eq 3) and tone counterfactual (eq 5-6)."""
import numpy as np

from pci_stack.generators import decompose, render, estimate_ita, tone_counterfactual


def _img(seed=0):
    rng = np.random.default_rng(seed)
    return np.clip(0.55 + 0.1 * rng.standard_normal((48, 48, 3)), 0, 1)


def test_reflectance_round_trip_is_identity():
    img = _img()
    recon = render(decompose(img))
    assert np.abs(recon - img).max() < 1e-6


def test_chromophore_maps_nonnegative():
    maps = decompose(_img())
    assert (maps.c_m >= 0).all() and (maps.c_h >= 0).all()


def test_ita_is_finite():
    ita = estimate_ita(_img())
    assert np.isfinite(ita)


def test_tone_counterfactual_shape_and_range():
    img = _img()
    mask = np.zeros((48, 48)); mask[18:30, 18:30] = 1
    xt = tone_counterfactual(img, "dark", mask)
    assert xt.shape == img.shape
    assert xt.min() >= 0 and xt.max() <= 1


def test_tone_edit_moves_ita_toward_target():
    img = _img(1)
    mask = np.zeros((48, 48)); mask[18:30, 18:30] = 1
    base = estimate_ita(img, mask)
    dark = tone_counterfactual(img, "dark", mask)
    # dark target should not raise ITA above the original
    assert estimate_ita(dark, mask) <= base + 5.0
