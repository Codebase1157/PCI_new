# results/

CSV reproductions of **every** quantitative table in the paper and supplement.
`scripts/08_reproduce_tables.py` reads the main tables and prints them with the
abstract's headline checks.

## Main tables

| File | Paper table |
|------|-------------|
| `tables/table1_datasets.csv` | Table 1 — the six datasets and the harmonized split |
| `tables/table2_lodo_auroc.csv` | Table 2 — leave-one-domain-out held-out AUROC |
| `tables/table3_external.csv` | Table 3 — external validation (DDI, SCIN) |
| `tables/table4_ablation.csv` | Table 4 — framework ablation |
| `tables/table5_diversity_cost.csv` | Table 5 — diversity diagnostics & inference cost |
| `tables/table6_conformal.csv` | Table 6 — conformal coverage |
| `tables/table7_audit.csv` | Table 7 — explanation audit |

## Supplementary tables

| File | Supp. table |
|------|-------------|
| `tables/tableS1_implementation.csv` | S1 — complete training / generation configuration |
| `tables/tableS2_positioning.csv` | S2 — positioning against prior work (C1–C9) |
| `tables/tableS3_calibration_occupancy.csv` | S3 — conformal calibration cell occupancy |
| `tables/tableS4_exclusions.csv` | S4 — images removed at each harmonization step |
| `tables/tableS4b_label_map.csv` | S4b — native-diagnosis → binary-target mapping |
| `tables/tableS5_concepts.csv` | S5 — 22-concept clinical-layer provenance |
| `tables/tableS6_ita_agreement.csv` | S6 — estimated-ITA vs Fitzpatrick confusion |
| `tables/tableS6b_agreement_summary.csv` | S6 — κ and exact-agreement summary |
| `tables/tableS7_concept_noise.csv` | S7 — sensitivity to concept-label noise |
| `tables/tableS8_compute_by_stage.csv` | S8 — inference compute by stage |
| `tables/tableS9_seed_dispersion.csv` | S9 — per-seed dispersion |
| `tables/tableS10_statistical_comparison.csv` | S10 — statistical comparison on the external set |
| `tables/tableS11_confusion.csv` | S11 — per-stratum confusion counts |
| `tables/tableS12_recent_systems.csv` | S12 — comparison with recently published systems |

These are the **reference values** from the manuscript. When you run the full pipeline
(stages 03–06), `scripts/06_evaluate.py` writes freshly computed metrics under
`results/` and `results/predictions/`; compare against these CSVs to confirm a faithful
reproduction. Point estimates are seed means; the paper reports patient-level bootstrap
intervals over 2,000 resamples (see `pci_stack.utils.metrics.bootstrap_ci`).

Freshly generated run files (`results/predictions/`, `results/summary.json`,
`results/metrics_*.json`) are git-ignored; the committed CSVs above are the stable
reference.
